
-- ########################################################################################################################
-- PROCESO
-- Detalle del Proceso
SELECT GP01.[GPR01_PRETMID]
      ,GP01.[GPR01_PROCOD]
      ,GP01.[GPR01_PROETM]
      ,GP01.[GPR01_ETMDEC]
	  ,GP02.[GPR02_ETACOD] + '-|-' + GP03.[GPR03_MOTCOD] AS ETAMOT
      ,GP02.[GPR02_ETCOID]
	  ,GP02.[GPR02_ETACOD]
	  ,GP02.[GPR02_ETADEC]
      ,GP03.[GPR03_MOTID]
	  ,GP03.[GPR03_MOTCOD]
	  ,GP03.[GPR03_MOTDEC]
  FROM [PVTWEB].[dbo].[GPR01_PROGES] AS GP01
	INNER JOIN (SELECT [GPR02_ETCOID]
					  ,[GPR02_ETACOD]
					  ,[GPR02_ETADEC]
				  FROM [PVTWEB].[dbo].[GPR02_ETAPAS]
				) AS GP02 ON
		GP01.[GPR02_ETCOID] = GP02.[GPR02_ETCOID]
	INNER JOIN (SELECT [GPR03_MOTID]
					  ,[GPR03_MOTCOD]
					  ,[GPR03_MOTDEC]
				  FROM [PVTWEB].[dbo].[GPR03_MOTIVO]
				) AS GP03 ON
		GP01.[GPR03_MOTID] = GP03.[GPR03_MOTID]
ORDER BY GP01.[GPR01_PROETM]
-- FIN

-- LISTADO DE CUENTA CORRIENTE
SELECT TOP 1000 [PCC03_CPBTEID], [PCC03_CPBTENUM], [GPR03_PROETM],  [PCC03_PRETCOM]
FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
WHERE [PCC03_CTADEN] LIKE '%SANCOR%'


-- ########################################################################################################################
-- INICIO -- CAMBIA EL ESTADO DE UN GRUPO DE REGISTROS
-- ########################################################################################################################
-- PRIMERO PASA LOS DATOS AL HISTORICO DE MOVIMIENTOS
INSERT INTO [PVTWEB].[dbo].[PCC07_PROHIST]
           ([PCC07_CPBTEID]
           ,[PCC07_PROETM_ANT]
           ,[PCC07_PRETCOM_ANT]
		   ,[PCC07_PRETCOM2_ANT]
           ,[PCC07_PRETFECH_ANT]
           ,[PCC07_PROETM_ACT]
           ,[PCC07_PRETCOM_ACT]
           ,[PCC07_PRETCOM2_ACT]
           ,[PCC07_PRETFECH_ACT]
		   ,[PCC07_CPBCCCOD]
		   ,[PCC07_CTASLDO])
	SELECT [PCC03_CPBTEID]
			,[GPR03_PROETM] AS [PROETM_ANT]
			,[PCC03_PRETCOM] AS [PRETCOM_ANT]
			,[PCC03_PRETCOM02] AS [PRETCOM2_ANT]
			,[PCC03_PRETFECH] AS [PRETFECH_ANT]
			,[PCC072_PROETM] AS [PROETM_ACT]
			,[PCC072_PRETCOM] AS [PRETCOM_ACT]
			,NULL AS [PCC07_PRETCOM2_ACT]
			,CAST(GETDATE() AS SMALLDATETIME) AS [PRETFECH_ACT]
			,[PCC03_CPBCCCOD]
			,[PCC03_CPBTESLDO]
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CA
		INNER JOIN (
					SELECT [PCC072_CPBTEID]
						  ,[PCC072_PROETM]
						  ,[PCC072_PRETCOM]
						  ,[PCC072_PRETCOM2]
					  FROM [PVTWEB].[dbo].[PCC072_DATACT]
					) AS FA ON
						CA.[PCC03_CPBTEID] = FA.[PCC072_CPBTEID]

-- LUEGO DEBE ACTUALIZAR LA NUEVA INFO
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [GPR03_PROETM] = [PCC072_PROETM]
      ,[PCC03_PRETCOM] = [PCC072_PRETCOM]
	  ,[PCC03_PRETCOM02] = [PCC072_PRETCOM2]
	  ,[PCC03_PRETFECH] = CAST(GETDATE() AS SMALLDATETIME)
--SELECT TOP 1000 [PCC03_CPBTEID], [GPR01_PROETM],[PCC03_PRETCOM], DA.*
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CA
		INNER JOIN (
					SELECT [PCC072_CPBTEID]
						  ,[PCC072_PROETM]
						  ,[PCC072_PRETCOM]
						  ,[PCC072_PRETCOM2]
					  FROM [PVTWEB].[dbo].[PCC072_DATACT]
					) AS FA ON
						CA.[PCC03_CPBTEID] = FA.[PCC072_CPBTEID]

DELETE FROM [PVTWEB].[dbo].[PCC072_DATACT]

-- ########################################################################################################################
-- FIN -- CAMBIA EL ESTADO DE UN GRUPO DE REGISTROS
-- ########################################################################################################################





-- ########################################################################################################################
-- INICIO -- PONE A CERO UN REGISTRO
-- ########################################################################################################################
DECLARE @COMPID AS NVARCHAR(36)
SET @COMPID = '76843E48-8C56-4547-92A9-96E16262498C'
--
--SELECT *
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
--		WHERE [PCC03_CPBTEID] = @COMPID

-- PRIMERO PASA LOS DATOS AL HISTORICO DE MOVIMIENTOS
INSERT INTO [PVTWEB].[dbo].[PCC07_PROHIST]
           ([PCC07_CPBTEID]
           ,[PCC07_PROETM_ANT]
           ,[PCC07_PRETCOM_ANT]
		   ,[PCC07_PRETCOM2_ANT]
           ,[PCC07_PRETFECH_ANT]
           ,[PCC07_PROETM_ACT]
           ,[PCC07_PRETCOM_ACT]
		   ,[PCC07_PRETCOM2_ACT]
           ,[PCC07_PRETFECH_ACT])
	SELECT [PCC03_CPBTEID]
			,[GPR03_PROETM] AS [PROETM_ANT]
			,[PCC03_PRETCOM] AS [PRETCOM_ANT]
			,[PCC03_PRETCOM02] AS [PRETCOM2_ANT]
			,[PCC03_PRETFECH] AS [PRETFECH_ANT]
			,'CCC_001_01' AS [PROETM_ACT]
			,'Borra la Info' AS [PRETCOM_ACT]
			,'Borra la Info' AS [PRETCOM2_ACT]
			,CAST(GETDATE() AS SMALLDATETIME) AS [PRETFECH_ACT]
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [PCC03_CPBTEID] = @COMPID

-- LUEGO DEBE ACTUALIZAR LA NUEVA INFO
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [GPR03_PROETM] = 'CCC_001_01'
      ,[PCC03_PRETCOM] = NULL
	  ,[PCC03_PRETCOM02] = NULL
	  ,[PCC03_PRETFECH] = CAST(GETDATE() AS SMALLDATETIME)
--SELECT TOP 1000 [PCC03_CPBTEID], [GPR01_PROETM],[PCC03_PRETCOM], DA.*
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [PCC03_CPBTEID] = @COMPID

-- ########################################################################################################################
-- FIN -- PONE A CERO UN REGISTRO
-- ########################################################################################################################

