--
-- TABLA CON LOS DATOS DE LOS COMPROBANTES
SELECT TOP 100 *
FROM [CalipsoProduccion].[dbo].[V_COMPROMISOPAGO]
WHERE TRORIGINANTE_ID = '978213C7-DDB3-4337-94E0-CB240A60EBE0'
--
-- TABLA CON LA INFORMACI�N DE LAS PERSONAS
-- SELECT TOP 100 *
-- FROM [CalipsoProduccion].[dbo].[V_PERSONA]
---- WHERE BOEXTENSION_ID = '37ED52CF-CEFE-4159-8117-6863F9228404'
---- WHERE BO_PLACE_ID = '978213C7-DDB3-4337-94E0-CB240A60EBE0'
-- WHERE NOMBRE LIKE '%SCILLETTA CRISTIAN ARIEL (E)%'	 --37FF2B54-4192-4D72-AB94-0E0B62C17CE4

-- TABLA CON LA INFORMACI�N DE LOS CLIENTES
-- SELECT TOP 100 *
-- FROM [CalipsoProduccion].[dbo].[V_CLIENTE]

-- TABLA CON LOS CENTROS DE COSTOS
-- SELECT TOP 100 *
-- FROM [CalipsoProduccion].[dbo].[CENTROCOSTOS]
-- CODIGO

-- TABLA CON LAS SUCURSALES DE LOS TALLERES
--SELECT TOP 100 ID, CODIGO, NOMBRE, *
--FROM [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR]
--WHERE ID = '60668249-E505-4618-A239-F30E4D673E7C'

--
--978213C7-DDB3-4337-94E0-CB240A60EBE0
--
--SELECT TOP 100 *
--FROM [CalipsoProduccion].[dbo].[VP_OrdenTrabajoCabecera]
--WHERE 
--978213C7-DDB3-4337-94E0-CB240A60EBE0
--
--
--SELECT TOP 100 CODIGO
--		, '1' AS Clase
--		, DENOMINACION
--		, CLIENTE
--		, FECHAEMISION
--		, FECHAVENCIMIENTO
--		, Saldo_cuenta
--		, TIPOCPBTE
--		, Saldo_Comprobante
--		, NUMECPBTE
--		, ComprobanteID
--		, CENTROCOSTOS
--		, CTROCOSTOSNOMBRE
--		, TOTAL
--		, AUXILIAR1
--		, AUXILIAR2
--		, CodigoTipoVenta
--		, TIPOCTACTENOMBRE
--		, solicitud
--		, Grupo
--		, Orden
--		, NOTA
--		, DETALLE
--FROM (
--INSERT INTO [TPV].[dbo].[PCC01_DATIMP]
--           ([PCC01_CTACOD]
--           ,[PCC01_CTADEN]
--           ,[PCC01_CTACLI]
--           ,[PCC01_FECEMI]
--           ,[PCC01_FECVTO]
--           ,[PCC01_CPBTETIPO]
--           ,[PCC01_CPBTESLDO]
--           ,[PCC01_CPBTENUM]
--           ,[PCC01_CPBTEID]
--           ,[PCC01_CPBCCCOD]
--           ,[PCC01_CPBCCDES]
--           ,[PCC01_CPBTETOT]
--           ,[PCC01_CPBTEAUX1]
--           ,[PCC01_CPBTEAUX2]
--           ,[PCC01_TVTACOD]
--           ,[PCC01_TVTANOM]
--           ,[PCC01_CPBTESOL]
--           ,[PCC01_CPBTEGRUP]
--           ,[PCC01_CPBTEORD]
--           ,[PCC01_CPBTENOTA]
--           ,[PCC01_CPBTEDETA]
--		   ,[PCC01_CODTIPVTA]
--		   ,[PCC01_SUCCOD]
--		   ,[PCC01_SUCNOMB])

	SELECT TOP 1000 CLI.CODIGO AS [PCC01_CTACOD]	-- TABLA DATOS DE LOS CLIENTES
			, CLI.DENOMINACION AS [PCC01_CTADEN]	-- TABLA DATOS DE LOS CLIENTES
			, PER.NOMBRE AS [PCC01_CTACLI]	-- TABLA DATOS DEL PERSONAL
			, FOT.[TipoCliente]
			, FOT.[TelefonoContacto]
			, FOT.[Celular]
			, FOT.[TelefonoLaboral]
			, FOT.[TelefonoParticular]
			, FOT.[Email]
			, FOT.[ProvinciaCliente]
			, FOT.[CiudadCliente]
			, SUBSTRING(CP.FECHAEMISION,7,2) + '/' + SUBSTRING(CP.FECHAEMISION,5,2) + '/' + SUBSTRING(CP.FECHAEMISION,0,5) AS [PCC01_FECEMI]
			, SUBSTRING(CP.FECHAVENCIMIENTO,7,2) + '/' + SUBSTRING(CP.FECHAVENCIMIENTO,5,2) + '/' + SUBSTRING(CP.FECHAVENCIMIENTO,0,5) AS [PCC01_FECVTO]
--			, CP.FECHAEMISION
--			, CP.FECHAVENCIMIENTO
			, CASE CP.TIPO WHEN 'CPFACTURA' THEN 'Fac' 
							WHEN 'CPDEBITO' THEN 'Deb' 
							WHEN 'CPCREDITO' THEN 'Cre' 
							WHEN 'CPRECIBO' THEN 'Rec'
							END AS [PCC01_CPBTETIPO]
			, CP.SALDO2_IMPORTE AS [PCC01_CPBTESLDO]
			, CP.DESCRIPCION AS [PCC01_CPBTENUM]
			, CP.TRORIGINANTE_ID AS [PCC01_CPBTEID]
			, CC.CODIGO AS [PCC01_CPBCCCOD]
			, CC.NOMBRE AS [PCC01_CPBCCDES]
			, CASE WHEN (CP.TIPO IN ('CPFACTURA', 'CPDEBITO') AND CP.IMTOTAL2_UNIDADVALORIZACION_ID = '0AB552E0-31DE-455B-A3F1-3A2FC195AFE2') THEN CP.IMTOTAL2_IMPORTE 
					ELSE CASE WHEN (CP.TIPO IN ('CPFACTURA', 'CPDEBITO') AND CP.IMTOTAL2_UNIDADVALORIZACION_ID <> '0AB552E0-31DE-455B-A3F1-3A2FC195AFE2') THEN CP.IMTOTAL2_IMPORTE * CP.TRCOTIZACION 
								ELSE CASE WHEN CP.IMTOTAL2_UNIDADVALORIZACION_ID = '0AB552E0-31DE-455B-A3F1-3A2FC195AFE2' THEN - 1 * CP.IMTOTAL2_IMPORTE 
											ELSE - 1 * CP.IMTOTAL2_IMPORTE * CP.TRCOTIZACION 
											END 
								END 
					END AS [PCC01_CPBTETOT]
			, CP.AUXILIAR1 AS [PCC01_CPBTEAUX1]
			, CP.AUXILIAR2 AS [PCC01_CPBTEAUX2]
--			, tf.sutipo AS TIPOCTACTE_ID
			, LEFT(CP.NOMCLASIFICADOR, 3) AS [PCC01_TVTACOD]
			, CASE WHEN LEN(CP.NOMCLASIFICADOR) > 6 THEN RIGHT(CP.NOMCLASIFICADOR, LEN(CP.NOMCLASIFICADOR) - 6) 
					ELSE '' 
					END AS [PCC01_TVTANOM]
--			, tf.AgrupadorTipoVenta_ID AS AGRUPADOR
			, tf.solicitud AS [PCC01_CPBTESOL]
			, tf.Grupo AS [PCC01_CPBTEGRUP]
			, tf.NOTA AS [PCC01_CPBTENOTA]
			, tf.DETALLE AS [PCC01_CPBTEDETA]
			, tf.CodigoTipoVenta AS [PCC01_CODTIPVTA]
--				, CP.OPERADORCOMERCIAL_ID
--			, tf.SUCURSAL_ID
			, SC.CODIGO AS [PCC01_SUCCOD] 
			, SC.NOMBRE AS [PCC01_SUCNOMB]
			, FOT.[TipoTaller]
			, tf.Orden AS [PCC01_CPBTEORD]
			, FOT.[Receptor]
			, FOT.[TipoTrabajo]
			, FOT.[TipoService]
			, CASE WHEN FOT.[CargoOT] IS NULL THEN FOT.[Cargo] ELSE FOT.[CargoOT] END AS CARGOOT
			, FOT.[Estado]
			, FOT.[MesOT]
		    , FOT.[FechaOT]
		    , FOT.[FechaEjecucion]
		    , FOT.[FechaFinalizada]
		    , FOT.[Impedimento]
		    , FOT.Anomalias
		    , FOT.Diagnostico
		    , FOT.Incidentes
			, FOT.[AvisoCliente]
		    , FOT.[Detalle]
		    , FOT.[Dominio]
			, FOT.[Kilometros]
		    , FOT.[Marca]
		    , FOT.[Modelo]
		    , FOT.[Submodelo]
		    , FOT.[Motor]
		    , FOT.[NumeroChasis]
			, FOT.USUABRIOOT
			, FOT.FVID
       FROM	[CalipsoProduccion].[dbo].[V_COMPROMISOPAGO] AS CP WITH (NOLOCK) 
			INNER JOIN [CalipsoProduccion].[dbo].[V_CLIENTE] AS CLI WITH (NOLOCK)	-- Tabla 
					ON CP.OPERADORCOMERCIAL_ID = CLI.ID 
			INNER JOIN [CalipsoProduccion].[dbo].[CLI_PETRI] AS CPVTA WITH (NOLOCK) 
					ON CP.CODIGOOPERADORCOMERCIAL = CPVTA.[cli_codigo] 
			INNER JOIN [CalipsoProduccion].[dbo].[V_PERSONA] AS PER WITH (NOLOCK)	-- Tabla con los datos de las personas
					ON CLI.ENTEASOCIADO_ID = PER.ID 
			INNER JOIN [CalipsoProduccion].[dbo].[CENTROCOSTOS] AS CC WITH (nolock) ON 
				CP.CENTROCOSTOS_ID = CC.ID 
			INNER JOIN (SELECT ID
								, TipoVenta_ID AS sutipo
								, AgrupadorTipoVenta_ID
								, solicitud
								, Grupo
								, Orden
								, NOTA
								, DETALLE
								, CodigoTipoVenta
								, SUCURSAL_ID
							FROM  [CalipsoProduccion].[dbo].[Vc_TipoFacturas_]
                         UNION ALL
                         SELECT ID
								, TipoVenta_ID AS sutipo
								, AgrupadorTipoVenta_ID
								, solicitud
								, Grupo
								, Orden
								, NOTA
								, DETALLE
								, CodigoTipoVenta
								, SUCURSAL_ID
							FROM [CalipsoProduccion].[dbo].[Vc_TipoDebitos_]
                         UNION ALL
                         SELECT ID
								, TipoVenta_ID AS sutipo
								, AgrupadorTipoVenta_ID
								, solicitud
								, Grupo
								, Orden
								, NOTA
								, DETALLE
								, CodigoTipoVenta
								, SUCURSAL_ID
							FROM [CalipsoProduccion].[dbo].[Vc_TipoCreditos_]
                         UNION ALL
                         SELECT ID
								, TipoRecibo_ID AS sutipo
								, AgrupadorTipoVenta_ID
								, solicitud
								, Grupo
								, Orden
								, NOTA
								, DETALLE
								, CodigoTipoVenta
								, SUCURSAL_ID
							FROM [CalipsoProduccion].[dbo].[Vc_TipoRecibos_]
						) AS tf 
								ON tf.ID = CP.TRORIGINANTE_ID
			INNER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS SC ON
					tf.SUCURSAL_ID = SC.ID
			INNER JOIN (SELECT OT.*
								, OV.USUARIO AS USUABRIOOT
		--						, OV.NOMBRE AS OV
		--						, FV.NOMBRE AS FV
								, FV.ID AS FVID
							FROM [CalipsoProduccion].[dbo].[TRORDENVENTA] OV  WITH (NOLOCK)
								INNER JOIN	[CalipsoProduccion].[dbo].[TRPROCESOPORLOTE] AS TRPPL  WITH (NOLOCK) ON
									OV.ID = TRPPL.TRANSACCION_ID 
										AND	RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8' 
								INNER JOIN	[CalipsoProduccion].[dbo].[AGENTEPROCESOPORLOTE] AS APL WITH (NOLOCK) ON
									APL.TRSORIGEN_ID = TRPPL.BO_PLACE_ID
										AND	APL.RELACIONORIGEN_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8' 
								INNER JOIN	[CalipsoProduccion].[dbo].[TRFACTURAVENTA] AS FV WITH (NOLOCK) ON
									APL.ID = FV.GENERADAPOR_ID
								INNER JOIN (SELECT DISTINCT [id]  -- VP ORDEN TRABAJO DETALLE
												  , [TipoTaller]
												  , [Sucursal]
												  , [OrdenTrabajo]
												  , [TipoTrabajo]
												  , [TipoService]
												  , [CargoOT]
												  , [Estado]
												  , [MesOT]
												  , [FechaOT]
												  , [FechaEjecucion]
												  , [FechaFinalizada]
											--      ,[MesUltimoestado]
											--      ,[MesTurno]
												  , [Receptor]
												  , [Cliente]
												  , [Empresa]
												  , [TipoCliente]
												  , [Retira]
												  , [TelefonoContacto]
												  , [Celular]
												  , [TelefonoLaboral]
												  , [TelefonoParticular]
												  , [Email]
												  , [ProvinciaCliente]
												  , [CiudadCliente]
											--      , [CodigoPostal]
											--      , [CALLE]
											--      , [FechaUltimoEstado]
											--      , [FechaVentaVehiculo]
											--      , [Fechaturno]
												  , [Impedimento]
											--      , [FechaFinGarantia]
												  , CAST([Anomalias] AS NVARCHAR(MAX)) AS Anomalias
												  , CAST([Diagnostico] AS NVARCHAR(MAX)) AS Diagnostico
												  , CAST([Incidentes] AS NVARCHAR(MAX)) AS Incidentes
												  , [Detalle]
												  , [Cargo]
												  , [Centrocostos]
												  , [DESCRIPCION]
												  , [Dominio]
												  , [Marca]
												  , [Modelo]
												  , [Submodelo]
												  , [Motor]
												  , [NumeroChasis]
												  , [Kilometros]
											--      , [CodigoReferencia]
											--      , [DescripcionReferencia]
											--      , [Cantidad]
											--      , [TotalCosto]
											--      , [TotalDescuento]
											--      , [TotalNeto]
											--      , [Rubro]
											--      , [Tipo]
											--      , [Canal]
												  , [AvisoCliente]
											  FROM [CalipsoProduccion].[dbo].[VP_OrdenTrabajo] WITH (NOLOCK)
											--WHERE ORDENTRABAJO = 16004
											) AS OT ON
									OV.ID = OT.ID
							 WHERE OV.TIPOTRANSACCION_ID = 'AEDA2553-10E7-4258-9E74-ACC1EAE15580'
						) AS FOT ON 
							CP.TRORIGINANTE_ID = FOT.FVID
		WHERE (CP.CPCOMPRAS = 'F') 
				AND (CP.PRIMERNIVEL = 'T') 
				AND (SUBSTRING(CLI.CODIGO, 1, 1) = '2') 
				AND (CP.SALDO2_IMPORTE <> '0') 
				AND (CP.SALDADO = 'F')



-- TOTAL DEUDA POR CUENTA
--	) AS s
--	UNION ALL
--	-- CALCULA EL TOTAL DE CADA CUENTA
--	SELECT TOP (100) PERCENT codigo
--			, '2' AS Clase
--			, DENOMINACION
--			, CLIENTE
--			, '' AS FECHAEMISION
--			, '' AS FECHAVENCIMIENTO
--			, SUM(TOTAL) AS Saldo_Cuenta
--			, '' AS TIPOCPBTE
--			, 0 AS saldo_Comprobante
--			, '' AS NUMECPBTE
--			, 0 AS Total
--			, '' AS AUXILIAR1
--			, '' AS AUXILIAR2
--			, '' AS CodigoTipoVenta
--			, '' AS TIPOCTACTENOMBRE
--			, '' AS solicitud
--			, '' AS Grupo
--			, '' AS Orden
--			, '' AS NOTA
--			, '' AS DETALLE
--	FROM (SELECT top 100 CLI.CODIGO AS codigo
--				, CLI.DENOMINACION
--				, PER.NOMBRE AS CLIENTE
--				, CLI.ID AS CLIENTE_ID
--				, '2' AS CLASE
--				, CP.FECHAEMISION
--				, CP.FECHAVENCIMIENTO
--				, CP.SALDO2_IMPORTE
--				, CASE CP.TIPO WHEN 'CPFACTURA' THEN 'Fac' 
--								WHEN 'CPDEBITO' THEN 'Deb' 
--								WHEN 'CPCREDITO' THEN 'Cre' 
--								WHEN 'CPRECIBO' THEN 'Rec'
--							   END AS TIPOCPBTE
--				, CP.DESCRIPCION AS NUMECPBTE
--				, '' AS NUMECHEQUE
--				, '' AS BANCO
--				, CASE WHEN (CP.TIPO IN ('CPFACTURA', 'CPDEBITO') AND CP.IMTOTAL2_UNIDADVALORIZACION_ID = '0AB552E0-31DE-455B-A3F1-3A2FC195AFE2') THEN CP.IMTOTAL2_IMPORTE 
--						ELSE CASE WHEN (CP.TIPO IN ('CPFACTURA', 'CPDEBITO') AND CP.IMTOTAL2_UNIDADVALORIZACION_ID <> '0AB552E0-31DE-455B-A3F1-3A2FC195AFE2') THEN CP.IMTOTAL2_IMPORTE * CP.TRCOTIZACION 
--									ELSE CASE WHEN CP.IMTOTAL2_UNIDADVALORIZACION_ID = '0AB552E0-31DE-455B-A3F1-3A2FC195AFE2' THEN - 1 * CP.IMTOTAL2_IMPORTE 
--												ELSE - 1 * CP.IMTOTAL2_IMPORTE * CP.TRCOTIZACION 
--											  END 
--								  END 
--						END AS TOTAL
--				, 0 AS IMPORTEVALOR
--				, CP.SALDO2_IMPORTE AS SALDO
--				, CP.TRORIGINANTE_ID AS Comprobante_ID
--				, CP.AUXILIAR1
--				, CP.AUXILIAR2
--				, tf.sutipo AS TIPOCTACTE
--				, LEFT(CP.NOMCLASIFICADOR, 3) AS tipoctactecodigo
--				, CASE WHEN LEN(CP.NOMCLASIFICADOR) > 6 THEN RIGHT(CP.NOMCLASIFICADOR, LEN(CP.NOMCLASIFICADOR) - 6) 
--						ELSE '' 
--					   END AS TIPOCTACTENOMBRE
--				, tf.AgrupadorTipoVenta_ID AS AGRUPADOR
--				, tf.solicitud
--				, tf.Grupo
--				, tf.Orden
--				, tf.NOTA
--				, tf.DETALLE
--				, tf.CodigoTipoVenta
--				, CP.OPERADORCOMERCIAL_ID
--				, tf.SUCURSAL_ID
--			FROM [CalipsoProduccion].[dbo].[V_COMPROMISOPAGO] AS CP WITH (NOLOCK) 
--					INNER JOIN [CalipsoProduccion].[dbo].[V_CLIENTE] AS CLI WITH (NOLOCK) 
--							ON CP.OPERADORCOMERCIAL_ID = CLI.ID 
--					INNER JOIN [CalipsoProduccion].[dbo].[V_PERSONA] AS PER WITH (NOLOCK) 
--							ON CLI.ENTEASOCIADO_ID = PER.ID 
--					INNER JOIN (SELECT ID
--										, TipoVenta_ID AS sutipo
--										, AgrupadorTipoVenta_ID
--										, solicitud
--										, Grupo
--										, Orden
--										, NOTA
--										, DETALLE
--										, CodigoTipoVenta
--										, SUCURSAL_ID
--									 FROM [CalipsoProduccion].[dbo].[Vc_TipoFacturas_] AS Vc_TipoFacturas__1
--								UNION ALL
--								SELECT ID
--										, TipoVenta_ID AS sutipo
--										, AgrupadorTipoVenta_ID
--										, solicitud
--										, Grupo
--										, Orden
--										, NOTA
--										, DETALLE
--										, CodigoTipoVenta
--										, SUCURSAL_ID
--									FROM [CalipsoProduccion].[dbo].[Vc_TipoDebitos_] AS Vc_TipoDebitos__1
--								UNION ALL
--								SELECT ID
--										, TipoVenta_ID AS sutipo
--										, AgrupadorTipoVenta_ID
--										, solicitud
--										, Grupo
--										, Orden
--										, NOTA
--										, DETALLE
--										, CodigoTipoVenta
--										, SUCURSAL_ID
--								FROM [CalipsoProduccion].[dbo].[Vc_TipoCreditos_] AS Vc_TipoCreditos__1
--								UNION ALL
--								SELECT ID
--										, TipoRecibo_ID AS sutipo
--										, AgrupadorTipoVenta_ID
--										, solicitud
--										, Grupo
--										, Orden
--										, NOTA
--										, DETALLE
--										, CodigoTipoVenta
--										, SUCURSAL_ID
--									FROM [CalipsoProduccion].[dbo].[Vc_TipoRecibos_] AS Vc_TipoRecibos__1) AS tf 
--												ON tf.ID = CP.TRORIGINANTE_ID
--						   WHERE (CP.CPCOMPRAS = 'F') 
--									AND (CP.PRIMERNIVEL = 'T') 
--									AND (SUBSTRING(CLI.CODIGO, 1, 1) = '2') 
--									AND (CP.SALDO2_IMPORTE <> '0') 
--									AND (CP.SALDADO = 'F')
--			) AS q
--		GROUP BY CODIGO, DENOMINACION, CLIENTE, CLIENTE_ID, CLASE, OPERADORCOMERCIAL_ID
--		ORDER BY CODIGO, CLASE



