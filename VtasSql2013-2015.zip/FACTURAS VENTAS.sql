SELECT  CliCod, Cliente, Vendedor_por_Defecto, count(*) as cantreg, sum(TotalCosto) as totalneto
FROM(
		SELECT     'Factura Venta RT' AS Tipo_Comprobante
					, fv.NOMBRE AS Comprobante
					, fv.NUMERODOCUMENTO AS Numero_Factura
					, c1.CODIGO AS CliCod
					, fv.NOMBREDESTINATARIO AS Cliente
					, SUBSTRING(fv.FECHAACTUAL, 1, 4) AS A�o
					, SUBSTRING(fv.FECHAACTUAL, 5, 2) AS Mes
					, CAST(SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4) AS datetime) AS Fecha
					, itc2.NOMBRE AS Tipo_Venta
					, itc3.NOMBRE AS Sucursal
					, p.CODIGO AS Codigo_Referencia
					, p.DESCRIPCION AS Descripcion_Referencia
					, p.TipoBienCambio AS Tipo_Bien_Cambio
					, p.Rubro
					, p.SubRubro
					, p.Familia
					, p.Tipo AS Tipo_Referencia
					, ifv.CANTIDAD2_CANTIDAD AS Cantidad
					, ifv.TOTAL2_IMPORTE AS TotalVentaNeta
					, ifv.VALOR2_IMPORTE * ifv.PORCENTAJEBONIFICACION * ifv.CANTIDAD2_CANTIDAD AS TotalDescuento
					, ISNULL(ud2.PUCosto * ifv.CANTIDAD2_CANTIDAD * - 1, 0) AS TotalCosto
					, ISNULL(itc1.NOMBRE, '') AS cargo, ciu.NOMBRE AS Ciudad_Cliente
					, Pro.NOMBRE AS Provincia_Cliente
					, cc.NOMBRE AS Centro_Costos
					, itc4.CODIGO + ' - ' + itc4.NOMBRE AS Tipo_Cliente
					, emp.DESCRIPCION AS Vendedor
					, ud3.TeParticular AS Telefono_particular
					, pf.NOMBRE AS Vendedor_por_Defecto
		FROM dbo.TRFACTURAVENTA AS fv WITH (nolock) 
			INNER JOIN dbo.ITEMFACTURAVENTA AS ifv WITH (nolock) ON 
					ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID 
			LEFT OUTER JOIN dbo.VP_Referencia_ AS p WITH (nolock) ON 
					p.ID = ifv.REFERENCIA_ID 
			INNER JOIN dbo.UD_ITEMFACTURART AS ud2 WITH (nolock) ON 
					ud2.ID = ifv.BOEXTENSION_ID 
			LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc1 WITH (nolock) ON 
					itc1.ID = ud2.Cargo_ID 
			LEFT OUTER JOIN dbo.CENTROCOSTOS AS cc WITH (nolock) ON 
					cc.ID = ifv.CENTROCOSTOS_ID 
			INNER JOIN dbo.UD_FACTURAVENTART AS ud1 WITH (nolock) ON 
					ud1.ID = fv.BOEXTENSION_ID 
			LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc2 WITH (nolock) ON 
					itc2.ID = ud1.TipoVenta_ID 
			LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc3 WITH (nolock) ON 
					itc3.ID = ud1.Sucursal_ID 
			LEFT OUTER JOIN dbo.CLIENTE AS c1 WITH (nolock) ON 
					c1.ID = fv.DESTINATARIO_ID 
			LEFT OUTER JOIN dbo.UD_CLIENTE AS ud3 ON 
					ud3.ID = c1.BOEXTENSION_ID 
			LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc4 WITH (nolock) ON 
					itc4.ID = ud3.TipoCliente_ID 
			LEFT OUTER JOIN dbo.DOMICILIO AS dom ON 
				dom.ID = c1.DOMICILIOFACTURACION_ID 
			LEFT OUTER JOIN dbo.CIUDAD AS ciu ON 
				ciu.ID = dom.CIUDAD_ID 
			LEFT OUTER JOIN dbo.PROVINCIA AS Pro ON 
				Pro.ID = dom.PROVINCIA_ID 
			LEFT OUTER JOIN dbo.EMPLEADO AS emp ON 
				emp.ID = ud1.EmpleadoVendedor_ID 
			LEFT OUTER JOIN dbo.VENDEDOR AS vend WITH (nolock) ON 
				vend.ID = c1.OPERADORASOCIADODEFAULT_ID 
			LEFT OUTER JOIN dbo.PERSONAFISICA AS pf WITH (nolock) ON 
				pf.ID = vend.ENTEASOCIADO_ID
		WHERE     (fv.ESTADO = 'C') AND (fv.FECHAACTUAL >= '20120601')
		UNION ALL
		SELECT  'Nota Credito Venta' AS Tipo_Comprobante
				, fv.NOMBRE AS Comprobante
				, fv.NUMERODOCUMENTO AS Numero_Factura
				, c1.CODIGO AS CliCod
				, fv.NOMBREDESTINATARIO AS Cliente
				, SUBSTRING(fv.FECHAACTUAL, 1, 4) AS A�o, SUBSTRING(fv.FECHAACTUAL, 5, 2) AS Mes, 
							  CAST(SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4) AS datetime) AS Fecha, 
							  itc2.NOMBRE AS Tipo_Venta, itc3.NOMBRE AS Sucursal, p.CODIGO AS Codigo_Referencia, p.DESCRIPCION AS Descripcion_Referencia, 
							  p.TipoBienCambio AS Tipo_Bien_Cambio, p.Rubro, p.SubRubro, p.Familia, p.Tipo AS Tipo_Referencia, ifv.CANTIDAD2_CANTIDAD * - 1 AS Cantidad, 
							  ifv.TOTAL2_IMPORTE * - 1 AS TotalVentaNeta, 
							  ifv.VALOR2_IMPORTE * ifv.PORCENTAJEBONIFICACION * ifv.CANTIDAD2_CANTIDAD * - 1 AS TotalDescuento, 
							  ISNULL(ud2.PUCosto * ifv.CANTIDAD2_CANTIDAD * - 1, 0) AS Costo, ISNULL(itc1.NOMBRE, '') AS cargo, ciu.NOMBRE AS Ciudad_Cliente, 
							  Pro.NOMBRE AS Provincia_Cliente, cc.NOMBRE AS Centro_Costos, itc4.CODIGO + ' - ' + itc4.NOMBRE AS Tipo_Cliente, 
							  emp.DESCRIPCION AS Vendedor, ud3.TeParticular AS Telefono_particular, '' AS Vendedor_por_Defecto
		FROM         dbo.TRCREDITOVENTA AS fv WITH (nolock) INNER JOIN
							  dbo.ITEMCREDITOVENTA AS ifv WITH (nolock) ON ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID LEFT OUTER JOIN
							  dbo.VP_Referencia_ AS p WITH (nolock) ON p.ID = ifv.REFERENCIA_ID INNER JOIN
							  dbo.UD_ITEMCREDITOVENTA AS ud2 WITH (nolock) ON ud2.ID = ifv.BOEXTENSION_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc1 WITH (nolock) ON itc1.ID = ud2.Cargo_ID LEFT OUTER JOIN
							  dbo.CENTROCOSTOS AS cc WITH (nolock) ON cc.ID = ifv.CENTROCOSTOS_ID INNER JOIN
							  dbo.UD_NOTACREDITOVENTA AS ud1 WITH (nolock) ON ud1.ID = fv.BOEXTENSION_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc2 WITH (nolock) ON itc2.ID = ud1.TipoVenta_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc3 WITH (nolock) ON itc3.ID = ud1.Sucursal_ID LEFT OUTER JOIN
							  dbo.CLIENTE AS c1 ON c1.ID = fv.DESTINATARIO_ID LEFT OUTER JOIN
							  dbo.UD_CLIENTE AS ud3 ON ud3.ID = c1.BOEXTENSION_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc4 WITH (nolock) ON itc4.ID = ud3.TipoCliente_ID LEFT OUTER JOIN
							  dbo.DOMICILIO AS dom ON dom.ID = c1.DOMICILIOFACTURACION_ID LEFT OUTER JOIN
							  dbo.CIUDAD AS ciu ON ciu.ID = dom.CIUDAD_ID LEFT OUTER JOIN
							  dbo.PROVINCIA AS Pro ON Pro.ID = dom.PROVINCIA_ID LEFT OUTER JOIN
							  dbo.EMPLEADO AS emp ON emp.ID = ud1.EmpleadoVendedor_ID
		WHERE     (fv.ESTADO = 'C') AND (fv.FECHAACTUAL >= '20120601')
		UNION ALL
		SELECT     'Nota Debito Venta' AS Tipo_Comprobante
				, fv.NOMBRE AS Comprobante
				, fv.NUMERODOCUMENTO AS Numero_Factura
				, c1.CODIGO AS CliCod
				, fv.NOMBREDESTINATARIO AS Cliente
				, SUBSTRING(fv.FECHAACTUAL, 1, 4) AS A�o
				, SUBSTRING(fv.FECHAACTUAL, 5, 2) AS Mes
				, CAST(SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4) AS datetime) AS Fecha
				, itc2.NOMBRE AS Tipo_Venta, itc3.NOMBRE AS Sucursal, p.CODIGO AS Codigo_Referencia, p.DESCRIPCION AS Descripcion_Referencia, 
							  p.TipoBienCambio AS Tipo_Bien_Cambio, p.Rubro, p.SubRubro, p.Familia, p.Tipo AS Tipo_Referencia, ifv.CANTIDAD2_CANTIDAD AS Cantidad, 
							  ifv.TOTAL2_IMPORTE AS TotalVentaNeta, ifv.VALOR2_IMPORTE * ifv.PORCENTAJEBONIFICACION * ifv.CANTIDAD2_CANTIDAD AS TotalDescuento, 
							  ISNULL(ud2.PUCosto * ifv.CANTIDAD2_CANTIDAD, 0) AS Costo, ISNULL(itc1.NOMBRE, '') AS cargo, ciu.NOMBRE AS Ciudad_Cliente, 
							  Pro.NOMBRE AS Provincia_Cliente, cc.NOMBRE AS Centro_Costos, itc4.CODIGO + ' - ' + itc4.NOMBRE AS Tipo_Cliente, 
							  emp.DESCRIPCION AS Vendedor, ud3.TeParticular AS Telefono_particular, '' AS Vendedor_por_Defecto
		FROM         dbo.TRDEBITOVENTA AS fv WITH (nolock) INNER JOIN
							  dbo.ITEMDEBITOVENTA AS ifv WITH (nolock) ON ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID LEFT OUTER JOIN
							  dbo.VP_Referencia_ AS p WITH (nolock) ON p.ID = ifv.REFERENCIA_ID INNER JOIN
							  dbo.UD_ITEMDEBITOVENTA AS ud2 WITH (nolock) ON ud2.ID = ifv.BOEXTENSION_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc1 WITH (nolock) ON itc1.ID = ud2.Cargo_ID LEFT OUTER JOIN
							  dbo.CENTROCOSTOS AS cc WITH (nolock) ON cc.ID = ifv.CENTROCOSTOS_ID INNER JOIN
							  dbo.UD_NOTADEBITOVENTA AS ud1 WITH (nolock) ON ud1.ID = fv.BOEXTENSION_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc2 WITH (nolock) ON itc2.ID = ud1.TipoVenta_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc3 WITH (nolock) ON itc3.ID = ud1.Sucursal_ID LEFT OUTER JOIN
							  dbo.CLIENTE AS c1 ON c1.ID = fv.DESTINATARIO_ID LEFT OUTER JOIN
							  dbo.UD_CLIENTE AS ud3 ON ud3.ID = c1.BOEXTENSION_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc4 WITH (nolock) ON itc4.ID = ud3.TipoCliente_ID LEFT OUTER JOIN
							  dbo.DOMICILIO AS dom ON dom.ID = c1.DOMICILIOFACTURACION_ID LEFT OUTER JOIN
							  dbo.CIUDAD AS ciu ON ciu.ID = dom.CIUDAD_ID LEFT OUTER JOIN
							  dbo.PROVINCIA AS Pro ON Pro.ID = dom.PROVINCIA_ID LEFT OUTER JOIN
							  dbo.EMPLEADO AS emp ON emp.ID = ud1.EmpleadoVendedor_ID
		WHERE     (fv.ESTADO = 'C') AND (fv.FECHAACTUAL >= '20120601')
		) AS VTA
group by CliCod, Cliente, Vendedor_por_Defecto
HAVING Vendedor_por_Defecto IS NOT NULL AND Vendedor_por_Defecto <> ''
