-- CREA LA CONSULTA DE CUENTAS CORRIENTES [CalipsoReplicado].[dbo].[JCP_VP_CTACTE]
-- ELIMINA LA TABLA SI EXISTE
USE [CalipsoReplicado]
GO
/****** Objeto:  Table [dbo].[PCC03_SDOPTE]    Fecha de la secuencia de comandos: 10/06/2013 10:29:36 ******/
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[JCP_VP_FCVTASREP]') AND type in (N'V'))
DROP VIEW [dbo].[JCP_VP_FCVTASREP]

-- CREA LA NUEVA TABLA
USE [CalipsoReplicado]
GO

CREATE VIEW [dbo].[JCP_VP_FCVTASREP]
AS

SELECT [MARCA]
	  ,[MODELO]
	  ,[SUBMODELO]
	  ,[MOTORTIPO]
	  ,[MOTOR]
	  ,[REFERENCIA_ID]
	  ,[Codigo_Referencia]
	  ,[Descripcion_Referencia]
	  ,SUM([Cantidad]) AS CANT
FROM (
	  SELECT [Tipo_Comprobante]
			  ,[FV_ID]
			  ,[Comprobante]
			  ,[Numero_Factura]
			  ,[ClienteID]
			  ,[ClienteCOD]
			  ,[Cliente]
			  ,[A�o]
			  ,[Mes]
			  ,[Fecha]
			  ,[TVta_COD]
			  ,[Tipo_Venta]
			  ,[Suc_COD]
			  ,[Sucursal]
			  ,[REFERENCIA_ID]
			  ,[Codigo_Referencia]
			  ,[Descripcion_Referencia]
			  ,[Tipo_Bien_Cambio]
			  ,[Rubro]
			  ,[SubRubro]
			  ,[Familia]
			  ,[Tipo_Referencia]
			  ,[Cantidad]
			  ,[TotalVentaNeta]
			  ,[TotalDescuento]
			  ,[TotalCosto]
			  ,[UtilNeta]
			  ,[cargo]
			  ,[Ciudad_Cliente]
			  ,[Provincia_Cliente]
			  ,[CCto_COD]
			  ,[Centro_Costos]
			  ,[Tipo_Cliente]
			  ,[EMPCOD]
			  ,[Vendedor]
			  ,[Telefono_particular]
			  ,[Vendedor_por_Defecto]
			  ,[Saldo]
			  ,[FVUSUARIO]
			  ,[OTRECEPTOR]
			  ,[OTUSUARIO]
			  ,[OTNOMBRE]
			  ,[OTNUM]
			  ,[TIPOTRAB]
			  ,[OTKILOMETROS]
			  ,[OTTELCONTACTO]
			  ,[OTINCIDENTE]
			  ,[OTDIAGNOSTICO]
			  ,[MARCA]
			  ,[MODELO]
			  ,[SUBMODELO]
			  ,[MOTORTIPO]
			  ,[MOTOR]
			  ,[MOTORNUMERO]
			  ,[DOMINIO]
			  ,[FECHAENTREGA]
			  ,[FECHAULTEST]
			  ,[FECHATURNO]
			  ,[FECHAEJECU]
FROM (
		SELECT TOP 100 'Factura Venta RT' AS Tipo_Comprobante
						, fv.ID AS FV_ID
						, fv.NOMBRE AS Comprobante
						, fv.NUMERODOCUMENTO AS Numero_Factura
						, fv.DESTINATARIO_ID AS ClienteID
						, CLI.CODIGO AS ClienteCOD
						, fv.NOMBREDESTINATARIO AS Cliente
						, SUBSTRING(fv.FECHAACTUAL, 1, 4) AS A�o
						, SUBSTRING(fv.FECHAACTUAL, 5, 2) AS Mes
						, CAST(SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4) AS datetime) AS Fecha
						, itc2.CODIGO AS TVta_COD
						, itc2.NOMBRE AS Tipo_Venta
						, itc3.CODIGO AS Suc_COD
						, itc3.NOMBRE AS Sucursal
						, ifv.REFERENCIA_ID AS REFERENCIA_ID
						, p.CODIGO AS Codigo_Referencia
						, p.DESCRIPCION AS Descripcion_Referencia
						, p.TipoBienCambio AS Tipo_Bien_Cambio
						, p.Rubro
						, p.SubRubro
						, p.Familia
						, p.Tipo AS Tipo_Referencia
						, ifv.CANTIDAD2_CANTIDAD AS Cantidad
						, ifv.TOTAL2_IMPORTE AS TotalVentaNeta
						, ifv.VALOR2_IMPORTE * ifv.PORCENTAJEBONIFICACION * ifv.CANTIDAD2_CANTIDAD / 100 AS TotalDescuento
						, ISNULL(ud2.PUCosto * ifv.CANTIDAD2_CANTIDAD * - 1, 0) AS TotalCosto
						, ifv.TOTAL2_IMPORTE - (ifv.VALOR2_IMPORTE * ifv.PORCENTAJEBONIFICACION * ifv.CANTIDAD2_CANTIDAD / 100) - ISNULL(ud2.PUCosto * ifv.CANTIDAD2_CANTIDAD, 0) AS UtilNeta
						, ISNULL(itc1.NOMBRE, '') AS cargo
						, ciu.NOMBRE AS Ciudad_Cliente
						, Pro.NOMBRE AS Provincia_Cliente
						, cc.CODIGO AS CCto_COD
						, cc.NOMBRE AS Centro_Costos
						, itc4.CODIGO + ' - ' + itc4.NOMBRE AS Tipo_Cliente
						, LTRIM(RTRIM(SUBSTRING(emp.DESCRIPCION, 1, CHARINDEX('-', emp.DESCRIPCION, 1) - 2))) AS EMPCOD
					    , CASE WHEN emp.DESCRIPCION IS NULL THEN fv.USUARIO ELSE LTRIM(RTRIM(SUBSTRING(emp.DESCRIPCION, CHARINDEX('-', emp.DESCRIPCION, 1) + 1, LEN(emp.DESCRIPCION)))) END AS Vendedor
					    , ud3.TeParticular AS Telefono_particular
					    , pf.NOMBRE AS Vendedor_por_Defecto
						, CPF.SALDO2_IMPORTE AS Saldo
						, fv.USUARIO AS FVUSUARIO
						, OT.NOMBREORIGINANTE AS OTRECEPTOR
						, OT.USUARIO AS OTUSUARIO
-- OT DATOS
						, OT.NOMBRE AS OTNOMBRE
						, RTRIM(LTRIM(SUBSTRING(OT.NOMBRE, 8, CHARINDEX('- Fe', OT.NOMBRE, 1) - 8))) AS OTNUM
						, TTB.NOMBRE AS TIPOTRAB
						, UDOT.KILOMETROS AS OTKILOMETROS
						, UDOT.TELCONTACTO AS OTTELCONTACTO
						, UDOT.INCIDENTES AS OTINCIDENTE
						, UDOT.DIAGNOSTICO AS OTDIAGNOSTICO
-- DATOS DEL AUTO			
						, CASE WHEN MAR.NOMBRE IS NULL THEN UDP.MARCA ELSE MAR.NOMBRE END AS MARCA
						, CASE WHEN MOD.NOMBRE IS NULL THEN UDP.MODELO ELSE MOD.NOMBRE END AS MODELO
						, CASE WHEN SMD.NOMBRE IS NULL THEN UDP.SUBMODELO ELSE SMD.NOMBRE END AS SUBMODELO
						, CASE WHEN MOT.NOMBRE IS NULL THEN '' ELSE MOT.NOMBRE END AS MOTORTIPO
						, CASE WHEN UDP.NUMEROMOTOR IS NULL THEN '' ELSE SUBSTRING(UDP.NUMEROMOTOR, 1, 3) END AS MOTOR
						, UDP.NUMEROMOTOR AS MOTORNUMERO
						, UDP.DOMINIO AS DOMINIO
-- FECHAS OT
						, OT.FECHAENTREGA AS FECHAENTREGA
						, OT.FECHAULTIMOESTADO AS FECHAULTEST
						, UDOT.FECHAHORATURNO AS FECHATURNO
						, UDOT.FECHAEJECUCION AS FECHAEJECU
		--SELECT TOP 100 NOMBRE, fv.DETALLE, fv.NOTA, *
--		INTO dbo.JCP_BORRAR
		FROM dbo.TRFACTURAVENTA AS fv WITH (nolock) 
				INNER JOIN dbo.ITEMFACTURAVENTA AS ifv WITH (nolock) ON 
						ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID 
				LEFT OUTER JOIN dbo.VP_Referencia_ AS p WITH (nolock) ON 
						p.ID = ifv.REFERENCIA_ID 
				INNER JOIN dbo.UD_ITEMFACTURART AS ud2 WITH (nolock) ON 
						ud2.ID = ifv.BOEXTENSION_ID 
				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc1 WITH (nolock) ON 
						itc1.ID = ud2.Cargo_ID 
				LEFT OUTER JOIN dbo.CENTROCOSTOS AS cc WITH (nolock) ON 
						cc.ID = ifv.CENTROCOSTOS_ID 
				INNER JOIN dbo.UD_FACTURAVENTART AS ud1 WITH (nolock) ON ud1.ID = fv.BOEXTENSION_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc2 WITH (nolock) ON itc2.ID = ud1.TipoVenta_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc3 WITH (nolock) ON itc3.ID = ud1.Sucursal_ID LEFT OUTER JOIN
							  dbo.CLIENTE AS c1 WITH (nolock) ON c1.ID = fv.DESTINATARIO_ID LEFT OUTER JOIN
							  dbo.UD_CLIENTE AS ud3 ON ud3.ID = c1.BOEXTENSION_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc4 WITH (nolock) ON itc4.ID = ud3.TipoCliente_ID LEFT OUTER JOIN
							  dbo.DOMICILIO AS dom WITH (nolock) ON dom.ID = c1.DOMICILIOFACTURACION_ID LEFT OUTER JOIN
							  dbo.CIUDAD AS ciu WITH (nolock) ON ciu.ID = dom.CIUDAD_ID LEFT OUTER JOIN
							  dbo.PROVINCIA AS Pro WITH (nolock) ON Pro.ID = dom.PROVINCIA_ID LEFT OUTER JOIN
							  dbo.EMPLEADO AS emp WITH (nolock) ON emp.ID = ud1.EmpleadoVendedor_ID LEFT OUTER JOIN
							  dbo.VENDEDOR AS vend WITH (nolock) ON vend.ID = c1.OPERADORASOCIADODEFAULT_ID LEFT OUTER JOIN
							  dbo.PERSONAFISICA AS pf WITH (nolock) ON pf.ID = vend.ENTEASOCIADO_ID LEFT OUTER JOIN
							  dbo.CPFACTURA AS CPF WITH (nolock) ON fv.ID = CPF.TRORIGINANTE_ID AND CPF.NIVEL = 1
							  INNER JOIN dbo.V_CLIENTE AS CLI WITH (NOLOCK) ON 
											fv.DESTINATARIO_ID = CLI.ID
				LEFT OUTER JOIN dbo.AGENTEPROCESOPORLOTE APL WITH(NOLOCK) ON 
					APL.ID = FV.GENERADAPOR_ID
				LEFT OUTER JOIN dbo.TRPROCESOPORLOTE TRPPL WITH(NOLOCK) ON 
					APL.TRSORIGEN_ID = TRPPL.BO_PLACE_ID 
						AND 
					APL.RELACIONORIGEN_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8' 
				LEFT OUTER JOIN dbo.TRORDENVENTA OT WITH(NOLOCK) ON 
					OT.ID = TRPPL.TRANSACCION_ID 
						AND 
					RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8' 
				LEFT OUTER JOIN dbo.UD_ORDENTRABAJO UDOT WITH(NOLOCK) ON 
					OT.BOEXTENSION_ID = UDOT.ID
				LEFT OUTER JOIN dbo.PRODUCTO VEH WITH(NOLOCK) ON 
					UDOT.VEHICULO_ID = VEH.ID
				LEFT OUTER JOIN dbo.UD_PRODUCTO UDP WITH(NOLOCK) ON 
					VEH.BOEXTENSION_ID = UDP.ID
				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR MAR WITH(NOLOCK) ON 
					UDP.OMARCA_ID = MAR.ID
				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR MOD WITH(NOLOCK) ON 
					UDP.OMODELO_ID = MOD.ID
				LEFT JOIN ITEMTIPOCLASIFICADOR SMD WITH(NOLOCK) ON 
					UDP.OSubModelo_ID = SMD.ID
				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR MOT WITH(NOLOCK) ON 
					UDP.OMOTOR_ID = MOT.ID
				LEFT OUTER JOIN ITEMTIPOCLASIFICADOR TTB WITH(NOLOCK) ON 
					UDOT.TIPOTRABAJO_ID = TTB.ID
		WHERE (fv.ESTADO = 'C') AND (fv.FECHAACTUAL >= '20090101')
		UNION ALL
		SELECT TOP 100 'Nota Credito Venta' AS Tipo_Comprobante
					, fv.ID AS FV_ID
					, fv.NOMBRE AS Comprobante
					, fv.NUMERODOCUMENTO AS Numero_Factura
					, fv.DESTINATARIO_ID AS ClienteID
					, CLI.CODIGO AS ClienteCOD
					, fv.NOMBREDESTINATARIO AS Cliente
					, SUBSTRING(fv.FECHAACTUAL, 1, 4) AS A�o
					, SUBSTRING(fv.FECHAACTUAL, 5, 2) AS Mes
					, CAST(SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4) AS datetime) AS Fecha
					, itc2.CODIGO AS TVta_COD
					, itc2.NOMBRE AS Tipo_Venta
					, itc3.CODIGO AS Suc_COD
					, itc3.NOMBRE AS Sucursal
					, ifv.REFERENCIA_ID AS REFERENCIA_ID
					, p.CODIGO AS Codigo_Referencia
					, p.DESCRIPCION AS Descripcion_Referencia
					, p.TipoBienCambio AS Tipo_Bien_Cambio
					, p.Rubro
					, p.SubRubro
					, p.Familia
					, p.Tipo AS Tipo_Referencia
					, ifv.CANTIDAD2_CANTIDAD * - 1 AS Cantidad
					, ifv.TOTAL2_IMPORTE * - 1 AS TotalVentaNeta
					, ifv.VALOR2_IMPORTE * ifv.PORCENTAJEBONIFICACION * ifv.CANTIDAD2_CANTIDAD * - 1 / 100 AS TotalDescuento
				    , ISNULL(ud2.PUCosto * ifv.CANTIDAD2_CANTIDAD, 0) AS Costo	--  * - 1
				    , (ifv.TOTAL2_IMPORTE * - 1) - (ifv.VALOR2_IMPORTE * ifv.PORCENTAJEBONIFICACION * ifv.CANTIDAD2_CANTIDAD / 100) - ISNULL(ud2.PUCosto * ifv.CANTIDAD2_CANTIDAD * - 1, 0) AS UtilNeta
				    , ISNULL(itc1.NOMBRE, '') AS cargo, ciu.NOMBRE AS Ciudad_Cliente
					, Pro.NOMBRE AS Provincia_Cliente
					, cc.CODIGO AS CCto_COD
					, cc.NOMBRE AS Centro_Costos
					, itc4.CODIGO + ' - ' + itc4.NOMBRE AS Tipo_Cliente
					, LTRIM(RTRIM(SUBSTRING(emp.DESCRIPCION, 1, CHARINDEX('-', emp.DESCRIPCION, 1) - 2))) AS EMPCOD
				    , CASE WHEN emp.DESCRIPCION IS NULL THEN fv.USUARIO ELSE LTRIM(RTRIM(SUBSTRING(emp.DESCRIPCION, CHARINDEX('-', emp.DESCRIPCION, 1) + 1, LEN(emp.DESCRIPCION)))) END AS Vendedor
				    , ud3.TeParticular AS Telefono_particular
					, '' AS Vendedor_por_Defecto
					, CPC.SALDO2_IMPORTE AS Saldo
				    , fv.USUARIO AS FVUSUARIO
					, NULL AS OTRECEPTOR
					, NULL AS OTUSUARIO
-- OT DATOS
					, NULL AS OTNOMBRE
					, NULL AS OTNUM
					, NULL AS TIPOTRAB
					, NULL AS OTKILOMETROS
					, NULL AS OTTELCONTACTO
					, NULL AS OTINCIDENTE
					, NULL AS OTDIAGNOSTICO
-- DATOS DEL AUTO			
					, NULL AS MARCA
					, NULL AS MODELO
					, NULL AS SUBMODELO
					, NULL AS MOTORTIPO
					, NULL AS MOTOR
					, NULL AS MOTORNUMERO
					, NULL AS DOMINIO
-- FECHAS OT
					, NULL AS FECHAENTREGA
					, NULL AS FECHAULTEST
					, NULL AS FECHATURNO
					, NULL AS FECHAEJECU
		FROM dbo.TRCREDITOVENTA AS fv WITH (nolock) 
				INNER JOIN dbo.ITEMCREDITOVENTA AS ifv WITH (nolock) ON 
					ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID 
				LEFT OUTER JOIN dbo.VP_Referencia_ AS p WITH (nolock) ON 
					p.ID = ifv.REFERENCIA_ID 
				INNER JOIN dbo.UD_ITEMCREDITOVENTA AS ud2 WITH (nolock) ON 
					ud2.ID = ifv.BOEXTENSION_ID 
				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc1 WITH (nolock) ON 
					itc1.ID = ud2.Cargo_ID 
				LEFT OUTER JOIN dbo.CENTROCOSTOS AS cc WITH (nolock) ON 
					cc.ID = ifv.CENTROCOSTOS_ID 
				INNER JOIN dbo.UD_NOTACREDITOVENTA AS ud1 WITH (nolock) ON 
					ud1.ID = fv.BOEXTENSION_ID 
				LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc2 WITH (nolock) ON itc2.ID = ud1.TipoVenta_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc3 WITH (nolock) ON itc3.ID = ud1.Sucursal_ID LEFT OUTER JOIN
							  dbo.CLIENTE AS c1 WITH (nolock) ON c1.ID = fv.DESTINATARIO_ID LEFT OUTER JOIN
							  dbo.UD_CLIENTE AS ud3 WITH (nolock) ON ud3.ID = c1.BOEXTENSION_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc4 WITH (nolock) ON itc4.ID = ud3.TipoCliente_ID LEFT OUTER JOIN
							  dbo.DOMICILIO AS dom WITH (nolock) ON dom.ID = c1.DOMICILIOFACTURACION_ID LEFT OUTER JOIN
							  dbo.CIUDAD AS ciu WITH (nolock) ON ciu.ID = dom.CIUDAD_ID LEFT OUTER JOIN
							  dbo.PROVINCIA AS Pro WITH (nolock) ON Pro.ID = dom.PROVINCIA_ID LEFT OUTER JOIN
							  dbo.EMPLEADO AS emp WITH (nolock) ON emp.ID = ud1.EmpleadoVendedor_ID LEFT OUTER JOIN
							  dbo.CPCREDITO AS CPC WITH (nolock) ON fv.ID = CPC.TRORIGINANTE_ID AND CPC.NIVEL = 1
								INNER JOIN dbo.V_CLIENTE AS CLI WITH (NOLOCK) ON 
											fv.DESTINATARIO_ID = CLI.ID
--				LEFT OUTER JOIN dbo.AGENTEPROCESOPORLOTE APL WITH(NOLOCK) ON 
--					APL.ID = FV.GENERADAPOR_ID
--				LEFT OUTER JOIN dbo.TRPROCESOPORLOTE TRPPL WITH(NOLOCK) ON 
--					APL.TRSORIGEN_ID = TRPPL.BO_PLACE_ID 
--						AND 
--					APL.RELACIONORIGEN_ID = 'CC746170-CEEC-47ED-925E-2F3234249705' 
--				LEFT OUTER JOIN dbo.TRORDENVENTA OT WITH(NOLOCK) ON 
--					OT.ID = TRPPL.TRANSACCION_ID 
--						AND 
--					RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8' 
--				LEFT OUTER JOIN dbo.UD_ORDENTRABAJO UDOT WITH(NOLOCK) ON 
--					OT.BOEXTENSION_ID = UDOT.ID
--				LEFT OUTER JOIN dbo.PRODUCTO VEH WITH(NOLOCK) ON 
--					UDOT.VEHICULO_ID = VEH.ID
--				LEFT OUTER JOIN dbo.UD_PRODUCTO UDP WITH(NOLOCK) ON 
--					VEH.BOEXTENSION_ID = UDP.ID
--				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR MAR WITH(NOLOCK) ON 
--					UDP.OMARCA_ID = MAR.ID
--				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR MOD WITH(NOLOCK) ON 
--					UDP.OMODELO_ID = MOD.ID
--				LEFT JOIN ITEMTIPOCLASIFICADOR SMD WITH(NOLOCK) ON 
--					UDP.OSubModelo_ID = SMD.ID
--				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR MOT WITH(NOLOCK) ON 
--					UDP.OMOTOR_ID = MOT.ID
--				LEFT OUTER JOIN ITEMTIPOCLASIFICADOR TTB WITH(NOLOCK) ON 
--					UDOT.TIPOTRABAJO_ID = TTB.ID
		WHERE     (fv.ESTADO = 'C') AND (fv.FECHAACTUAL >= '20090101')
		UNION ALL
		SELECT TOP 100 'Nota Debito Venta' AS Tipo_Comprobante
					, fv.ID AS FV_ID, fv.NOMBRE AS Comprobante
					, fv.NUMERODOCUMENTO AS Numero_Factura
					, fv.DESTINATARIO_ID AS ClienteID
					, CLI.CODIGO AS ClienteCOD
					, fv.NOMBREDESTINATARIO AS Cliente
					, SUBSTRING(fv.FECHAACTUAL, 1, 4) AS A�o
					, SUBSTRING(fv.FECHAACTUAL, 5, 2) AS Mes
					, CAST(SUBSTRING(fv.FECHAACTUAL, 7, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 5, 2) + '/' + SUBSTRING(fv.FECHAACTUAL, 1, 4) AS datetime) AS Fecha
					, itc2.CODIGO AS TVta_COD
					, itc2.NOMBRE AS Tipo_Venta
					, itc3.CODIGO AS Suc_COD
					, itc3.NOMBRE AS Sucursal
					, ifv.REFERENCIA_ID AS REFERENCIA_ID
					, p.CODIGO AS Codigo_Referencia
					, p.DESCRIPCION AS Descripcion_Referencia
					, p.TipoBienCambio AS Tipo_Bien_Cambio
					, p.Rubro
					, p.SubRubro
					, p.Familia
					, p.Tipo AS Tipo_Referencia
					, ifv.CANTIDAD2_CANTIDAD AS Cantidad
					, ifv.TOTAL2_IMPORTE AS TotalVentaNeta
					, ifv.VALOR2_IMPORTE * ifv.PORCENTAJEBONIFICACION * ifv.CANTIDAD2_CANTIDAD / 100 AS TotalDescuento
					, ISNULL(ud2.PUCosto * ifv.CANTIDAD2_CANTIDAD, 0) AS Costo
					, ifv.TOTAL2_IMPORTE - (ifv.VALOR2_IMPORTE * ifv.PORCENTAJEBONIFICACION * ifv.CANTIDAD2_CANTIDAD / 100) - ISNULL(ud2.PUCosto * ifv.CANTIDAD2_CANTIDAD, 0) AS UtilNeta
					, ISNULL(itc1.NOMBRE, '') AS cargo
					, ciu.NOMBRE AS Ciudad_Cliente
					, Pro.NOMBRE AS Provincia_Cliente
					, cc.CODIGO AS CCto_COD
					, cc.NOMBRE AS Centro_Costos
					, itc4.CODIGO + ' - ' + itc4.NOMBRE AS Tipo_Cliente
					, LTRIM(RTRIM(SUBSTRING(emp.DESCRIPCION, 1, CHARINDEX('-', emp.DESCRIPCION, 1) - 2))) AS EMPCOD
					, CASE WHEN emp.DESCRIPCION IS NULL THEN fv.USUARIO ELSE LTRIM(RTRIM(SUBSTRING(emp.DESCRIPCION, CHARINDEX('-', emp.DESCRIPCION, 1) + 1, LEN(emp.DESCRIPCION)))) END AS Vendedor
					, ud3.TeParticular AS Telefono_particular
					, '' AS Vendedor_por_Defecto
					, CPD.SALDO2_IMPORTE AS Saldo
					, fv.USUARIO
					, NULL AS OTRECEPTOR
					, NULL AS OTUSUARIO
-- OT DATOS
					, NULL AS OTNOMBRE
					, NULL AS OTNUM
					, NULL AS TIPOTRAB
					, NULL AS OTKILOMETROS
					, NULL AS OTTELCONTACTO
					, NULL AS OTINCIDENTE
					, NULL AS OTDIAGNOSTICO
-- DATOS DEL AUTO			
					, NULL AS MARCA
					, NULL AS MODELO
					, NULL AS SUBMODELO
					, NULL AS MOTORTIPO
					, NULL AS MOTOR
					, NULL AS MOTORNUMERO
					, NULL AS DOMINIO
-- FECHAS OT
					, NULL AS FECHAENTREGA
					, NULL AS FECHAULTEST
					, NULL AS FECHATURNO
					, NULL AS FECHAEJECU
		FROM dbo.TRDEBITOVENTA AS fv WITH (nolock) 
				INNER JOIN dbo.ITEMDEBITOVENTA AS ifv WITH (nolock) ON 
					ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID 
				LEFT OUTER JOIN dbo.VP_Referencia_ AS p WITH (nolock) ON 
					p.ID = ifv.REFERENCIA_ID 
				INNER JOIN dbo.UD_ITEMDEBITOVENTA AS ud2 WITH (nolock) ON 
					ud2.ID = ifv.BOEXTENSION_ID 
				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc1 WITH (nolock) ON 
					itc1.ID = ud2.Cargo_ID 
				LEFT OUTER JOIN dbo.CENTROCOSTOS AS cc WITH (nolock) ON 
					cc.ID = ifv.CENTROCOSTOS_ID 
				INNER JOIN dbo.UD_NOTADEBITOVENTA AS ud1 WITH (nolock) ON 
					ud1.ID = fv.BOEXTENSION_ID 
				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc2 WITH (nolock) ON 
					itc2.ID = ud1.TipoVenta_ID 
				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR AS itc3 WITH (nolock) ON 
					itc3.ID = ud1.Sucursal_ID 
				LEFT OUTER JOIN
							  dbo.CLIENTE AS c1 WITH (nolock) ON c1.ID = fv.DESTINATARIO_ID LEFT OUTER JOIN
							  dbo.UD_CLIENTE AS ud3 WITH (nolock) ON ud3.ID = c1.BOEXTENSION_ID LEFT OUTER JOIN
							  dbo.ITEMTIPOCLASIFICADOR AS itc4 WITH (nolock) ON itc4.ID = ud3.TipoCliente_ID LEFT OUTER JOIN
							  dbo.DOMICILIO AS dom WITH (nolock) ON dom.ID = c1.DOMICILIOFACTURACION_ID LEFT OUTER JOIN
							  dbo.CIUDAD AS ciu WITH (nolock) ON ciu.ID = dom.CIUDAD_ID LEFT OUTER JOIN
							  dbo.PROVINCIA AS Pro WITH (nolock) ON Pro.ID = dom.PROVINCIA_ID LEFT OUTER JOIN
							  dbo.EMPLEADO AS emp WITH (nolock) ON emp.ID = ud1.EmpleadoVendedor_ID LEFT OUTER JOIN
							  dbo.CPDEBITO AS CPD WITH (nolock) ON fv.ID = CPD.TRORIGINANTE_ID AND CPD.NIVEL = 1
								INNER JOIN dbo.V_CLIENTE AS CLI WITH (NOLOCK) ON 
											fv.DESTINATARIO_ID = CLI.ID
--				LEFT OUTER JOIN dbo.AGENTEPROCESOPORLOTE APL WITH(NOLOCK) ON 
--					APL.ID = FV.GENERADAPOR_ID
--				LEFT OUTER JOIN dbo.TRPROCESOPORLOTE TRPPL WITH(NOLOCK) ON 
--					APL.TRSORIGEN_ID = TRPPL.BO_PLACE_ID 
--						AND 
--					APL.RELACIONORIGEN_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8' 
--				LEFT OUTER JOIN dbo.TRORDENVENTA OT WITH(NOLOCK) ON 
--					OT.ID = TRPPL.TRANSACCION_ID 
--						AND 
--					RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8' 
--				LEFT OUTER JOIN dbo.UD_ORDENTRABAJO UDOT WITH(NOLOCK) ON 
--					OT.BOEXTENSION_ID = UDOT.ID
--				LEFT OUTER JOIN dbo.PRODUCTO VEH WITH(NOLOCK) ON 
--					UDOT.VEHICULO_ID = VEH.ID
--				LEFT OUTER JOIN dbo.UD_PRODUCTO UDP WITH(NOLOCK) ON 
--					VEH.BOEXTENSION_ID = UDP.ID
--				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR MAR WITH(NOLOCK) ON 
--					UDP.OMARCA_ID = MAR.ID
--				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR MOD WITH(NOLOCK) ON 
--					UDP.OMODELO_ID = MOD.ID
--				LEFT JOIN ITEMTIPOCLASIFICADOR SMD WITH(NOLOCK) ON 
--					UDP.OSubModelo_ID = SMD.ID
--				LEFT OUTER JOIN dbo.ITEMTIPOCLASIFICADOR MOT WITH(NOLOCK) ON 
--					UDP.OMOTOR_ID = MOT.ID
--				LEFT OUTER JOIN ITEMTIPOCLASIFICADOR TTB WITH(NOLOCK) ON 
--					UDOT.TIPOTRABAJO_ID = TTB.ID
		WHERE     (fv.ESTADO = 'C') AND (fv.FECHAACTUAL >= '20090101')
		) AS FCVTA
	  ) AS FC
WHERE [Rubro] = '01 - Repuestos'
	AND ([MARCA] = 'Renault' OR [MARCA] = 'Nissan')
GROUP BY [FV010_MARCA]
	  ,[FV010_MODELO]
	  ,[FV010_SUBMODELO]
	  ,[FV010_REFERID]
	  ,[FV010_REFERCOD]
	  ,[FV010_REFERDESC]




---- VERIFICA EL DESCUENTO
--select top 1000 ifv.*, NOMBRE, fv.DETALLE, fv.NOTA, *
--FROM         dbo.TRFACTURAVENTA AS fv WITH (nolock) 
--				INNER JOIN dbo.ITEMFACTURAVENTA AS ifv WITH (nolock) ON 
--					fv.ITEMSTRANSACCION_ID = ifv.BO_PLACE_ID 
--WHERE FV.ID = '0AD79C69-56E1-4996-86B9-001FB517560E'



















--
--SELECT TOP 100 LTRIM(RTRIM(SUBSTRING(emp.DESCRIPCION, 1, CHARINDEX('-', emp.DESCRIPCION, 1) - 2))) AS EMPCOD
--			, CASE WHEN emp.DESCRIPCION IS NULL THEN fv.USUARIO ELSE LTRIM(RTRIM(SUBSTRING(emp.DESCRIPCION, CHARINDEX('-', emp.DESCRIPCION, 1) + 1, LEN(emp.DESCRIPCION)))) END AS EMPNOMB
--FROM         dbo.TRFACTURAVENTA AS fv WITH (nolock) INNER JOIN
--                      dbo.ITEMFACTURAVENTA AS ifv WITH (nolock) ON ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID LEFT OUTER JOIN
--                      dbo.VP_Referencia_ AS p WITH (nolock) ON p.ID = ifv.REFERENCIA_ID INNER JOIN
--                      dbo.UD_ITEMFACTURART AS ud2 WITH (nolock) ON ud2.ID = ifv.BOEXTENSION_ID LEFT OUTER JOIN
--                      dbo.ITEMTIPOCLASIFICADOR AS itc1 WITH (nolock) ON itc1.ID = ud2.Cargo_ID LEFT OUTER JOIN
--                      dbo.CENTROCOSTOS AS cc WITH (nolock) ON cc.ID = ifv.CENTROCOSTOS_ID INNER JOIN
--                      dbo.UD_FACTURAVENTART AS ud1 WITH (nolock) ON ud1.ID = fv.BOEXTENSION_ID LEFT OUTER JOIN
--                      dbo.ITEMTIPOCLASIFICADOR AS itc2 WITH (nolock) ON itc2.ID = ud1.TipoVenta_ID LEFT OUTER JOIN
--                      dbo.ITEMTIPOCLASIFICADOR AS itc3 WITH (nolock) ON itc3.ID = ud1.Sucursal_ID LEFT OUTER JOIN
--                      dbo.CLIENTE AS c1 WITH (nolock) ON c1.ID = fv.DESTINATARIO_ID LEFT OUTER JOIN
--                      dbo.UD_CLIENTE AS ud3 ON ud3.ID = c1.BOEXTENSION_ID LEFT OUTER JOIN
--                      dbo.ITEMTIPOCLASIFICADOR AS itc4 WITH (nolock) ON itc4.ID = ud3.TipoCliente_ID LEFT OUTER JOIN
--                      dbo.DOMICILIO AS dom WITH (nolock) ON dom.ID = c1.DOMICILIOFACTURACION_ID LEFT OUTER JOIN
--                      dbo.CIUDAD AS ciu WITH (nolock) ON ciu.ID = dom.CIUDAD_ID LEFT OUTER JOIN
--                      dbo.PROVINCIA AS Pro WITH (nolock) ON Pro.ID = dom.PROVINCIA_ID LEFT OUTER JOIN
--                      dbo.EMPLEADO AS emp WITH (nolock) ON emp.ID = ud1.EmpleadoVendedor_ID LEFT OUTER JOIN
--                      dbo.VENDEDOR AS vend WITH (nolock) ON vend.ID = c1.OPERADORASOCIADODEFAULT_ID LEFT OUTER JOIN
--                      dbo.PERSONAFISICA AS pf WITH (nolock) ON pf.ID = vend.ENTEASOCIADO_ID LEFT OUTER JOIN
--                      dbo.CPFACTURA AS CPF WITH (nolock) ON fv.ID = CPF.TRORIGINANTE_ID AND CPF.NIVEL = 1
--					  INNER JOIN dbo.V_CLIENTE AS CLI WITH (NOLOCK) ON 
--									fv.DESTINATARIO_ID = CLI.ID
--WHERE     (fv.ESTADO = 'C') AND (fv.FECHAACTUAL >= '20120601') AND emp.CODIGO = 28271653
--
--
--28271653 - GUIGNARD DANIEL