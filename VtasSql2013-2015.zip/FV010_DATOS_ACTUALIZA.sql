-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 1
-- ###################################################################################################################################
DECLARE @NUEVOIDACT AS NVARCHAR(36) 
DECLARE @PROCNUM AS NUMERIC(18,0)

-- GENERA EL CODIGO PARA ESTE PROCESO, ESTO PERMITE QUE EN CADA ETAPA SEPARADA CARGUE EL MISMO CODIGO
-- PRIMERO BORRA EL CODIGO DEL PROCESO, ES POR LAS DUDAS SI HUBIERE
DELETE FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WHERE [GRL098_PROC] = 'FVTA_ACT'
INSERT INTO [PVTWEB].[dbo].[GRL098_PROCLAVE]
           ([GRL098_PROC]
           ,[GRL098_PROCNUM])
       SELECT 'FVTA_ACT', REPLACE(REPLACE(REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 120), '-', ''), ':', ''), ' ', '')

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'FVTA_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO


INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC]              , [GRL099_FECINIC]                , [GRL099_FECFIN])
	 SELECT  @NUEVOIDACT   , 'FVTA_ACT'   , 1                 , @PROCNUM      , 'FVTA_IMPDAT'   , 'FVTA_DATBORR'  , '[FV010_FVTA]'  , 'Elimina datos de [FV010_FVTA]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
DELETE FROM [PVTWEB].[dbo].[FV010_FVTA]
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 1
-- ###################################################################################################################################


-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 2
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'FVTA_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'FVTA_ACT', 2, @PROCNUM, 'FVTA_IMPDAT', 'FVTA_DATIMP', '[FV010_FVTA]', 'Importa datos de [FV010_FVTA]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- LUEGO IMPORTA LOS DATOS COMPLETOS
INSERT INTO [PVTWEB].[dbo].[FV010_FVTA]
           ([FV010_CTETIPO]
           ,[FV010_FVID]
           ,[FV010_CTEDET]
           ,[FV010_FCNUM]
           ,[FV010_CLIID]
           ,[FV010_CTACOD]
           ,[FV010_CLINOMB]
           ,[FV010_FCANO]
           ,[FV010_FCMES]
           ,[FV010_FCFECHA]
           ,[FV010_VTATIPO_COD]
           ,[FV010_VTATIPO]
           ,[FV010_SUC_COD]
           ,[FV010_SUCURSAL]
           ,[FV010_REFERID]
           ,[FV010_REFERCOD]
           ,[FV010_REFERDESC]
           ,[FV010_REFERTIPO]
           ,[FV010_REFERRUBRO]
           ,[FV010_REFERSUBRUBRO]
           ,[FV010_REFERFLIA]
           ,[FV010_SSoPROD]
           ,[FV010_FCCANTIDAD]
           ,[FV010_FCTOTVTANETA]
           ,[FV010_FCTOTDTO]
           ,[FV010_FCTOTCOSTO]
           ,[FV010_FCUTILNET]
           ,[FV010_FCCARGO]
           ,[FV010_CLICIUDAD]
           ,[FV010_CLIPROV]
           ,[FV010_CCTO_COD]
		   ,[FV010_CCTO_CGEST]
           ,[FV010_CTROCTO]
           ,[FV010_CLITIPO]
           ,[FV010_USUARIO]
           ,[FV010_EMPCOD]
           ,[FV010_EMPNOMB]
           ,[FV010_CLITELPART]
           ,[FV010_VENDxDEF]
           ,[FV010_FCSALDO]
           ,[FV010_OTRECEPTOR]
           ,[FV010_OTUSUARIO]
           ,[FV010_OTNUMFEC]
           ,[FV010_OTNUM]
           ,[FV010_TIPOTRAB]
           ,[FV010_OTKILOMET]
           ,[FV010_OTTELCONT]
           ,[FV010_OTINCID]
           ,[FV010_OTDIAGN]
           ,[FV010_MARCA]
           ,[FV010_MODELO]
           ,[FV010_SUBMODELO]
           ,[FV010_MOTORTIPO]
           ,[FV010_MOTOR]
           ,[FV010_MOTORNUM]
           ,[FV010_DOMINIO]
           ,[FV010_FECHAENTREGA]
           ,[FV010_FECHAULTMEST]
           ,[FV010_FECHAHORATURN]
           ,[FV010_FECHAEJECUCION]
--           ,[FV010_CCABRCOD]
			)
     SELECT [Tipo_Comprobante]
			  ,[FV_ID]
			  ,[Comprobante]
			  ,[Numero_Factura]
			  ,[ClienteID]
			  ,[ClienteCOD]
			  ,[Cliente]
			  ,[A�o]
			  ,[Mes]
			  ,[Fecha]
			  ,[TVta_COD]
			  ,[Tipo_Venta]
			  ,[Suc_COD]
			  ,[Sucursal]
			  ,[REFERENCIA_ID]
			  ,[Codigo_Referencia]
			  ,[Descripcion_Referencia]
			  ,[Tipo_Bien_Cambio]
			  ,[Rubro]
			  ,[SubRubro]
			  ,[Familia]
			  ,[Tipo_Referencia]
			  ,[Cantidad]
			  ,[TotalVentaNeta]
			  ,[TotalDescuento]
			  ,[TotalCosto]
			  ,[UtilNeta]
			  ,[cargo]
			  ,[Ciudad_Cliente]
			  ,[Provincia_Cliente]
			  ,[CCto_COD]
			  ,[CCto_COD] AS CCTOGEST
			  ,[Centro_Costos]
			  ,[Tipo_Cliente]
			  ,[FVUSUARIO]
			  ,[EMPCOD]
			  ,[Vendedor]
			  ,[Telefono_particular]
			  ,[Vendedor_por_Defecto]
			  ,[Saldo]
			  ,[OTRECEPTOR]
			  ,[OTUSUARIO]
			  ,[OTNOMBRE]
			  ,[OTNUM]
			  ,[TIPOTRAB]
			  ,[OTKILOMETROS]
			  ,[OTTELCONTACTO]
			  ,[OTINCIDENTE]
			  ,[OTDIAGNOSTICO]
			  ,[MARCA]
			  ,[MODELO]
			  ,[SUBMODELO]
			  ,[MOTORTIPO]
			  ,[MOTOR]
			  ,[MOTORNUMERO]
			  ,[DOMINIO]
			  ,[FECHAENTREGA]
			  ,[FECHAULTEST]
			  ,[FECHATURNO]
			  ,[FECHAEJECU]
		  FROM [SYS-REPLICA].[CalipsoReplicado].[dbo].[JCP_VP_FCVTASREP] WITH (NOLOCK)
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 2
-- ###################################################################################################################################


-- TAMANOS DE LOS CAMPOS
--SELECT MAX(LEN([Tipo_Comprobante])) AS TIPCOMP
--			  ,MAX(LEN([FV_ID])) AS FVID
--			  ,MAX(LEN([Comprobante])) AS COMPR
--			  ,MAX(LEN([Numero_Factura])) AS NUMFAC
--			  ,MAX(LEN([ClienteID])) AS CLIID
--			  ,MAX(LEN([ClienteCOD])) AS CLICOD
--			  ,MAX(LEN([Cliente])) AS CLIENTE
--			  ,MAX(LEN([A�o])) AS ANO
--			  ,MAX(LEN([Mes])) AS MES
--			  ,MAX(LEN([Fecha])) AS FECHA
--			  ,MAX(LEN([TVta_COD])) AS TVTACOD
--			  ,MAX(LEN([Tipo_Venta])) AS TIPVENTA
--			  ,MAX(LEN([Suc_COD])) AS SUCCOD
--			  ,MAX(LEN([Sucursal])) AS SUCURSAL
--			  ,MAX(LEN([REFERENCIA_ID])) AS REFID
--			  ,MAX(LEN([Codigo_Referencia])) AS REFCOD
--			  ,MAX(LEN([Descripcion_Referencia])) AS REFDESC
--			  ,MAX(LEN([Tipo_Bien_Cambio])) AS TIPBIENCBIO
--			  ,MAX(LEN([Rubro])) AS RUBRO
--			  ,MAX(LEN([SubRubro])) AS SUBRUB
--			  ,MAX(LEN([Familia])) AS FLIA
--			  ,MAX(LEN([Tipo_Referencia])) AS TIPREF
--			  ,MAX(LEN([Cantidad])) AS CANT
--			  ,MAX(LEN([TotalVentaNeta])) AS TOTVTANETA
--			  ,MAX(LEN([TotalDescuento])) AS TOTDTO
--			  ,MAX(LEN([TotalCosto])) AS TOTCOSTO
--			  ,MAX(LEN([UtilNeta])) AS UTILNETA
--			  ,MAX(LEN([cargo])) AS CARGO
--			  ,MAX(LEN([Ciudad_Cliente])) AS CLICIUD
--			  ,MAX(LEN([Provincia_Cliente])) AS CLIPROV
--			  ,MAX(LEN([CCto_COD])) AS CTROCTO
--			  ,MAX(LEN([Centro_Costos])) AS CENTROCOSTO
--			  ,MAX(LEN([Tipo_Cliente])) AS CLITIPO
--			  ,MAX(LEN([FVUSUARIO])) AS FVUSUARIO
--			  ,MAX(LEN([EMPCOD])) AS EMPCOD
--			  ,MAX(LEN([Vendedor])) AS VENDED
--			  ,MAX(LEN([Telefono_particular])) AS TELPART
--			  ,MAX(LEN([Vendedor_por_Defecto])) AS VENDXdEF
--			  ,MAX(LEN([Saldo])) AS SALDO
--			  ,MAX(LEN([OTRECEPTOR])) AS OTRECEP
--			  ,MAX(LEN([OTUSUARIO])) AS OTUSUAR
--			  ,MAX(LEN([OTNOMBRE])) AS OTNOMB
--			  ,MAX(LEN([OTNUM])) AS OTNUME
--			  ,MAX(LEN([TIPOTRAB])) AS TIPOTRAB
--			  ,MAX(LEN([OTKILOMETROS])) AS OTKILOM
--			  ,MAX(LEN([OTTELCONTACTO])) AS OTTELCONT
----			  ,MAX(LEN([OTINCIDENTE])) AS OTINCID
----			  ,MAX(LEN([OTDIAGNOSTICO])) AS OTDIAGNO
--			  ,MAX(LEN([MARCA])) AS MARCA
--			  ,MAX(LEN([MODELO])) AS MODEL
--			  ,MAX(LEN([SUBMODELO])) AS SUBMODEL
--			  ,MAX(LEN([MOTORTIPO])) AS MOTORTIPO
--			  ,MAX(LEN([MOTOR])) AS MOTOR
--			  ,MAX(LEN([MOTORNUMERO])) AS MOTORNUM
--			  ,MAX(LEN([DOMINIO])) AS DOMIN
--			  ,MAX(LEN([FECHAENTREGA])) AS FECHENTRE
--			  ,MAX(LEN([FECHAULTEST])) AS FECHULTEST
--			  ,MAX(LEN([FECHATURNO])) AS FECHAtURNO
--			  ,MAX(LEN([FECHAEJECU])) AS FECHAEJEC
--		  FROM [SYS-REPLICA].[CalipsoReplicado].[dbo].[JCP_VP_FCVTASREP] WITH (NOLOCK)


-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 3  -- ACTUALIZA EL CENTRO DE COSTO DE GESTI�N - ESTE ESTA CORREGIDO DE LOS PROBLEMAS QUE PUEDEN HABER HABIDO EN EL SISTEMA
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)
-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'FVTA_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'FVTA_ACT', 3, @PROCNUM, 'ACT_TABLAS', 'ACT_CTROCTOS', '[GRL032_CCTOVTATIPO]', 'Act CtroCtos [GRL032_CCTOVTATIPO]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

-- TABLA [GRL032_CCTOVTATIPO]
-- CARGA LA TABLA CENTRO DE COSTOS - TIPOS DE VENTAS - LOS C�DIGOS QUE FALTAN
INSERT INTO [PVTWEB].[dbo].[GRL032_CCTOVTATIPO]
           ([GRL032_CCTO_COD]
           ,[GRL032_CTROCTO]
           ,[GRL032_VTATIPO_COD]
           ,[GRL032_VTATIPO]
--           ,[GRL032_CCTOCODGEST]
			)
				SELECT [FV010_CCTO_COD], [FV010_CTROCTO], [FV010_VTATIPO_COD], [FV010_VTATIPO]
				FROM (
						SELECT [FV010_CCTO_COD], [FV010_CTROCTO], [FV010_VTATIPO_COD], [FV010_VTATIPO]
						--SELECT CCTO, CCTIPVTA, COUNT(DISTINCT [FV010_FVID]) AS CANTFACT, COUNT(*) AS CANTREG,  SUM([FV010_FCTOTVTANETA]) AS VTANETTOT
						FROM (SELECT *, CAST([FV010_CCTO_COD] AS NVARCHAR(20)) AS CCTO, [FV010_VTATIPO] AS CCTIPVTA
								FROM [PVTWEB].[dbo].[FV010_FVTA] WITH(NOLOCK) 
							 ) AS FV
						GROUP BY [FV010_CCTO_COD], [FV010_CTROCTO], [FV010_VTATIPO_COD], [FV010_VTATIPO]
						) AS FVCCT
						LEFT OUTER JOIN [PVTWEB].[dbo].[GRL032_CCTOVTATIPO] AS GCT ON
							FVCCT.[FV010_CCTO_COD] = GCT.[GRL032_CCTO_COD]
								AND
							FVCCT.[FV010_VTATIPO_COD] = GCT.[GRL032_VTATIPO_COD]
				WHERE GCT.[GRL032_CCTO_COD] IS NULL
				ORDER BY [FV010_CCTO_COD], [FV010_CTROCTO], [FV010_VTATIPO_COD], [FV010_VTATIPO]

---- LISTA LOS CENTRO DE COSTOS QUE NO TIENEN UN CENTRO DE COSTO DE GESTI�N
--SELECT TOP 1000 *
--FROM [PVTWEB].[dbo].[GRL032_CCTOVTATIPO]
--WHERE [GRL032_CCTOCODGEST] IS NULL

-- ACTUALIZA el ctro ctos de gesti�n, seg�n la tabla GRL032_CCTOVTATIPO
UPDATE [PVTWEB].[dbo].[FV010_FVTA]
	SET [FV010_CCTO_CGEST] = [GRL032_CCTOCODGEST]
		FROM [PVTWEB].[dbo].[FV010_FVTA] AS FV WITH(NOLOCK) 
			INNER JOIN (SELECT *
						FROM [PVTWEB].[dbo].[GRL032_CCTOVTATIPO] WITH(NOLOCK)
						) AS VFCT  ON
				FV.[FV010_CCTO_COD] = VFCT.[GRL032_CCTO_COD]
					AND
				FV.[FV010_VTATIPO_COD] = VFCT.[GRL032_VTATIPO_COD]

-- TABLA [GRL030_ABRDESC]
-- CARGA EL CENTRO DE COSTOS A LA TABLA GRL030_ABRDESC
INSERT INTO [PVTWEB].[dbo].[GRL030_ABRDESC]
           ([GRL030_CODIGO]
           ,[GRL030_DESCRIPC]
           ,[GRL030_ABRTIPO])
				SELECT [FV010_CCTO_COD], [FV010_CTROCTO], 'CTRO CTO' AS [ABRTIPO]
				FROM (
						SELECT [FV010_CCTO_COD], [FV010_CTROCTO]
						FROM [PVTWEB].[dbo].[FV010_FVTA] WITH(NOLOCK) 
						GROUP BY [FV010_CCTO_COD], [FV010_CTROCTO]
						) AS FVCCT
						LEFT OUTER JOIN 
									(SELECT [GRL030_CODIGO]
									 FROM [PVTWEB].[dbo].[GRL030_ABRDESC] WITH(NOLOCK) 
									 WHERE GRL030_ABRTIPO = 'CTRO CTO') AS CTA ON
							FVCCT.[FV010_CCTO_COD] = CTA.[GRL030_CODIGO]
				WHERE CTA.[GRL030_CODIGO] IS NULL
				ORDER BY [FV010_CCTO_COD]

-- ACTUALIZA el ctro ctos ABREVIADOS, seg�n la tabla [FV010_FVTA], vinculo Centro de Costos de Gesti�n
UPDATE [PVTWEB].[dbo].[FV010_FVTA]
	SET [FV010_CCTODESABR] = CTROCTODESABR
		, [FV010_CCTOABR] = CTROCTOABR
		, [FV010_CCABRCOD] = CCABRCOD
		, [FV010_CCAC3] = CCAC3
		, [FV010_MARCAABR] = MARCA
FROM [PVTWEB].[dbo].[FV010_FVTA] AS FV WITH (NOLOCK) 
			LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS CTROCTOCODABR
									,[GRL030_DESCRIPC] AS CTROCTODESABR
									,[GRL030_DESCABR] AS CTROCTOABR
									,[GRL030_AGR01] AS CCABRCOD
									,LEFT([GRL030_AGR01],3) AS CCAC3
									,CASE WHEN [GRL030_DESCRIPC] LIKE '%Nissan%' THEN 'NISSAN' 
										  WHEN [GRL030_DESCRIPC] LIKE '%Renault%'  THEN 'RENAULT' 
										  WHEN [GRL030_DESCRIPC] LIKE '%Fiat%'  THEN 'FIAT' 
										  ELSE 'OTRA' 
									 END AS MARCA
							  FROM [PVTWEB].[dbo].[GRL030_ABRDESC] WITH (NOLOCK)
							  WHERE [GRL030_ABRTIPO] = 'CTRO CTO'
							) AS AB ON
								FV.[FV010_CCTO_CGEST] = AB.[CTROCTOCODABR]

-- ACTUALIZA el ctro ctos ABREVIADOS que quedaron vacios, seg�n la tabla [FV010_FVTA], vinculo Centro de Costos
UPDATE [PVTWEB].[dbo].[FV010_FVTA]
	SET [FV010_CCTODESABR] = CTROCTODESABR
		, [FV010_CCTOABR] = CTROCTOABR
		, [FV010_CCABRCOD] = CCABRCOD
		, [FV010_CCAC3] = CCAC3
		, [FV010_MARCAABR] = MARCA
FROM [PVTWEB].[dbo].[FV010_FVTA] AS FV WITH (NOLOCK) 
			LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS CTROCTOCODABR
									,[GRL030_DESCRIPC] AS CTROCTODESABR
									,[GRL030_DESCABR] AS CTROCTOABR
									,[GRL030_AGR01] AS CCABRCOD
									,LEFT([GRL030_AGR01],3) AS CCAC3
									,CASE WHEN [GRL030_DESCRIPC] LIKE '%Nissan%' THEN 'NISSAN' 
										  WHEN [GRL030_DESCRIPC] LIKE '%Renault%'  THEN 'RENAULT' 
										  WHEN [GRL030_DESCRIPC] LIKE '%Fiat%'  THEN 'FIAT' 
										  ELSE 'OTRA' 
									 END AS MARCA
							  FROM [PVTWEB].[dbo].[GRL030_ABRDESC] WITH (NOLOCK)
							  WHERE [GRL030_ABRTIPO] = 'CTRO CTO'
							) AS AB ON
								FV.[FV010_CCTO_COD] = AB.[CTROCTOCODABR]
WHERE FV.[FV010_CCTO_CGEST] IS NULL


-- ACTUALIZA el ctro ctos ABREVIADOS, vac�os como A DEFINIR,
UPDATE [PVTWEB].[dbo].[FV010_FVTA]
	SET [FV010_CCTODESABR] = ISNULL([FV010_CCTODESABR], 'A DEF')
		, [FV010_CCTOABR] = ISNULL([FV010_CCTOABR], 'A DEF')
		, [FV010_CCABRCOD] = ISNULL([FV010_CCABRCOD], 'A DEF')
		, [FV010_CCAC3] = ISNULL([FV010_CCAC3], 'A DEF')
		, [FV010_MARCAABR] = ISNULL([FV010_MARCAABR], 'A DEF')
FROM [PVTWEB].[dbo].[FV010_FVTA] AS FV WITH (NOLOCK)
WHERE [FV010_CCTODESABR] IS NULL OR [FV010_CCTOABR] IS NULL OR [FV010_CCABRCOD] IS NULL OR [FV010_CCAC3] IS NULL OR [FV010_MARCAABR] IS NULL

---- Verifica que el [FV010_CCTODESABR] no quede vacio
--SELECT [FV010_CCTODESABR], [FV010_CCTOABR], [FV010_CCABRCOD], [FV010_CCAC3], [FV010_MARCAABR], *
--FROM [PVTWEB].[dbo].[FV010_FVTA] AS FV WITH (NOLOCK)
--WHERE [FV010_CCTODESABR] = 'A DEF'
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- *******************************************************************************************************************************************
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 3
-- ###################################################################################################################################


-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 4  -- ACTUALIZACIONES VARIAS TABLAS
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)
-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'FVTA_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'FVTA_ACT', 4, @PROCNUM, 'ACT_TABLAS', 'FVTA_ACT VARIAS', '[FV010_FVTA]', 'Act valores que pueden dar error [FV010_FVTA]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

-- CORRIGE VALORES QUE PRODUCEN ERRORES
UPDATE [PVTWEB].[dbo].[FV010_FVTA]
   SET [FV010_TIPOTRAB] = 'Reparacion'
	WHERE [FV010_TIPOTRAB] = 'Reparaci�n' 

UPDATE [PVTWEB].[dbo].[FV010_FVTA]
   SET [FV010_TIPOTRAB] = 'A Definir'
	WHERE [FV010_TIPOTRAB] IS NULL 
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- *******************************************************************************************************************************************



-- ######################################################################################################################################
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT AS ID, 'FVTA_ACT', 5, @PROCNUM, 'ACT_TABLAS', 'ACT_RESPONS', '[GRL030_ABRDESC]', 'Act el responsable [GRL030_ABRDESC] / [GRL012_CLIRESP]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

-- INSERTA LOS NUEVOS USUARIOS EN LA TABLA ABRDESC
INSERT INTO [PVTWEB].[dbo].[GRL030_ABRDESC]
           ([GRL030_CODIGO]
           ,[GRL030_DESCRIPC]
--           ,[GRL030_DESCABR]
           ,[GRL030_ABRTIPO]
--           ,[GRL030_AGR01]
			)
		SELECT EP.[FV010_EMPNOMB]
				, EP.[FV010_EMPNOMB]
				, 'RECEPTOR'
		FROM (
				SELECT [FV010_EMPNOMB]
				FROM [PVTWEB].[dbo].[FV010_FVTA]
				GROUP BY [FV010_EMPNOMB]
			  ) AS EP 
				LEFT OUTER JOIN 
				   (SELECT [GRL030_CODIGO]
						  ,[GRL030_DESCRIPC]
						  ,[GRL030_DESCABR]
						  ,[GRL030_ABRTIPO]
						  ,[GRL030_AGR01]
					  FROM [PVTWEB].[dbo].[GRL030_ABRDESC]
					WHERE ([GRL030_ABRTIPO] = 'RECEPTOR')
					) AS ET ON
				EP.[FV010_EMPNOMB] = ET.[GRL030_CODIGO]
		WHERE ET.[GRL030_CODIGO] IS NULL

-- INSERTA LOS USUARIOS QUE OPERARON EL SISTEMA EN LA TABLA [GRL030_ABRDESC]
INSERT INTO [PVTWEB].[dbo].[GRL030_ABRDESC]
           ([GRL030_CODIGO]
--           ,[GRL030_DESCRIPC]
--           ,[GRL030_DESCABR]
           ,[GRL030_ABRTIPO]
--           ,[GRL030_AGR01]
			)
			SELECT [FV010_USUARIO] AS 'CODIGO'
					,'USUSIST' AS 'ABRTIPO'
			FROM [PVTWEB].[dbo].[FV010_FVTA] AS FV 
				LEFT OUTER JOIN (SELECT [GRL030_CODIGO] 
									FROM [PVTWEB].[dbo].[GRL030_ABRDESC] 
									WHERE [GRL030_ABRTIPO] = 'USUSIST' 
									GROUP BY [GRL030_CODIGO]
								 ) AS AB
					ON FV.[FV010_USUARIO] = AB.[GRL030_CODIGO]
				WHERE AB.[GRL030_CODIGO] IS NULL
			GROUP BY [FV010_USUARIO]


-- ######################################################################################################################################
-- INSERTA LOS CLIENTES NUEVOS CON LA TABLA DE RESPONSABLES
INSERT INTO [PVTWEB].[dbo].[GRL012_CLIRESP]
           ([GRL012_CLIID]
           ,[GRL012_CLICOD]
           ,[GRL012_CLICCTO]
           ,[GRL012_CLIRAZSOC]
--           ,[GRL012_CLIRESPNOM]
--           ,[GRL012_CLIRESPID]
			)
	-- LISTA LOS CLIENTES Y SUS CENTROS DE COSTOS QUE TODAVIA NO ESTAN EN LA TABLA DE RESPONSABLES
     SELECT [FV010_CLIID], [FV010_CTACOD], [FV010_CCTO_CGEST], [FV010_CLINOMB]	--[FV010_CCTO_COD]
		FROM [PVTWEB].[dbo].[FV010_FVTA] AS FACVTA
			LEFT OUTER JOIN [PVTWEB].[dbo].[GRL012_CLIRESP] AS CLRES ON
				FACVTA.[FV010_CTACOD] = CLRES.[GRL012_CLICOD]
					AND
				FACVTA.[FV010_CCTO_CGEST] = CLRES.[GRL012_CLICCTO]
	 WHERE CLRES.[GRL012_CLICOD] IS NULL AND [FV010_CCTO_CGEST] IS NOT NULL
	 GROUP BY [FV010_CLIID], [FV010_CTACOD], [FV010_CCTO_CGEST], [FV010_CLINOMB]	--, LEFT([FV010_CLINOMB], 15)
	 ORDER BY [FV010_CLIID], [FV010_CTACOD], [FV010_CCTO_CGEST]


-- ACTUALIZA EL RESPONSABLE FINAL DEL CLIENTE, EN LAS DISTINTAS TABLAS
-- ACTUALIZA LA TABLA DE RESPONSABLE DE VENTAS
UPDATE [PVTWEB].[dbo].[FV010_FVTA]
   SET [FV010_CLIRESP] = CASE WHEN [GRL012_CLIRESPNOM] IS NULL	-- CLIENTE NO DE REPUESTOS
							THEN CASE WHEN [RECEPABR] IS NULL	-- EL RECEPTOR NO TIENE CODIGO ABREVIADO EN LA TABLA [GRL030_ABRDESC]
										THEN CASE WHEN [USUABR] IS NULL THEN	-- EL USUARIO NO TIENE CODIGO ABREVIADO EN LA TABLA [GRL030_ABRDESC]
														CASE WHEN [FV010_EMPNOMB] IS NULL THEN	-- EL CAMPO USUARIO NO TIENE NOMBRE
																CASE WHEN [FV010_USUARIO] IS NULL THEN 'A DEFINIR' ELSE [FV010_USUARIO] END	-- SI NO TIENE USUARIO - PONE A DEFINIR - SI NO EL USUARIO
															 ELSE [FV010_EMPNOMB]
														END
												  ELSE [USUABR]
											 END
									   ELSE [RECEPABR]
								 END
						ELSE [GRL012_CLIRESPNOM]
					END
		FROM [PVTWEB].[dbo].[FV010_FVTA] AS FV  WITH (NOLOCK)
				LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS RECEPTCODABR
										,[GRL030_DESCRIPC] AS RECEPTDESC
										,[GRL030_DESCABR] AS RECEPABR
										,[GRL030_AGR01] AS RECAGR
								  FROM [PVTWEB].[dbo].[GRL030_ABRDESC]  WITH (NOLOCK)
								  WHERE [GRL030_ABRTIPO] = 'RECEPTOR'
								) AS AB2 ON
									FV.[FV010_EMPNOMB] = AB2.[RECEPTCODABR]
				LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS USUCODABR
											,[GRL030_DESCRIPC] AS USUDESC
											,[GRL030_DESCABR] AS USUABR
											,[GRL030_AGR01] AS USUAGR
									  FROM [PVTWEB].[dbo].[GRL030_ABRDESC]  WITH (NOLOCK)
									  WHERE [GRL030_ABRTIPO] = 'USUSIST'
								 ) AS AB3 ON
									FV.[FV010_USUARIO] = AB3.[USUCODABR]
				LEFT OUTER JOIN (SELECT [GRL012_CLIID]
								  ,[GRL012_CLICCTO]
								  ,[GRL012_CLICOD]
								  ,[GRL012_CLIRAZSOC]
								  ,[GRL012_CLIRESPNOM]
								  ,[GRL012_CLIRESPID]
								  ,[GRL012_CLITIPOABR]
								FROM [PVTWEB].[dbo].[GRL012_CLIRESP] WITH (NOLOCK)
								) AS CR ON
								FV.[FV010_CLIID] = CR.[GRL012_CLIID]
									AND 
								FV.[FV010_CCTO_CGEST] = CR.[GRL012_CLICCTO]

-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT


-- ######################################################################################################################################
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT AS ID, 'FVTA_ACT', 6, @PROCNUM, 'ACT_TABLAS', 'ACT_CLI_TIPO', '[GRL014_CLITIPO]', 'Act el Tipo de Cliente [GRL014_CLITIPO]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

-- ACTUALIZA LA TABLA DE CLIENTE TIPO
INSERT INTO [PVTWEB].[dbo].[GRL014_CLITIPO]
           ([GRL014_CTAID]
           ,[GRL014_CTACOD]
           ,[GRL014_CLIRAZSOC]
           ,[GRL014_CLINOMABR]
--           ,[GRL014_CLIDNINUM]
--           ,[GRL014_CTACODUNIF]
           ,[GRL014_CLITIPOCAL]
--           ,[GRL014_CLITIPO]
--           ,[GRL014_CLITIPOABR]
			)
	SELECT [FV010_CLIID]
			, MIN([FV010_CTACOD]) AS [FV010_CTACOD]
			, MIN([FV010_CLINOMB]) AS [FV010_CTACOD]
			, MIN(CASE WHEN CHARINDEX(' ', [FV010_CLINOMB], CHARINDEX(' ', [FV010_CLINOMB], 0)) = 0 
								 THEN [FV010_CLINOMB]
								 ELSE LTRIM(SUBSTRING([FV010_CLINOMB], 0, CHARINDEX(' ', [FV010_CLINOMB], CHARINDEX(' ', [FV010_CLINOMB], 0) + 1)))
							END) AS [GRL014_CLINOMABR]
			, MIN([FV010_CLITIPO]) AS [FV010_CLITIPO]
		FROM [PVTWEB].[dbo].[FV010_FVTA] AS FACVTA
			LEFT OUTER JOIN [PVTWEB].[dbo].[GRL014_CLITIPO] AS CLTIP ON
				FACVTA.[FV010_CLIID] = CLTIP.[GRL014_CTAID]
	 WHERE CLTIP.[GRL014_CTAID] IS NULL
	 GROUP BY [FV010_CLIID]

-- ACTUALIZA EL CODIGO DE CLIENTE EN LA TABLA GRL014_CLITIPO
-- INICIO --  ACTUALIZA EL CODIGO DE CLIENTE DESDE CALIPSO
-- ------------------------------------------------------------------------------------------------------------------------------
UPDATE [PVTWEB].[dbo].[GRL014_CLITIPO]
   SET [GRL014_CLITIPO] = [GRL0142_CLITIPO]
		, [GRL014_CLITIPOABR] = [GRL0142_CLITIPABR]
--		SELECT TOP 10000 [GRL014_CTAID], [GRL014_CLITIPO], [GRL0142_CLITIPCAL], [GRL0142_CLITIPO], [GRL0142_CLITIPABR]
		FROM [PVTWEB].[dbo].[GRL014_CLITIPO] AS CT
			INNER JOIN [PVTWEB].[dbo].[GRL0142_CLITIPOS] AS CTC ON
					CT.[GRL014_CLITIPOCAL] = CTC.[GRL0142_CLITIPCAL]
		WHERE [GRL014_CLITIPOABR] IS NULL
-- ------------------------------------------------------------------------------------------------------------------------------


---- ACTUALIZA EL CODIGO DE CLIENTE ABREVIADO DESDE LA TABLA CLITIPOS, SEGUN CLASIFICACI�N PROPIA
---- INICIO --  ACTUALIZA EL CODIGO DE CLIENTE DESDE CALIPSO
---- ------------------------------------------------------------------------------------------------------------------------------
--UPDATE [PVTWEB].[dbo].[GRL014_CLITIPO]
--   SET [GRL014_CLITIPOABR] = [GRL0142_CLITIPABR]
----		SELECT TOP 10000 [GRL014_CTAID], [GRL014_CLITIPO], [GRL0142_CLITIPCAL], [GRL0142_CLITIPO], [GRL0142_CLITIPABR]
--		FROM [PVTWEB].[dbo].[GRL014_CLITIPO] AS CT
--			INNER JOIN [PVTWEB].[dbo].[GRL0142_CLITIPOS] AS CTC ON
--					CT.[GRL014_CLITIPO] = CTC.[GRL0142_CLITIPO]
---- ------------------------------------------------------------------------------------------------------------------------------

-- ACTUALIZA EL DNI
-- Debe actualizar el DNI del Cliente, esto es para unificar los Clientes
UPDATE [PVTWEB].[dbo].[GRL014_CLITIPO]
   SET [GRL014_CLIDNINUM] = CLI.[GRL010_CLIDNINUM]
--	SELECT TOP 100 CTI.[GRL014_CTAID], CLI.[GRL010_CLIDNINUM], *
	FROM [PVTWEB].[dbo].[GRL014_CLITIPO] AS CTI
		INNER JOIN (SELECT [GRL010_CLIID]
						  ,[GRL010_CLICOD]
						  ,[GRL010_CLIRAZSOC]
						  ,[GRL010_CLIDIRPROV]
						  ,[GRL010_CLIDIRCIUDAD]
						  ,[GRL010_CLIDIRBARRIO]
						  ,[GRL010_CLIDIRCALLE]
						  ,[GRL010_CLIDIRCP]
						  ,[GRL010_CLITELPART]
						  ,[GRL010_CLITELLAB]
						  ,[GRL010_CLITELCELU]
						  ,[GRL010_CLIEMAIL]
						  ,[GRL010_CLIDNITIPO]
						  ,[GRL010_CLIDNINUM]
						  ,[GRL010_CLICUIT]
						  ,[GRL010_CLIFECNAC]
						  ,[GRL010_CLITIPO]
					  FROM [PVTWEB].[dbo].[GRL010_CLIENT] WITH(NOLOCK)
					  WHERE [GRL010_CLIDNINUM] IS NOT NULL AND [GRL010_CLIDNINUM] <> '') AS CLI ON 
			CTI.[GRL014_CTAID] = CLI.[GRL010_CLIID]

-- ACTUALIZA EL CLIENTE TIPO ABREVIADO, DESDE LA TABLA [GRL014_CLITIPO]
UPDATE [PVTWEB].[dbo].[FV010_FVTA]
   SET [FV010_CLITIPO] = [GRL014_CLITIPO]
		, [FV010_CLITIPOABR] = [GRL014_CLITIPOABR]
	FROM [PVTWEB].[dbo].[FV010_FVTA] AS FV WITH (NOLOCK) 
			LEFT OUTER JOIN (SELECT [GRL014_CTAID]
								  ,[GRL014_CTACOD]
								  ,[GRL014_CLIRAZSOC]
								  ,[GRL014_CLINOMABR]
								  ,[GRL014_CTACODUNIF]
								  ,[GRL014_CLITIPO]
								  ,[GRL014_CLITIPOABR]
							  FROM [PVTWEB].[dbo].[GRL014_CLITIPO]
						 ) AS CT ON
								FV.[FV010_CLIID] = CT.[GRL014_CTAID]

-- ACTUALIZA EL CLIENTE TIPO ABREVIADO, DESDE LA TABLA [GRL0142_CLITIPOS]
UPDATE [PVTWEB].[dbo].[FV010_FVTA]
   SET [FV010_CLITIPOABR] = [GRL0142_CLITIPABR]
	FROM [PVTWEB].[dbo].[FV010_FVTA] AS FV WITH (NOLOCK) 
			LEFT OUTER JOIN (SELECT [GRL0142_CLITIPCAL]
								  ,[GRL0142_CLITIPO]
								  ,[GRL0142_CLITIPABR]
							  FROM [PVTWEB].[dbo].[GRL0142_CLITIPOS]) AS CTC ON
			FV.[FV010_CLITIPO] = CTC.[GRL0142_CLITIPO]
	WHERE [FV010_CLITIPOABR] IS NULL

-- ACTUALIZA LOS QUE SON NULOS
UPDATE [PVTWEB].[dbo].[FV010_FVTA]
   SET [FV010_CLITIPO] = '20 - General'
		, [FV010_CLITIPOABR] = '01 - General'
	WHERE [FV010_CLITIPO] IS NULL OR [FV010_CLITIPOABR] IS NULL

--SELECT TOP 100 [FV010_CLITIPO], [FV010_CLITIPOABR], COUNT(*) AS TOTAL
--FROM [PVTWEB].[dbo].[FV010_FVTA]
--GROUP BY [FV010_CLITIPO], [FV010_CLITIPOABR]
--ORDER BY [FV010_CLITIPOABR], [FV010_CLITIPO]


-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 4
-- ###################################################################################################################################




-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^6
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^6
-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 5  -- INSERTA NUEVOS VALORES		TABLA [FV011_FVTAAGR]
-- ###################################################################################################################################
DECLARE @NUEVOIDACT AS NVARCHAR(36) 
DECLARE @PROCNUM AS NUMERIC(18,0)
-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'FVTA_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'FVTA_ACT', 7, @PROCNUM, 'FVTA_AGRUP', 'FVTAGR_DATBORR', '[FV011_FVTAAGR]', 'Elimina datos de [FV011_FVTAAGR]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
DELETE FROM [PVTWEB].[dbo].[FV011_FVTAAGR]		-- BORRA LOS DATOS DE LA TABLA DE FACTURAS AGRUPADAS
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT


SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'FVTA_ACT', 8 , @PROCNUM, 'FVTA_AGRUP', 'FVTAGR_DATIMP', '[FV011_FVTAAGR]', 'Importa datos a [FV011_FVTAAGR]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
INSERT INTO [PVTWEB].[dbo].[FV011_FVTAAGR]
           ([FV011_CPBTETIPO]
           ,[FV011_MARCA]
           ,[FV011_FCANO]
           ,[FV011_FCMES]
           ,[FV011_FCFECHA]
           ,[FV011_VTATIPOCOD]
           ,[FV011_VTATIPODES]
           ,[FV011_SUCCOD]
           ,[FV011_SUCDES]
           ,[FV011_REFRUBRO]
           ,[FV011_FCCARGO]
           ,[FV011_CCTOCOD]
           ,[FV011_CCTODES]
           ,[FV011_CCTOABR]
           ,[FV011_CCTOABRCOD]
           ,[FV011_CCTOABR3C]
           ,[FV011_CLITIPOABR]
		   ,[FV011_USUARIO]
           ,[FV011_EMPCOD]
           ,[FV011_EMPNOMB]
           ,[FV011_VDEXDEF]
           ,[FV011_CLIRESP]
           ,[FV011_FCCANT]
           ,[FV011_FCVTANET]
           ,[FV011_FCDTO]
           ,[FV011_FCCOSTO]
           ,[FV011_FCUTILNET]
           ,[FV011_FCSALDO])
	SELECT [FV010_CTETIPO] AS [FV011_CPBTETIPO]
		   ,[FV010_MARCAABR]
--		   ,[FV010_FVID]
--		   ,[FV010_CTEDET]
--		   ,[FV010_FCNUM]
--		   ,[FV010_CLIID]
--		   ,[FV010_CTACOD]
--		   ,[FV010_CLINOMB]
		   ,[FV010_FCANO] AS [FV011_FCANO]
		   ,[FV010_FCMES] AS [FV011_FCMES]
		   ,[FV010_FCFECHA] AS [FV011_FCFECHA]
		   ,[FV010_VTATIPO_COD] AS [FV011_VTATIPOCOD]
		   ,[FV010_VTATIPO] AS [FV011_VTATIPODES]
		   ,[FV010_SUC_COD] AS [FV011_SUCCOD]
		   ,[FV010_SUCURSAL] AS [FV011_SUCDES]
	--       ,[FV010_REFERCOD]
	--       ,[FV010_REFERDESC]
--	       ,[FV010_REFERTIPO]
	       ,[FV010_REFERRUBRO] AS [FV011_REFRUBRO]
	--	     ,[FV010_REFERSUBRUBRO]
	--       ,[FV010_REFERFLIA]
--	       ,[FV010_SSoPROD]
	       ,[FV010_FCCARGO] AS [FV011_FCCARGO]
--		   ,[FV010_CLICIUDAD]
--		   ,[FV010_CLIPROV]
		   ,[FV010_CCTO_CGEST] AS [FV011_CCTOCOD]	-- [FV010_CCTO_COD]
		   ,[FV010_CCTODESABR] AS [FV011_CCTODES]		--[FV010_CTROCTO]
		   ,[FV010_CCTOABR] AS [FV011_CCTOABR]
		   ,[FV010_CCABRCOD] AS [FV011_CCTOABRCOD]
		   ,[FV010_CCAC3] AS [FV011_CCTOABR3C]
--		   ,[FV010_CLITIPO]
--		   ,[GRL014_CLINOMABR]
--		   ,[GRL014_CLITIPO]
		   ,[FV010_CLITIPOABR] AS [FV011_CLITIPOABR]
		   ,[FV010_USUARIO]
		   ,[FV010_EMPCOD] AS [FV011_EMPCOD]
		   ,[FV010_EMPNOMB] AS [FV011_EMPNOMB]
--		   ,[FV010_CLITELPART]
		   ,[FV010_VENDxDEF] AS [FV011_VDEXDEF]
		   ,[FV010_CLIRESP] AS [FV011_CLIRESP]
		   ,SUM([FV010_FCCANTIDAD]) AS [FV011_FCCANT]
		   ,SUM([FV010_FCTOTVTANETA]) AS [FV011_FCVTANET]
		   ,SUM([FV010_FCTOTDTO]) AS [FV011_FCDTO]
		   ,SUM([FV010_FCTOTCOSTO]) AS [FV011_FCCOSTO]
		   ,SUM([FV010_FCUTILNET]) AS [FV011_FCUTILNET]
		   ,AVG([FV010_FCSALDO]) AS [FV011_FCSALDO]
--	SELECT TOP 100 *
	FROM [PVTWEB].[dbo].[FV010_FVTA] AS FV WITH (NOLOCK) 
	GROUP BY [FV010_CTETIPO]
		   ,[FV010_MARCAABR]
		   ,[FV010_FCANO]
		   ,[FV010_FCMES]
		   ,[FV010_FCFECHA]
		   ,[FV010_VTATIPO_COD]
		   ,[FV010_VTATIPO]
		   ,[FV010_SUC_COD]
		   ,[FV010_SUCURSAL]
	       ,[FV010_REFERRUBRO]
	       ,[FV010_FCCARGO]
		   ,[FV010_CCTO_CGEST]
		   ,[FV010_CCTODESABR]
		   ,[FV010_CCTOABR]
		   ,[FV010_CCABRCOD]
		   ,[FV010_CCAC3]
		   ,[FV010_CLITIPOABR]
		   ,[FV010_USUARIO]
		   ,[FV010_EMPCOD]
		   ,[FV010_EMPNOMB]
		   ,[FV010_VENDxDEF]
		   ,[FV010_CLIRESP]
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^6
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^6
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 5
-- ###################################################################################################################################



---- ACTUALIZA EL CODIGO ABREVIADO DE CENTRO DE COSTOS
--UPDATE [PVTWEB].[dbo].[FV011_FVTAAGR]
--   SET [FV011_CCABRCOD] = CCABRCOD
--		FROM [PVTWEB].[dbo].[FV011_FVTAAGR] AS FV WITH (NOLOCK) 
--				LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS CTROCTOCODABR
--									,[GRL030_DESCRIPC] AS CTROCTODESABR
--									,[GRL030_DESCABR] AS CTROCTOABR
--									,[GRL030_AGR01] AS CCABRCOD
--									,LEFT([GRL030_AGR01],3) AS CCAC3
--									,LEFT([GRL030_AGR01],2) AS CCAC2
--									,CASE WHEN LEFT([GRL030_AGR01],3) = 'PVN' THEN 'NISSAN' 
--										  WHEN LEFT([GRL030_AGR01],3) = 'PVR' THEN 'RENAULT' 
--										  ELSE 'OTRA' 
--									 END AS MARCA
--							  FROM [PVTWEB].[dbo].[GRL030_ABRDESC] WITH (NOLOCK)
--							  WHERE [GRL030_ABRTIPO] = 'CTRO CTO'
--							) AS AB ON
--								FV.[FV011_CCTOCOD] = AB.[CTROCTOCODABR]
--



--
--
---- ######################################################################################################################################
---- INSERTA NUEVOS VALORES		TABLA [FV013_INFMES]
---- ######################################################################################################################################
--DELETE FROM [PVTWEB].[dbo].[FV013_INFMES]		-- TABLA INFORMES
--INSERT INTO [PVTWEB].[dbo].[FV013_INFMES]
--           ([FV010_FCANO]
--           ,[FV010_FCMES]
--           ,[ANOMES]
--           ,[FV010_VTATIPO_COD]
--           ,[FV010_VTATIPO]
--           ,[FV010_CCTO_COD]
--           ,[FV010_CTROCTO]
--           ,[CCAC3]
--           ,[RESPONSABLE]
--           ,[FV010_REFERRUBRO]
--           ,[FV012_CANT]
--           ,[FV012_VTANET]
--           ,[FV012_DTO]
--           ,[FV012_COSTO]
--           ,[FV012_UTILNET]
--           ,[FV012_FCSALDO])
--			SELECT 
--				   [FV010_FCANO]
--				  ,[FV010_FCMES]
--				  ,LEFT(CONVERT(VARCHAR(12), [FV010_FCFECHA], 111),7) AS ANOMES
----				  ,DATEPART(WK,[FV010_FCFECHA]) AS SEM
----				  ,[FV010_FCFECHA]
----				  ,[FV010_CTETIPO]
----				  ,[FV010_FVID]
----				  ,[FV010_CTEDET]
----				  ,[FV010_FCNUM]
----				  ,[FV010_CLIID]
----				  ,[FV010_CTACOD]
----				  ,[FV010_CLINOMB]
----				  ,[FV010_CLITIPO]
----				  ,CASE WHEN [GRL014_CLINOMABR] IS NULL 
----						THEN CAST(CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END AS NVARCHAR(50)) + '�' + CAST(CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END AS NVARCHAR(50)) + '-' + [FV010_CLINOMB] + '�' + [FV010_CLINOMB]
----						ELSE CAST(CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END AS NVARCHAR(50)) + '�' + CAST(CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END AS NVARCHAR(50)) + '-' + [GRL014_CLINOMABR] + '�' + [GRL014_CLINOMABR]
----						END AS CLIENTE
--				  ,[FV010_VTATIPO_COD]
--				  ,[FV010_VTATIPO]
----				  ,[FV010_SUC_COD]
----				  ,[FV010_SUCURSAL]
----				  ,[FV010_FCCARGO]
----				  ,[FV010_CLICIUDAD]
----				  ,[FV010_CLIPROV]
----				  ,[FV010_CLITELPART]
--				  ,[FV010_CCTO_CGEST]		-- [FV010_CCTO_COD]
--				  ,[CTROCTODESABR]			--[FV010_CTROCTO]
--				  ,[CCAC3]
------				  ,[FV010_EMPCOD]
------				  ,[FV010_EMPNOMB]
------				  ,[FV010_VENDxDEF]
--				  ,CASE WHEN [GRL012_CLIRESPNOM] IS NULL THEN 'A DEFINIR'
--					 WHEN [GRL012_CLIRESPNOM] = 'RECEPTOR' 
--						THEN CASE WHEN [FV010_EMPNOMB] IS NULL 
--								  THEN 'A DEFINIR' ELSE CASE WHEN [RECEPABR] IS NULL THEN [FV010_EMPNOMB] ELSE [RECEPABR] END
--							 END
--					 ELSE [GRL012_CLIRESPNOM] 
--					END AS RESPONSABLE
----						,CAST([FV010_CCTO_COD] AS NVARCHAR(8)) + '�' + [FV010_CCTO_COD] + '�' + [FV011_CCTOABR] AS [CTROCTOS]
----						,[FV011_CCTOABR3C] + '�' + [FV011_MARCA] AS [CTROCTOABR]
----					 	,CASE WHEN [FV011_CLITIPOABR] IS NULL THEN 'A DEFINIR' ELSE [FV011_CLITIPOABR] END AS [CTETIPO]
----				  ,CASE WHEN @PAR4 = 'TOTAL' THEN CCAC2 
----							 WHEN @PAR4 = 'PVR' THEN CCAC3
----							 WHEN @PAR4 = 'PVN' THEN CCAC3
----							 ELSE CAST([FV010_CCTO_COD] AS VARCHAR(50)) 
----							 END AS CTCTOS
----				  ,[FV010_REFERCOD]
----				  ,[FV010_REFERDESC]
----				  ,[FV010_REFERTIPO]
--				  ,[FV010_REFERRUBRO]
----				  ,[FV010_REFERSUBRUBRO]
----				  ,[FV010_REFERFLIA]
----				  ,[FV010_SSoPROD]
--				  ,CAST(SUM([FV010_FCCANTIDAD]) AS DECIMAL(18,2)) AS [FV012_CANT]
--				  ,CAST(SUM([FV010_FCTOTVTANETA]) AS DECIMAL(18,2)) AS [FV012_VTANET]
--				  ,CAST(SUM([FV010_FCTOTDTO]) AS DECIMAL(18,2)) AS [FV012_DTO]
--				  ,CAST(SUM([FV010_FCTOTCOSTO]) AS DECIMAL(18,2)) AS [FV012_COSTO]
--				  ,CAST(SUM([FV010_FCUTILNET]) AS DECIMAL(18,2)) AS [FV012_UTILNET]
--				  ,CAST(SUM([FV010_FCSALDO]) AS DECIMAL(18,2)) AS [FV012_FCSALDO]
----SELECT TOP 100 *
--			FROM [PVTWEB].[dbo].[FV010_FVTA] AS FV WITH (NOLOCK) 
--					LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS CTROCTOCODABR
--										,[GRL030_DESCRIPC] AS CTROCTODESABR
--										,[GRL030_DESCABR] AS CTROCTOABR
--										,[GRL030_AGR01] AS CCABRCOD
--										,LEFT([GRL030_AGR01],3) AS CCAC3
--										,LEFT([GRL030_AGR01],2) AS CCAC2
--										,CASE WHEN LEFT([GRL030_AGR01],3) = 'PVN' THEN 'NISSAN' 
--											  WHEN LEFT([GRL030_AGR01],3) = 'PVR' THEN 'RENAULT' 
--											  ELSE 'OTRA' 
--										 END AS MARCA
--									 FROM [PVTWEB].[dbo].[GRL030_ABRDESC] WITH (NOLOCK)
--									 WHERE [GRL030_ABRTIPO] = 'CTRO CTO'
--								) AS AB ON
--									FV.[FV010_CCTO_CGEST] = AB.[CTROCTOCODABR]
--				LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS RECEPTCODABR
--										,[GRL030_DESCRIPC] AS RECEPTDESC
--										,[GRL030_DESCABR] AS RECEPABR
--										,[GRL030_AGR01] AS RECAGR
--								  FROM [PVTWEB].[dbo].[GRL030_ABRDESC]
--								  WHERE [GRL030_ABRTIPO] = 'RECEPTOR'
--								 ) AS AB2 ON
--									FV.[FV010_EMPNOMB] = AB2.[RECEPTCODABR]
--				LEFT OUTER JOIN (SELECT [GRL012_CLIID]
--									  ,[GRL012_CLICCTO]
--									  ,[GRL012_CLICOD]
--									  ,[GRL012_CLIRAZSOC]
--									  ,[GRL012_CLIRESPNOM]
--									  ,[GRL012_CLIRESPID]
--									  ,[GRL012_CLITIPOABR]
--								  FROM [PVTWEB].[dbo].[GRL012_CLIRESP] WITH (NOLOCK)
--								) AS CR ON
--									FV.[FV010_CLIID] = CR.[GRL012_CLIID]
--										AND 
--									FV.[FV010_CCTO_CGEST] = CR.[GRL012_CLICCTO]
--					LEFT OUTER JOIN (SELECT [GRL014_CTAID]
--										  ,[GRL014_CTACOD]
--										  ,[GRL014_CLIRAZSOC]
--										  ,[GRL014_CLINOMABR]
--										  ,[GRL014_CTACODUNIF]
--										  ,[GRL014_CLITIPO]
--										  ,[GRL014_CLITIPOABR]
--									  FROM [PVTWEB].[dbo].[GRL014_CLITIPO]
--								 ) AS CT ON
--										FV.[FV010_CLIID] = CT.[GRL014_CTAID]
--			WHERE [FV010_FCCARGO] <> 'Tagle - Garantias Fabrica'
------					AND CASE WHEN @PAR2 = 'TOTAL' THEN 'TOTAL' ELSE [FV010_REFERRUBRO] END  = CASE WHEN @PAR2 = 'TOTAL' THEN 'TOTAL' ELSE @PAR2 END
----					AND [CCABRCOD] LIKE  '%' + @PAR3 + '%'
------						AND CASE WHEN @PAR4 = 'TOTAL' THEN CCAC2 
------								 WHEN @PAR4 = 'PVR' THEN CCAC3
------								 WHEN @PAR4 = 'PVN' THEN CCAC3
------								 ELSE CAST([FV010_CCTO_COD] AS VARCHAR(50)) 
------								 END = CASE WHEN @PAR4 = 'TOTAL' THEN 'PV' ELSE @PAR4 END
----					AND CASE WHEN [GRL014_CLITIPOABR] IS NULL THEN 'VARIOS' ELSE [GRL014_CLITIPOABR] END = @PAR5
--		GROUP BY [FV010_FCANO]
--				  ,[FV010_FCMES]
--				  ,LEFT(CONVERT(VARCHAR(12), [FV010_FCFECHA], 111),7)
----				  ,DATEPART(WK,[FV010_FCFECHA])
------			  ,CASE WHEN [GRL014_CLINOMABR] IS NULL 
------						THEN CAST(CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END AS NVARCHAR(50)) + '�' + CAST(CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END AS NVARCHAR(50)) + '-' + [FV010_CLINOMB] + '�' + [FV010_CLINOMB]
------						ELSE CAST(CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END AS NVARCHAR(50)) + '�' + CAST(CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END AS NVARCHAR(50)) + '-' + [GRL014_CLINOMABR] + '�' + [GRL014_CLINOMABR]
------						END
--				  ,[FV010_VTATIPO_COD]
--				  ,[FV010_VTATIPO]
--				  ,[FV010_CCTO_CGEST]
--				  ,[CTROCTODESABR]
--				  ,[CCAC3]
--				  , CASE WHEN [GRL012_CLIRESPNOM] IS NULL THEN 'A DEFINIR'
--						 WHEN [GRL012_CLIRESPNOM] = 'RECEPTOR' 
--							THEN CASE WHEN [FV010_EMPNOMB] IS NULL 
--									  THEN 'A DEFINIR' ELSE CASE WHEN [RECEPABR] IS NULL THEN [FV010_EMPNOMB] ELSE [RECEPABR] END
--								 END
--						 ELSE [GRL012_CLIRESPNOM] END
--				  ,[FV010_REFERRUBRO]
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^6
---- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^6
