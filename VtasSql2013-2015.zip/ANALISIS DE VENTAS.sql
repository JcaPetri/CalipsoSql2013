-- #####################################################################################################################################3
-- ANALISIS DE LA CUENTA DE LA BASE AGRUPADA
-- #####################################################################################################################################3
DECLARE	@PAR1 AS VARCHAR(50)
DECLARE	@PAR2 AS VARCHAR(50)

SET @PAR1 = 'PVR CBA'
SET @PAR2 = '2020105'
SELECT [FV010_VTATIPO], COUNT(*)
FROM (
				SELECT TOP 100 [FV010_CTETIPO]
					  ,[FV010_FVID]
					  ,[FV010_CTEDET]
					  ,[FV010_FCNUM]
					  ,[FV010_CLIID]
					  ,[FV010_CTACOD]
					  ,[FV010_CLINOMB]
					  ,[FV010_FCANO]
					  ,[FV010_FCMES]
					  ,[FV010_FCFECHA]
					  ,[FV010_VTATIPO_COD]
					  ,[FV010_VTATIPO]
					  ,[FV010_SUC_COD]
					  ,[FV010_SUCURSAL]
					  ,[FCCANT_TOT]
					  ,[FCVTANET_TOT]
					  ,[FCDTO_TOT]
					  ,[FCCOSTO_TOT]
					  ,[FCUTILNET_TOT]
					  ,[FV010_CLICIUDAD]
					  ,[FV010_CLIPROV]
					  ,[FV010_CCTO_COD]
					  ,[FV010_CTROCTO]
					  ,[FV010_CLITIPO]
					  ,[FV010_EMPCOD]
					  ,[FV010_EMPNOMB]
					  ,[FV010_CLITELPART]
					  ,[FV010_VENDxDEF]
					  ,[FCSALDO]
					  , DATEPART(WK,[FV010_FCFECHA]) AS SEM
					  , CAST([FV010_CCTO_COD] AS NVARCHAR(8)) + '�' + [FV010_CCTO_COD] + '�' + [CTROCTOABR] AS [CTROCTOS]
					  , CCAC3 + '�' + MARCA AS [CTROCTOABR]
					  , CASE WHEN [GRL012_CLITIPOABR] IS NULL THEN 'A DEFINIR' ELSE [GRL012_CLITIPOABR] END AS [CTETIPO]
				  FROM [PVTWEB].[dbo].[FV010_FVREPAGR] AS FV WITH (NOLOCK) 
					LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS CTROCTOCODABR
											,[GRL030_DESCRIPC] AS CTROCTODESABR
											,[GRL030_DESCABR] AS CTROCTOABR
											,[GRL030_AGR01] AS CCABRCOD
											,LEFT([GRL030_AGR01],3) AS CCAC3
											,CASE WHEN LEFT([GRL030_AGR01],3) = 'PVN' THEN 'NISSAN' 
												  WHEN LEFT([GRL030_AGR01],3) = 'PVR' THEN 'RENAULT' 
												  ELSE 'OTRA' 
											 END AS MARCA
									  FROM [PVTWEB].[dbo].[GRL030_ABRDESC] WITH (NOLOCK)
									  WHERE [GRL030_ABRTIPO] = 'CTRO CTO'
									) AS AB ON
										FV.[FV010_CCTO_COD] = AB.[CTROCTOCODABR]
					LEFT OUTER JOIN (SELECT [GRL012_CLIID]
										  ,[GRL012_CLICCTO]
										  ,[GRL012_CLICOD]
										  ,[GRL012_CLIRAZSOC]
										  ,[GRL012_CLIRESPNOM]
										  ,[GRL012_CLIRESPID]
										  ,[GRL012_CLITIPOABR]
									  FROM [PVTWEB].[dbo].[GRL012_CLIRESP] WITH (NOLOCK)
									) AS CR ON
										FV.[FV010_CLIID] = CR.[GRL012_CLIID]
											AND 
										FV.[FV010_CCTO_COD] = CR.[GRL012_CLICCTO]
					LEFT OUTER JOIN (SELECT [GRL014_CTAID]
										  ,[GRL014_CTACOD]
										  ,[GRL014_CLIRAZSOC]
										  ,[GRL014_CLINOMABR]
										  ,[GRL014_CTACODUNIF]
										  ,[GRL014_CLITIPO]
										  ,[GRL014_CLITIPOABR]
									  FROM [PVTWEB].[dbo].[GRL014_CLITIPO]
								 ) AS CT ON
										FV.[FV010_CLIID] = CT.[GRL014_CTAID]
					WHERE [FV010_FCFECHA] >= '2013-01-10'
--							AND [GRL014_CLITIPOABR] <> 'INTERNA'
--							AND [CCABRCOD] LIKE  '%' + @PAR1 + '%'
--							AND CASE WHEN @PAR2 = 'TOTAL' THEN LEFT(CCAC3, 2) 
--									 WHEN @PAR2 = 'PVR' THEN CCAC3
--									 WHEN @PAR2 = 'PVN' THEN CCAC3
--									 ELSE CAST([FV010_CCTO_COD] AS VARCHAR(50)) 
--									 END = CASE WHEN @PAR2 = 'TOTAL' THEN 'PV' ELSE @PAR2 END
			) AS FVTA
GROUP BY [FV010_VTATIPO]

--
--Taller de Chapa Tagle	114
--Taller Mecanico Tagle	1534
--Gestoria Tagle	1
--Ventas Especiales Tagle	89
--Facturacion CCBU Compra Usados Tagle	4
--Repuestos Tagle	879
--Autos Usados Tagle	29
--Autos Okm Tagle	259
--Se�a Tagle	23
--Patentes a Cobrar Tagle	28

-- #####################################################################################################################################3
-- ANALISIS DE LA CUENTA DE LA BASE EN DETALLE
-- #####################################################################################################################################3

-- VALOR TOTAL DE LAS CUENTAS CORRIENTES DE POSTVENTA AGRUPADAS POR SECTOR
--DECLARE @PAR1 AS VARCHAR(50)
--DECLARE	@PAR2 AS VARCHAR(50)
--DECLARE	@PAR3 AS VARCHAR(50)
--DECLARE	@PAR4 AS VARCHAR(50)
--
--SET @PAR1 = 'PV'
--SET @PAR2 = '2020104'
--SET @PAR3 = 'EMPLEADO'
--SET @PAR4 = '200016999'

SELECT [FV010_REFERRUBRO], COUNT(*)
FROM (
	SELECT TOP 100 'DATOS' AS TIPOFILA
			, [FV010_CTETIPO]
			  , [FV010_FVID]
			  , [FV010_CTEDET]
			  , [FV010_FCNUM]
			  , [FV010_CLIID]
			  , [FV010_CTACOD]
			  , [FV010_CLINOMB]
			  , [FV010_FCANO]
			  , [FV010_FCMES]
			  , CONVERT(VARCHAR(12), [FV010_FCFECHA], 111) AS 'FECHA'
			  , [FV010_VTATIPO_COD]
			  , [FV010_VTATIPO]
			  , [FV010_SUC_COD]
			  , [FV010_SUCURSAL]
			  , [FV010_REFERCOD]
			  , [FV010_REFERDESC]
			  , [FV010_REFERTIPO]
			  , [FV010_REFERRUBRO]
			  , [FV010_REFERSUBRUBRO]		-- NO TIENE NADA
			  , [FV010_REFERFLIA]
			  , [FV010_SSoPROD]
			  , CAST([FV010_FCCANTIDAD] AS DECIMAL(18,2)) AS CANT
			  , CAST([FV010_FCTOTVTANETA] AS DECIMAL(18,2)) AS TOTNET
			  , CAST([FV010_FCTOTDTO] AS DECIMAL(18,2)) AS DTONET
			  , CAST([FV010_FCTOTCOSTO] AS DECIMAL(18,2)) AS COSTO
			  , CAST([FV010_FCUTILNET] AS DECIMAL(18,2)) AS UTILTOT
			  , [FV010_FCCARGO]
			  , [FV010_CLICIUDAD]
			  , [FV010_CLIPROV]
			  , [FV010_CCTO_COD]
			  , [FV010_CTROCTO]
			  , [FV010_CLITIPO]
			  , [FV010_EMPCOD]
			  , [FV010_EMPNOMB]
			  , [FV010_CLITELPART]
			  , [FV010_VENDxDEF]
			  , [FV010_FCSALDO]
			  , DATEPART(WK,[FV010_FCFECHA]) AS SEM
			  , CAST([FV010_CCTO_COD] AS NVARCHAR(8)) + '�' + [FV010_CCTO_COD] + '�' + [CTROCTOABR] AS [CTROCTOS]
			  , CCAC3 + '�' + MARCA AS [CTROCTOMARCA]
			  , AB.*
			  , CR.*
			  , CT.*
			  , CASE WHEN [GRL012_CLITIPOABR] IS NULL THEN 'A DEFINIR' ELSE [GRL012_CLITIPOABR] END AS [CTETIPO]
			  , CASE WHEN [GRL014_CLINOMABR] IS NULL 
					THEN CAST(CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END AS NVARCHAR(50)) + '�' + CAST(CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END AS NVARCHAR(50)) + '-' + [FV010_CLINOMB] + '�' + [FV010_CLINOMB]
					ELSE CAST(CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END AS NVARCHAR(50)) + '�' + CAST(CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END AS NVARCHAR(50)) + '-' + [GRL014_CLINOMABR] + '�' + [GRL014_CLINOMABR]
					END AS CLIENTE
		  FROM [PVTWEB].[dbo].[FV010_FVREP] AS FV WITH (NOLOCK) 
			LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS CTROCTOCODABR
									,[GRL030_DESCRIPC] AS CTROCTODESABR
									,[GRL030_DESCABR] AS CTROCTOABR
									,[GRL030_AGR01] AS CCABRCOD
									,LEFT([GRL030_AGR01],3) AS CCAC3
									,CASE WHEN LEFT([GRL030_AGR01],3) = 'PVN' THEN 'NISSAN' 
										  WHEN LEFT([GRL030_AGR01],3) = 'PVR' THEN 'RENAULT' 
										  ELSE 'OTRA' 
									 END AS MARCA
							  FROM [PVTWEB].[dbo].[GRL030_ABRDESC] WITH (NOLOCK)
							  WHERE [GRL030_ABRTIPO] = 'CTRO CTO'
							) AS AB ON
								FV.[FV010_CCTO_COD] = AB.[CTROCTOCODABR]
			LEFT OUTER JOIN (SELECT [GRL012_CLIID]
								  ,[GRL012_CLICCTO]
								  ,[GRL012_CLICOD]
								  ,[GRL012_CLIRAZSOC]
								  ,[GRL012_CLIRESPNOM]
								  ,[GRL012_CLIRESPID]
								  ,[GRL012_CLITIPOABR]
							  FROM [PVTWEB].[dbo].[GRL012_CLIRESP] WITH (NOLOCK)
							) AS CR ON
								FV.[FV010_CLIID] = CR.[GRL012_CLIID]
									AND 
								FV.[FV010_CCTO_COD] = CR.[GRL012_CLICCTO]
			LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS RECEPTCODABR
									,[GRL030_DESCRIPC] AS RECEPTDESC
									,[GRL030_DESCABR] AS RECEPABR
									,[GRL030_AGR01] AS RECAGR
							  FROM [PVTWEB].[dbo].[GRL030_ABRDESC]
							  WHERE [GRL030_ABRTIPO] = 'RECEPTOR'
							 ) AS AB2 ON
								FV.[FV010_EMPNOMB] = AB2.[RECEPTCODABR]
			LEFT OUTER JOIN (SELECT [GRL014_CTAID]
								  ,[GRL014_CTACOD]
								  ,[GRL014_CLIRAZSOC]
								  ,[GRL014_CLINOMABR]
								  ,[GRL014_CTACODUNIF]
								  ,[GRL014_CLITIPO]
								  ,[GRL014_CLITIPOABR]
							  FROM [PVTWEB].[dbo].[GRL014_CLITIPO]
						 ) AS CT ON
								FV.[FV010_CLIID] = CT.[GRL014_CTAID]
			WHERE [FV010_FCFECHA] >= '2013-01-10'
	--				AND [GRL014_CLITIPOABR] <> 'INTERNA'
	--				AND [CCABRCOD] LIKE  '%' + @PAR1 + '%'
	--				AND CASE WHEN @PAR2 = 'TOTAL' THEN LEFT(CCAC3, 2) 
	--						 WHEN @PAR2 = 'PVR' THEN CCAC3
	--						 WHEN @PAR2 = 'PVN' THEN CCAC3
	--						 ELSE CAST([FV010_CCTO_COD] AS VARCHAR(50)) 
	--						 END = CASE WHEN @PAR2 = 'TOTAL' THEN 'PV' ELSE @PAR2 END
	--				AND CASE WHEN [GRL014_CLITIPOABR] IS NULL THEN 'VARIOS' ELSE [GRL014_CLITIPOABR] END = @PAR3
	--				AND CASE WHEN [GRL014_CTACODUNIF] IS NULL THEN [FV010_CTACOD] ELSE [GRL014_CTACODUNIF] END LIKE CASE WHEN @PAR4 = 'TOTAL' THEN '%' ELSE @PAR4 END
--	ORDER BY FV010_FCFECHA ASC
	) AS FC
GROUP BY [FV010_REFERRUBRO]





-- ##########################################################################################################################################3
-- PAPELES DE TRABAJO ANALISIS
-- #####################################################################################################################################3


SELECT TOP 200 [FV010_CTETIPO]
      ,[FV010_FVID]
      ,[FV010_CTEDET]
      ,[FV010_FCNUM]
      ,[FV010_CLIID]
      ,[FV010_CTACOD]
      ,[FV010_CLINOMB]
      ,[FV010_FCANO]
      ,[FV010_FCMES]
      ,[FV010_FCFECHA]
      ,[FV010_VTATIPO_COD]
      ,[FV010_VTATIPO]
      ,[FV010_SUC_COD]
      ,[FV010_SUCURSAL]
      ,[FV010_REFERCOD]
      ,[FV010_REFERDESC]
      ,[FV010_REFERTIPO]
      ,[FV010_REFERRUBRO]
      ,[FV010_REFERSUBRUBRO]
      ,[FV010_REFERFLIA]
      ,[FV010_SSoPROD]
      ,[FV010_FCCANTIDAD]
      ,[FV010_FCTOTVTANETA]
      ,[FV010_FCTOTDTO]
      ,[FV010_FCTOTCOSTO]
      ,[FV010_FCUTILNET]
      ,[FV010_FCCARGO]
      ,[FV010_CLICIUDAD]
      ,[FV010_CLIPROV]
      ,[FV010_CCTO_COD]
      ,[FV010_CTROCTO]
      ,[FV010_CLITIPO]
      ,[FV010_EMPCOD]
      ,[FV010_EMPNOMB]
      ,[FV010_CLITELPART]
      ,[FV010_VENDxDEF]
      ,[FV010_FCSALDO]
  FROM [PVTWEB].[dbo].[FV010_FVREP]
WHERE [FV010_FCNUM] LIKE '%006500004014%'


-- DETALLA LOS TIPOS DE COMPROBANTES
SELECT TOP 200 [FV010_CTETIPO], COUNT(*) AS CANT
  FROM [PVTWEB].[dbo].[FV010_FVREP]
GROUP BY [FV010_CTETIPO]
--	Factura Venta RT	180315
--	Nota Credito Venta	9413
--	Nota Debito Venta	8504

-- DETALLA LOS TIPOS DE VENTAS
SELECT TOP 200 [FV010_VTATIPO], COUNT(*) AS CANT
  FROM [PVTWEB].[dbo].[FV010_FVREP]
GROUP BY [FV010_VTATIPO]
--	Autos Okm Tagle	7082
--	Autos Usados Tagle	854
--	Cheques Rechazados Clientes	2
--	Facturacion CCBU Compra Usados Tagle	28
--	Facturacion CCBU Compra Usados Tagle - Vtas Espec.	8
--	Facturacion Formularios Getoria	208
--	Facturacion General Convencionales Tagle	5
--	Facturacion General Tagle	10
--	Facturacion Interempresa Avant(TAGLE)	4
--	Facturacion Interempresa Motcor(TAGLE)	4
--	Gestoria Tagle	45
--	Liquidacion de Prendas Convencionales Tagle 	18
--	Patentes a Cobrar Tagle	384
--	Repuestos Tagle	32104
--	Se�a Tagle	2617
--	Taller de Chapa Tagle	4944
--	Taller Mecanico Tagle	148472
--	Venta Accesorios Tagle	6
--	Venta de Accesorios por Terceros	4
--	Ventas Especiales Tagle	1433

-- DETALLA LAS SUCURSALES
SELECT TOP 200 [FV010_SUCURSAL], COUNT(*) AS CANT
  FROM [PVTWEB].[dbo].[FV010_FVREP]
GROUP BY [FV010_SUCURSAL]
--	Nix - Cordoba	25464
--	Nix - Rio IV	8282
--	Tagle - Cordoba	115242
--	Tagle - Rio IV	39880
--	Tagle - Villa Mar�a 	9364


-- DETALLA LOS CENTROS DE COSTOS
SELECT TOP 200 [FV010_CCTO_COD], [FV010_CTROCTO], COUNT(*) AS CANT
  FROM [PVTWEB].[dbo].[FV010_FVREP]
GROUP BY [FV010_CCTO_COD], [FV010_CTROCTO]
ORDER BY [FV010_CCTO_COD]
--	2020101	Tagle - Renault - Cordoba - Veh. Nuevos	7004
--	2020102	Tagle - Renault - Cordoba - Veh. Usados	980
--	2020103	Tagle - Renault - Cordoba - Plan Ahorro	846
--	2020104	Tagle - Renault - Cordoba - Repuestos	19725
--	2020105	Tagle - Renault - C�rdoba - Taller Mecan	82636
--	2020106	Tagle - Renault - Cordoba - Taller Chapa	2936
--	2020107	Tagle - Renault - Cordoba - Gestoria	301
--	2020108	Tagle - Renault - Cordoba - Administraci	14
--	2020109	Tagle - Renault - Cordoba - Directorio	283
--	2020110	Tagle - Renault - Cordoba - R. Minuto	255

-- DETALLA LOS TIPOS DE CLIENTES
SELECT TOP 200 [FV010_CLITIPO], COUNT(*) AS CANT
  FROM [PVTWEB].[dbo].[FV010_FVREP]
GROUP BY [FV010_CLITIPO]
--	NULL	41
--	1 - Repuestos - Concecionario (MAY)	2253
--	10 - Repuestos - Talleristas (MAY)	7759
--	12 - Repuestos - Vta.Repuesteros (MAY)	3660
--	13 - Repuestos - A.O.R.M. (MAY)	156
--	14 - Repuestos - Vta.Mayoristas B (MAY)	994
--	15 - Repuestos - Vta.Mayoristas C (MAY)	528
--	2 - Repuestos - Internas Departamentales	5106
--	20 - General	160316
--	3 - Repuestos - Costo Empleado	1301
--	4 - Repuestos - A.O.T.MOTRIO (MAY)	246
--	5 - Repuestos - Garantias	35
--	6 - Repuestos - Ventas Internas	1319
--	7 - Repuestos - Vta.Mayoristas A (MAY)	10417
--	8 - Repuestos - Venta Publico	1338
--	9 - Repuestos - Cias de Seguros (MAY)	2763

-- DETALLA LOS ARTICULOS Y SUS TIPOS DE REFERENCIA
SELECT TOP 200 [FV010_REFERTIPO], COUNT(*) AS CANT
  FROM [PVTWEB].[dbo].[FV010_FVREP]
GROUP BY [FV010_REFERTIPO]
--		79093
--	1 - Repuestos y Accesorios	117028
--	2 - Vehiculo 0Km	1841
--	3 - Vehiculo Usado	266
--	5 - Vehiculos Especiales	4

-- DETALLA LOS ARTICULOS Y SUS RUBROS
SELECT TOP 200 [FV010_REFERRUBRO], COUNT(*) AS CANT
  FROM [PVTWEB].[dbo].[FV010_FVREP]
GROUP BY [FV010_REFERRUBRO]
--	[FV010_REFERSUBRUBRO] ESTE CAMPO NO TIENE NADA
--	-	8686
--	01 - Repuestos	109833
--	02 - Mano de Obra 	53554
--	03 - Trabajos de Terceros	11965
--	04 - Lubricantes	9751
--	06 - Vehiculos 	4326
--	07 - Gestoria	117

-- DETALLA LOS ARTICULOS Y SUS FAMILIAS
SELECT TOP 200 [FV010_REFERFLIA], COUNT(*) AS CANT
  FROM [PVTWEB].[dbo].[FV010_FVREP]
GROUP BY [FV010_REFERFLIA]
ORDER BY COUNT(*) DESC
--		79093
--	NULL	79011
--	 - 	18756
--	0502 - FILTROS DE AIRE	6455
--	0948 - LUBRICANTES	1758
--	0503 - CORREAS	960
--	0352 - FILTROS DE GASOIL	822


-- DETALLA SI ES PRODUCTO O SERVICIO
SELECT TOP 200 [FV010_SSoPROD], COUNT(*) AS CANT
  FROM [PVTWEB].[dbo].[FV010_FVREP]
GROUP BY [FV010_SSoPROD]
--	Producto	119139
--	Servicio	79093


-- DETALLA LOS TIPOS DE CARGOS
SELECT TOP 200 [FV010_FCCARGO], COUNT(*) AS CANT
  FROM [PVTWEB].[dbo].[FV010_FVREP]
GROUP BY [FV010_FCCARGO]


--		20044
--	Tagle - Clientes	148009
--	Tagle - Empleados	170
--	Tagle - Garantias Fabrica	19147
--	Tagle - Gerencia	386
--	Tagle - Planes Ahorro	1098
--	Tagle - Repuestos	212
--	Tagle - Taller Chapa y Pintura - Ate. Clientes	544
--	Tagle - Taller Chapa y Pintura - Garantias Int.	21
--	Tagle - Taller Mecanico - Ate. Clientes	3137
--	Tagle - Usados	455
--	Tagle - Ventas 	4589
--	Tagle -Taller Mecanico - Garantias Int.	420

-- DETALLA LOS EMPLEADOS
SELECT TOP 200 [FV010_EMPNOMB], COUNT(*) AS CANT
  FROM [PVTWEB].[dbo].[FV010_FVREP]
GROUP BY [FV010_EMPNOMB]
ORDER BY COUNT(*) DESC
--	FW_SYS_USER	45744
--	REYNA JORGE GABRIEL	17301
--	GUIGNARD DANIEL	17090
--	COSTANZO HERNAN FEDERICO (E)	16743
--	FABIANA GRACIELA CLAVEL	15395
--	SANCHEZ CARLOS ALBERTO	14985
--	KOLLER GUSTAVO CESAR	7666

-- FALTA EL TIPO DE ORDEN DE REPARACION, SI ES SERVICIO, REPARACION, GARANTIA, ETC.