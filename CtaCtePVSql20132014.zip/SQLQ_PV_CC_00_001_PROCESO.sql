-- VERIFICACI�N DE LOS ESTADOS DE LOS COMPROBANTES
SELECT SP.[GPR03_PROETM]
	,PR.[GPR01_ETMDEC]
	,SP.[PCC03_PRETCOM02]
	,COUNT(*) AS TOTAL
	, CAST(SUM(CASE WHEN [PCC03_CPBTETIPO] = 'Fac' THEN [PCC03_CPBTESLDO] 
					WHEN [PCC03_CPBTETIPO] = 'Deb' THEN [PCC03_CPBTESLDO] 
					WHEN [PCC03_CPBTETIPO] = 'Rec' THEN [PCC03_CPBTESLDO] * -1
					WHEN [PCC03_CPBTETIPO] = 'Cre' THEN [PCC03_CPBTESLDO] * -1
					END) AS INT) AS TotPes
	--SELECT TOP 100 *
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP
		INNER JOIN (SELECT GP01.[GPR01_PRETMID]
						  ,GP01.[GPR01_PROCOD]
						  ,GP01.[GPR01_PROETM]
						  ,GP01.[GPR01_ETMDEC]
						  ,GP02.[GPR02_ETCOID]
						  ,GP02.[GPR02_ETACOD]
						  ,GP02.[GPR02_ETADEC]
						  ,GP03.[GPR03_MOTID]
						  ,GP03.[GPR03_MOTCOD]
						  ,GP03.[GPR03_MOTDEC]
					  FROM [PVTWEB].[dbo].[GPR01_PROGES] AS GP01
						INNER JOIN (SELECT [GPR02_ETCOID]
										  ,[GPR02_ETACOD]
										  ,[GPR02_ETADEC]
									  FROM [PVTWEB].[dbo].[GPR02_ETAPAS]
									) AS GP02 ON
							GP01.[GPR02_ETCOID] = GP02.[GPR02_ETCOID]
						INNER JOIN (SELECT [GPR03_MOTID]
										  ,[GPR03_MOTCOD]
										  ,[GPR03_MOTDEC]
									  FROM [PVTWEB].[dbo].[GPR03_MOTIVO]
									) AS GP03 ON
							GP01.[GPR03_MOTID] = GP03.[GPR03_MOTID]
					 ) AS PR ON 
			SP.[GPR03_PROETM] = PR.[GPR01_PROETM]
GROUP BY SP.[GPR03_PROETM]
	,PR.[GPR01_ETMDEC]
	,SP.[PCC03_PRETCOM02]
ORDER BY SP.[GPR03_PROETM]


-- DETALLE DE LOS PROCESOS
SELECT GP01.[GPR01_PRETMID]
      ,GP01.[GPR01_PROCOD]
      ,GP01.[GPR01_PROETM]
      ,GP01.[GPR01_ETMDEC]
      ,GP02.[GPR02_ETCOID]
	  ,GP02.[GPR02_ETACOD]
	  ,GP02.[GPR02_ETADEC]
      ,GP03.[GPR03_MOTID]
	  ,GP03.[GPR03_MOTCOD]
	  ,GP03.[GPR03_MOTDEC]
  FROM [PVTWEB].[dbo].[GPR01_PROGES] AS GP01
	INNER JOIN (SELECT [GPR02_ETCOID]
					  ,[GPR02_ETACOD]
					  ,[GPR02_ETADEC]
				  FROM [PVTWEB].[dbo].[GPR02_ETAPAS]
				) AS GP02 ON
		GP01.[GPR02_ETCOID] = GP02.[GPR02_ETCOID]
	INNER JOIN (SELECT [GPR03_MOTID]
					  ,[GPR03_MOTCOD]
					  ,[GPR03_MOTDEC]
				  FROM [PVTWEB].[dbo].[GPR03_MOTIVO]
				) AS GP03 ON
		GP01.[GPR03_MOTID] = GP03.[GPR03_MOTID]

--CCC_001_01	Cob Cta Cte	CMP EMI	PTE ENT	Comprobante Emitidas Pendientes de Entregar
--CCC_002_01	Cob Cta Cte	CMP EMI	REC CLI	Comprobante Rechazadas por el Cliente por alg�n inconveniente
--CCC_003_01	Cob Cta Cte	CMP EMI	PLA VEN	Comprobante que se venci� el plazo para entragarlas al Cliente
--CCC_004_01	Cob Cta Cte	CMP EMI	DOC EXT	Comprobante extraviadas internamente
--CCC_004_02	Cob Cta Cte	CMP EMI	DOC EXP	Comprobante extraviadas por el proveedor
--CCC_004_03	Cob Cta Cte	CMP EMI	DOC DES	Comprobante desconocido / No se conoce su origen
--CCC_005_01	Cob Cta Cte	CMP ENT	PTE COB	Comprobante entregadas pendientes de cobrar
--CCC_006_01	Cob Cta Cte	CMP ENT	PLA VEN	Comprobante que se venci� el plazo de pago comprometido
--CCC_007_01	Cob Cta Cte	CMP ENT	DOC OBJ	Comprobante entregadas con objeciones del Cliente
--CCC_007_02	Cob Cta Cte	CMP ENT	MUN HAB	Comprobante entregadas en la Habilitaci�n Municipal
--CCC_007_03	Cob Cta Cte	CMP ENT	MUN EXP	Comprobante entregadas en Expediente
--CCC_007_04	Cob Cta Cte	CMP ENT	G10 SHA	Comprobante entregadas Gestion 2010 Sin Habilitaci�n definida
--CCC_007_05	Cob Cta Cte	CMP ENT	G11 SHA	Comprobante entregadas Gestion 2011 Sin Habilitaci�n definida
--CCC_007_06	Cob Cta Cte	CMP ENT	CON CLI	Comprobante entregadas en conciliacion con Cliente
--CCC_007_07	Cob Cta Cte	CMP ENT	LIC PTE	Comprobante entregadas para una licitacion
--CCC_007_08	Cob Cta Cte	CMP ENT	CON APB	Comprobante entregadas en conciliacion Aprobadas por Cliente
--CCC_008_01	Cob Cta Cte	CMP COB	PTE IMP	Comprobante cobradas pendientes de la imputaci�n en Calipso
--CCC_008_02	Cob Cta Cte	CMP COB	G10 PIM	Comprobante cobradas Gesti�n 2010 Pendiente de Imputar
--CCC_008_03	Cob Cta Cte	CMP COB	G11 PIM	Comprobante cobradas Gesti�n 2010 Pendiente de Imputar
--CCC_008_04	Cob Cta Cte	CMP COB	ACC VTA	Comprobante cobradas en Ventas Pte imputar a Accesorios
--CCC_008_05	Cob Cta Cte	CMP COB	PIA MCC	Comprobante cobradas Pte Imputacion Autom�tica Mismo Centro de Costos
--CCC_008_06	Cob Cta Cte	CMP COB	PIA DCC	Comprobante cobradas Pte Imputacion Autom�tica Distinto Centro de Costos
--CCC_009_01	Cob Cta Cte	CMP COB	DOC IMP	Comprobante cobradas imputadas en Calipso
--CCC_009_02	Cob Cta Cte	CMP COB	DOC 001	Comprobante cobradas Pendiente de Ajustar en Calipso
--CCC_010_01	Cob Cta Cte	CMP FIN	FAC FIN	Comprobante pasadas al hist�rico
--****************************************************************************************************************************
-- fin
--****************************************************************************************************************************


