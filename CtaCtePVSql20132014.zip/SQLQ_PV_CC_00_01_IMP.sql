---- Borrar todas las Bases de Datos
--SELECT TOP 100 * FROM [PVTWEB].[dbo].[PCC01_DATIMP]
--DELETE FROM [PVTWEB].[dbo].[PCC01_DATIMP]
--
--SELECT TOP 100 * FROM [PVTWEB].[dbo].[PCC02_DATEMP]
--DELETE FROM [PVTWEB].[dbo].[PCC02_DATEMP]
--
--SELECT TOP 100 * FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
--DELETE FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
--
--SELECT TOP 100 * FROM [PVTWEB].[dbo].[PCC04_SDOHST]
--DELETE FROM [PVTWEB].[dbo].[PCC04_SDOHST]
--
--SELECT TOP 100 * FROM [PVTWEB].[dbo].[PCC05_RESPON]
--DELETE FROM [PVTWEB].[dbo].[PCC05_RESPON]
--
--SELECT TOP 100 * FROM [PVTWEB].[dbo].[PCC06_PROIMP]
--DELETE FROM [PVTWEB].[dbo].[PCC06_PROIMP]
--
--SELECT TOP 100 * FROM [PVTWEB].[dbo].[PCC07_PROHIST]
--DELETE FROM [PVTWEB].[dbo].[PCC07_PROHIST]
--
--SELECT TOP 100 * FROM [PVTWEB].[dbo].[PCC072_DATACT]
--DELETE FROM [PVTWEB].[dbo].[PCC072_DATACT]
--
--SELECT TOP 100 * FROM [PVTWEB].[dbo].[PCC074_RESPACT]
--DELETE FROM [PVTWEB].[dbo].[PCC074_RESPACT]
--
--SELECT TOP 100 * FROM [PVTWEB].[dbo].[PCC08_CLITIPO]
---- DELETE FROM [PVTWEB].[dbo].[PCC08_CLITIPO]
--
--SELECT TOP 100 * FROM [PVTWEB].[dbo].[PCCT_DATEMP]
---- DELETE FROM [PVTWEB].[dbo].[PCCT_DATEMP]


-- Borra la Tabla donde importa los datos desde el TXT.
DELETE FROM [PVTWEB].[dbo].[PCC01_DATIMP]

-- Importa los datos a la Tabla con todos los campos nvarchar(255)
--BULK INSERT [PVTWEB].[dbo].[PCC01_DATIMP]
--   FROM 'C:\bcp\CCBaseCalipso_2013_03_01.txt'
--   WITH 
--      (	 DATAFILETYPE = 'char',
--         FIELDTERMINATOR = '\t',		--\t = tabulador	; Comas
--         ROWTERMINATOR = '\n', 
--		 MAXERRORS = 5 
--		 --ERRORFILE = 'C:\Users\juan.petri\TAGLE\LISTA DE PRECIOS\LISTA PRECIO TALLER\LP TALL 2012 02 FEB\SQLErrImp.txt' 
--      )

-- CONSULTA TARDA 5 MINUTOS 
INSERT INTO [PVTWEB].[dbo].[PCC01_DATIMP]
           ([PCC01_CTAID]
		   ,[PCC01_CTACOD]
           ,[PCC01_CTADEN]
           ,[PCC01_CTACLI]
           ,[PCC01_CLITIPO]
           ,[PCC01_CLITELCONT]
           ,[PCC01_CLICELU]
           ,[PCC01_CLITELLAB]
           ,[PCC01_CLITELPART]
           ,[PCC01_CLIEMAIL]
           ,[PCC01_CLIPROV]
           ,[PCC01_CLICIUD]
           ,[PCC01_CPBFECEMI]
           ,[PCC01_CPBFECVTO]
           ,[PCC01_CPBTETIPO]
           ,[PCC01_CPBTESLDO]
           ,[PCC01_CPBTENUM]
           ,[PCC01_CPBTEID]
           ,[PCC01_CPBCCCOD]
           ,[PCC01_CPBCCDES]
           ,[PCC01_CPBTETOT]
           ,[PCC01_CPBTEAUX1]
           ,[PCC01_CPBTEAUX2]
           ,[PCC01_TIPOVTACOD]
           ,[PCC01_TIPOVTANOM]
           ,[PCC01_CPBTESOL]
           ,[PCC01_CPBTEGRUP]
           ,[PCC01_CPBTENOTA]
           ,[PCC01_CPBTEDETA]
           ,[PCC01_CODTIPVTA]
           ,[PCC01_SUCCOD]
           ,[PCC01_SUCNOMB]
           ,[PCC01_TIPOTALLER]
           ,[PCC01_CPBTEORD]
           ,[PCC01_OTRECEPT]
           ,[PCC01_OTTIPTRAB]
           ,[PCC01_OTCARGO]
		   ,[PCC01_OTESTADO]
           ,[PCC01_OTMES]
           ,[PCC01_OTFECHA]
           ,[PCC01_OTFECHEJEC]
           ,[PCC01_OTFECHFIN]
           ,[PCC01_OTIMPED]
           ,[PCC01_OTANOMAL]
           ,[PCC01_OTDIAGNOST]
           ,[PCC01_OTINCIDENT]
           ,[PCC01_OTDETALLE]
           ,[PCC01_OTVEHDOMIN]
           ,[PCC01_OTVEHKILOM]
           ,[PCC01_OTVEHMARC]
           ,[PCC01_OTVEHMODE]
           ,[PCC01_OTVEHSUBMOD]
           ,[PCC01_OTVEHMOTOR]
           ,[PCC01_OTVEHNUMCHAS]
           ,[PCC01_OTVEHUSUABRIOT]
           ,[PCC01_OTFVID])
	   SELECT [PCC01_CTAID]
			  ,[PCC01_CTACOD]
			  ,[PCC01_CTADEN]
			  ,[PCC01_CTACLI]
			  ,[PCC01_CLITIPO]
			  ,[PCC01_CLITELCONT]
			  ,[PCC01_CLICELU]
			  ,[PCC01_CLITELLAB]
			  ,[PCC01_CLITELPART]
			  ,[PCC01_CLIEMAIL]
			  ,[PCC01_CLIPROV]
			  ,[PCC01_CLICIUD]
			  ,[PCC01_CPBFECEMI]
			  ,[PCC01_CPBFECVTO]
			  ,[PCC01_CPBTETIPO]
			  ,[PCC01_CPBTESLDO]
			  ,[PCC01_CPBTENUM]
			  ,[PCC01_CPBTEID]
			  ,[PCC01_CPBCCCOD]
			  ,[PCC01_CPBCCDES]
			  ,[PCC01_CPBTETOT]
			  ,[PCC01_CPBTEAUX1]
			  ,[PCC01_CPBTEAUX2]
			  ,[PCC01_TIPOVTACOD]
			  ,[PCC01_TIPOVTANOM]
			  ,[PCC01_CPBTESOL]
			  ,[PCC01_CPBTEGRUP]
			  ,[PCC01_CPBTENOTA]
			  ,[PCC01_CPBTEDETA]
			  ,[PCC01_CODTIPVTA]
			  ,[PCC01_SUCCOD]
			  ,[PCC01_SUCNOMB]
			  ,[PCC01_TIPOTALLER]
			  ,[PCC01_CPBTEORD]
			  ,[PCC01_OTRECEPT]
			  ,[PCC01_OTTIPTRAB]
			  ,[PCC01_OTCARGO]
			  ,[PCC01_OTESTADO]
			  ,[PCC01_OTMES]
			  ,[PCC01_OTFECHA]
			  ,[PCC01_OTFECHEJEC]
			  ,[PCC01_OTFECHFIN]
			  ,[PCC01_OTIMPED]
			  ,[PCC01_OTANOMAL]
			  ,[PCC01_OTDIAGNOST]
			  ,[PCC01_OTINCIDENT]
			  ,[PCC01_OTDETALLE]
			  ,[PCC01_OTVEHDOMIN]
			  ,[PCC01_OTVEHKILOM]
			  ,[PCC01_OTVEHMARC]
			  ,[PCC01_OTVEHMODE]
			  ,[PCC01_OTVEHSUBMOD]
			  ,[PCC01_OTVEHMOTOR]
			  ,[PCC01_OTVEHNUMCHAS]
			  ,[PCC01_OTVEHUSUABRIOT]
			  ,[PCC01_OTFVID]
       FROM	[SYS-REPLICA].[CalipsoReplicado].[dbo].[VP_JCP_CTACTE] WITH (NOLOCK)

-- Borra los t�tulos
DELETE FROM [PVTWEB].[dbo].[PCC01_DATIMP] WHERE [PCC01_CTACOD] IS NULL OR [PCC01_CTACOD] = '	' OR [PCC01_CTACOD] = 'codigo'
-- Borra los totales
DELETE FROM [PVTWEB].[dbo].[PCC01_DATIMP] WHERE [PCC01_CPBFECEMI] = '//'
-- Borra las filas que no corresponden
DELETE FROM [PVTWEB].[dbo].[PCC01_DATIMP] WHERE [PCC01_CPBTETIPO] = 'SALDO TOTAL CUENTA'


-- Pasa la informaci�n depurada a la tabla Temporaria - Esto sirve para actualizar la Base de SDOPTE
DELETE FROM [PVTWEB].[dbo].[PCC02_DATEMP]
INSERT INTO [PVTWEB].[dbo].[PCC02_DATEMP]
           ([PCC02_CTAID]
		   ,[PCC02_CTACOD]
           ,[PCC02_CTADEN]
           ,[PCC02_CTACLI]
           ,[PCC02_CLITIPO]
           ,[PCC02_CLITELCONT]
           ,[PCC02_CLICELU]
           ,[PCC02_CLITELLAB]
           ,[PCC02_CLITELPART]
           ,[PCC02_CLIEMAIL]
           ,[PCC02_CLIPROV]
           ,[PCC02_CLICIUD]
           ,[PCC02_CPBFECEMI]
           ,[PCC02_CPBFECVTO]
           ,[PCC02_CPBTETIPO]
           ,[PCC02_CPBTESLDO]
           ,[PCC02_CPBTENUM]
           ,[PCC02_CPBTEID]
           ,[PCC02_CPBCCCOD]
           ,[PCC02_CPBCCDES]
           ,[PCC02_CPBTETOT]
           ,[PCC02_CPBTEAUX1]
           ,[PCC02_CPBTEAUX2]
           ,[PCC02_TIPOVTACOD]
           ,[PCC02_TIPOVTANOM]
           ,[PCC02_CPBTESOL]
           ,[PCC02_CPBTEGRUP]
           ,[PCC02_CPBTENOTA]
           ,[PCC02_CPBTEDETA]
           ,[PCC02_SUCCOD]
           ,[PCC02_SUCNOMB]
           ,[PCC02_TIPOTALLER]
           ,[PCC02_CPBTEORD]
           ,[PCC02_OTRECEPT]
           ,[PCC02_OTTIPTRAB]
           ,[PCC02_OTCARGO]
           ,[PCC02_OTESTADO]
           ,[PCC02_OTMES]
           ,[PCC02_OTFECHA]
           ,[PCC02_OTFECHEJEC]
           ,[PCC02_OTFECHFIN]
           ,[PCC02_OTIMPED]
           ,[PCC02_OTANOMAL]
           ,[PCC02_OTDIAGNOST]
           ,[PCC02_OTINCIDENT]
           ,[PCC02_OTDETALLE]
           ,[PCC02_OTVEHDOMIN]
           ,[PCC02_OTVEHKILOM]
           ,[PCC02_OTVEHMARC]
           ,[PCC02_OTVEHMODE]
           ,[PCC02_OTVEHSUBMOD]
           ,[PCC02_OTVEHMOTOR]
           ,[PCC02_OTVEHNUMCHAS]
           ,[PCC02_OTVEHUSUABRIOT]
           ,[PCC02_OTFVID])
		SELECT DISTINCT [PCC01_CTAID]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_CTACOD])), '	', '') AS INT) AS [PCC02_CTACOD]
			  ,[PCC01_CTADEN] AS [PCC02_CTADEN]
			  ,[PCC01_CTACLI] AS [PCC02_CTACLI]
			  ,[PCC01_CLITIPO] AS [PCC02_CLITIPO]
			  ,[PCC01_CLITELCONT] AS [PCC02_CLITELCONT]
			  ,[PCC01_CLICELU] AS [PCC02_CLICELU]
			  ,[PCC01_CLITELLAB] AS [PCC02_CLITELLAB]
			  ,[PCC01_CLITELPART] AS [PCC02_CLITELPART]
			  ,[PCC01_CLIEMAIL] AS [PCC02_CLIEMAIL]
			  ,[PCC01_CLIPROV] AS [PCC02_CLIPROV]
			  ,[PCC01_CLICIUD] AS [PCC02_CLICIUD]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBFECEMI])), '	', '') AS SMALLDATETIME) AS [PCC02_CPBFECEMI]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBFECVTO])), '	', '') AS SMALLDATETIME) AS [PCC02_CPBFECVTO]
			  ,[PCC01_CPBTETIPO] AS [PCC02_CPBTETIPO]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBTESLDO])), '	', '') AS DECIMAL(22,4)) AS [PCC02_CPBTESLDO]
			  ,[PCC01_CPBTENUM] AS [PCC02_CPBTENUM]
			  ,[PCC01_CPBTEID] AS [PCC02_CPBTEID]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBCCCOD])), '	', '') AS INT) AS [PCC02_CPBCCCOD]
			  ,[PCC01_CPBCCDES] AS [PCC02_CPBCCDES]
			  ,[PCC01_CPBTETOT] AS [PCC02_CPBTETOT]
			  ,[PCC01_CPBTEAUX1] AS [PCC02_CPBTEAUX1]
			  ,[PCC01_CPBTEAUX2] AS [PCC02_CPBTEAUX2]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_TIPOVTACOD])), '	', '') AS SMALLINT) AS [PCC02_TIPOVTACOD]
			  ,[PCC01_TIPOVTANOM] AS [PCC02_TIPOVTANOM]
			  ,[PCC01_CPBTESOL] AS [PCC02_CPBTESOL]
			  ,[PCC01_CPBTEGRUP] AS [PCC02_CPBTEGRUP]
			  ,[PCC01_CPBTENOTA] AS [PCC02_CPBTENOTA]
			  ,[PCC01_CPBTEDETA] AS [PCC02_CPBTEDETA]
--			  ,[PCC01_CODTIPVTA]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_SUCCOD])), '	', '') AS SMALLINT) AS [PCC02_SUCCOD]
			  ,[PCC01_SUCNOMB] AS [PCC02_SUCNOMB]
			  ,[PCC01_TIPOTALLER] AS [PCC02_TIPOTALLER]
			  ,[PCC01_CPBTEORD] AS [PCC02_CPBTEORD]
			  ,[PCC01_OTRECEPT] AS [PCC02_OTRECEPT]
			  ,[PCC01_OTTIPTRAB] AS [PCC02_OTTIPTRAB]
			  ,[PCC01_OTCARGO] AS [PCC02_OTCARGO]
			  ,[PCC01_OTESTADO] AS [PCC02_OTESTADO]
			  ,[PCC01_OTMES] AS [PCC02_OTMES]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_OTFECHA])), '	', '') AS SMALLDATETIME) AS [PCC02_OTFECHA]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_OTFECHEJEC])), '	', '') AS SMALLDATETIME) AS [PCC02_OTFECHEJEC]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_OTFECHFIN])), '	', '') AS SMALLDATETIME) AS [PCC02_OTFECHFIN]
			  ,[PCC01_OTIMPED] AS [PCC02_OTIMPED]
			  ,[PCC01_OTANOMAL] AS [PCC02_OTANOMAL]
			  ,[PCC01_OTDIAGNOST] AS [PCC02_OTDIAGNOST]
			  ,[PCC01_OTINCIDENT] AS [PCC02_OTINCIDENT]
			  ,[PCC01_OTDETALLE] AS [PCC02_OTDETALLE]
			  ,[PCC01_OTVEHDOMIN] AS [PCC02_OTVEHDOMIN]
			  ,[PCC01_OTVEHKILOM] AS [PCC02_OTVEHKILOM]
			  ,[PCC01_OTVEHMARC] AS [PCC02_OTVEHMARC]
			  ,[PCC01_OTVEHMODE] AS [PCC02_OTVEHMODE]
			  ,[PCC01_OTVEHSUBMOD] AS [PCC02_OTVEHSUBMOD]
			  ,[PCC01_OTVEHMOTOR] AS [PCC02_OTVEHMOTOR]
			  ,[PCC01_OTVEHNUMCHAS] AS [PCC02_OTVEHNUMCHAS]
			  ,[PCC01_OTVEHUSUABRIOT] AS [PCC02_OTVEHUSUABRIOT]
			  ,[PCC01_OTFVID] AS [PCC02_OTFVID]
		  FROM [PVTWEB].[dbo].[PCC01_DATIMP]

-- ACTUALIZA LA FECHA DE ACTUALIZACION
UPDATE [PVTWEB].[dbo].[PCC02_DATEMP]
   SET [PCC02_FECACT] = CAST(CONVERT(VARCHAR(10), GETDATE(),103) AS SMALLDATETIME)
 
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- INICIO				VERIFICA QUE NO HAYA VALORES DUPLICADOS
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
SELECT PC.*
FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
	INNER JOIN (-- VALORES DUPLICADOS
				SELECT [PCC02_CPBTEID] AS CLAVE02 
				FROM [PVTWEB].[dbo].[PCC02_DATEMP]
				GROUP BY [PCC02_CPBTEID]
				HAVING COUNT(*) > 1
				) AS CD ON
		PC.[PCC02_CPBTEID] = CD.CLAVE02
ORDER BY PC.[PCC02_CPBTEID]

-- ELIMINA DUPLICADOS, DONDE EL OTCARGO ES VACIO
DELETE [PVTWEB].[dbo].[PCC02_DATEMP]
WHERE [PCC02_OTCARGO] = ''
	AND [PCC02_CPBTEID] IN (
							SELECT PC.[PCC02_CPBTEID]
--								, PC.*
							FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
								INNER JOIN (-- VALORES DUPLICADOS
											SELECT [PCC02_CPBTEID] AS CLAVE02 
											FROM [PVTWEB].[dbo].[PCC02_DATEMP]
											GROUP BY [PCC02_CPBTEID]
											HAVING COUNT(*) > 1
											) AS CD ON
									PC.[PCC02_CPBTEID] = CD.CLAVE02
							WHERE [PCC02_OTCARGO] = ''
--							ORDER BY PC.[PCC02_CPBTEID]
							)


-- ELIMINA DUPLICADOS, DONDE EL OTCARGO ES Tagle - Clientes Y Tagle - Garantias Fabrica
DELETE [PVTWEB].[dbo].[PCC02_DATEMP]
WHERE [PCC02_OTCARGO] = 'Tagle - Garantias Fabrica'
	AND [PCC02_CPBTEID] IN (
							SELECT PC.[PCC02_CPBTEID]
--								, PC.*
							FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
								INNER JOIN (-- VALORES DUPLICADOS
											SELECT [PCC02_CPBTEID] AS CLAVE02 
											FROM [PVTWEB].[dbo].[PCC02_DATEMP]
											GROUP BY [PCC02_CPBTEID]
											HAVING COUNT(*) > 1
											) AS CD ON
									PC.[PCC02_CPBTEID] = CD.CLAVE02
--							ORDER BY PC.[PCC02_CPBTEID]
							)


-- ELIMINA DUPLICADOS, DONDE EL OTCARGO ES Tagle - Clientes Y Tagle - Ventas
DELETE [PVTWEB].[dbo].[PCC02_DATEMP]
WHERE [PCC02_OTCARGO] = 'Tagle - Ventas'
	AND [PCC02_CPBTEID] IN (
							SELECT PC.[PCC02_CPBTEID]
--								, PC.*
							FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
								INNER JOIN (-- VALORES DUPLICADOS
											SELECT [PCC02_CPBTEID] AS CLAVE02 
											FROM [PVTWEB].[dbo].[PCC02_DATEMP]
											GROUP BY [PCC02_CPBTEID]
											HAVING COUNT(*) > 1
											) AS CD ON
									PC.[PCC02_CPBTEID] = CD.CLAVE02
--							ORDER BY PC.[PCC02_CPBTEID]
							)

-- ELIMINA DUPLICADOS, DONDE EL OTCARGO ES Tagle - Clientes Y Tagle - Ventas
DELETE [PVTWEB].[dbo].[PCC02_DATEMP]
WHERE [PCC02_OTCARGO] = 'Tagle - Planes Ahorro'
	AND [PCC02_CPBTEID] IN (
							SELECT PC.[PCC02_CPBTEID]
--								, PC.*
							FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
								INNER JOIN (-- VALORES DUPLICADOS
											SELECT [PCC02_CPBTEID] AS CLAVE02 
											FROM [PVTWEB].[dbo].[PCC02_DATEMP]
											GROUP BY [PCC02_CPBTEID]
											HAVING COUNT(*) > 1
											) AS CD ON
									PC.[PCC02_CPBTEID] = CD.CLAVE02
--							ORDER BY PC.[PCC02_CPBTEID]
							)

DELETE [PVTWEB].[dbo].[PCC02_DATEMP]
WHERE [PCC02_OTCARGO] = 'Tagle - Gerencia'
	AND [PCC02_CPBTEID] IN (
							SELECT PC.[PCC02_CPBTEID]
--								, PC.*
							FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
								INNER JOIN (-- VALORES DUPLICADOS
											SELECT [PCC02_CPBTEID] AS CLAVE02 
											FROM [PVTWEB].[dbo].[PCC02_DATEMP]
											GROUP BY [PCC02_CPBTEID]
											HAVING COUNT(*) > 1
											) AS CD ON
									PC.[PCC02_CPBTEID] = CD.CLAVE02
--							ORDER BY PC.[PCC02_CPBTEID]
							)

-- VERIFICA QUE NO HAYA DUPLICADOS
SELECT PC.*
FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
	INNER JOIN (-- VALORES DUPLICADOS
				SELECT [PCC02_CPBTEID] AS CLAVE02 
				FROM [PVTWEB].[dbo].[PCC02_DATEMP]
				GROUP BY [PCC02_CPBTEID]
				HAVING COUNT(*) > 1
				) AS CD ON
		PC.[PCC02_CPBTEID] = CD.CLAVE02
ORDER BY PC.[PCC02_CPBTEID]


-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- FIN					VERIFICA QUE NO HAYA VALORES DUPLICADOS
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

-- Borra la Base con los datos importados
DELETE FROM [PVTWEB].[dbo].[PCC01_DATIMP]
--
---- CONTROL DE UN CLIENTE PUNTUAL
--SELECT TOP 100 *
--FROM [PVTWEB].[dbo].[PCC02_DATEMP]
--WHERE [PCC02_CTACOD] = 200018616


-- #############################################################################################################
--                                          INICIO
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Ahora hay que actualizar la base SDOPTE y pasar al Hist�rico los comprobantes cancelados
SELECT *
FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
WHERE [PCC03_CPBTEID] IN (-- AQU� LISTAMOS LOS COMPROBANTES QUE ESTAN EN LA TABLA [PCC03_SDOPTE] Y NO EN LA TABLA [PCC02_DATEMP]
						  SELECT [PCC03_CPBTEID] AS CLAVEN 
						   FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SDO 
								LEFT OUTER JOIN (-- NOS DA EL LISTADO DE LOS CPTES PENDIENTES UNICOS
												  SELECT [PCC02_CPBTEID] AS CLAVE02 
												  FROM [PVTWEB].[dbo].[PCC02_DATEMP]
												  GROUP BY [PCC02_CPBTEID]
												  HAVING COUNT(*) = 1
												 ) AS SDOLU ON
														SDO.[PCC03_CPBTEID] = SDOLU.CLAVE02
							WHERE SDOLU.CLAVE02 IS NULL
						   )

-- PRIMERO SE DEBE MARCAR LOS REGISTROS A ACTUALIZAR
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
SET [PCC03_ACTCOD] = 'CPTE_NO_PTE'
WHERE [PCC03_CPBTEID] IN (-- AQU� LISTAMOS LOS COMPROBANTES QUE ESTAN EN LA TABLA [PCC03_SDOPTE] Y NO EN LA TABLA [PCC02_DATEMP]
						  SELECT [PCC03_CPBTEID] AS CLAVEN 
						   FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SDO 
								LEFT OUTER JOIN (-- NOS DA EL LISTADO DE LOS CPTES PENDIENTES UNICOS
												  SELECT [PCC02_CPBTEID] AS CLAVE02 
												  FROM [PVTWEB].[dbo].[PCC02_DATEMP]
												  GROUP BY [PCC02_CPBTEID]
												  HAVING COUNT(*) = 1
												 ) AS SDOLU ON
														SDO.[PCC03_CPBTEID] = SDOLU.CLAVE02
							WHERE SDOLU.CLAVE02 IS NULL
						   )


-- Actualiza la Tabla de procesos, los comprobantes que no estan antes de que se les cambie 
-- el codigo de la etapa del proceso hay que actualizar el hist�rico
INSERT INTO [PVTWEB].[dbo].[PCC07_PROHIST]
           ([PCC07_CPBTEID]
           ,[PCC07_PROETM_ANT]
           ,[PCC07_PRETCOM_ANT]
		   ,[PCC07_PRETCOM2_ANT]
           ,[PCC07_PRETFECH_ANT]
           ,[PCC07_PROETM_ACT]
           ,[PCC07_PRETCOM_ACT]
		   ,[PCC07_PRETCOM2_ACT]
           ,[PCC07_PRETFECH_ACT])
	SELECT [PCC03_CPBTEID]
			,[GPR03_PROETM]
			,[PCC03_PRETCOM]
			,[PCC03_PRETCOM]
			,[PCC03_PRETFECH]
			,'CCC_010_01' AS [PROETM_ACT]
			,'Act aut, por no estar m�s pte en calipso' AS [PRETCOM_ACT]
		    ,'Act aut, por no estar m�s pte en calipso' AS [PRETCOM2_ACT]
			,CAST(GETDATE() AS SMALLDATETIME) AS [PRETFECH_ACT]
-- SELECT TOP 10 *
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
	WHERE [PCC03_ACTCOD] = 'CPTE_NO_PTE'


-- Actualiza los comprobantes que ya fueron cancelados, no estan en la nueva base de datos
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
SET [GPR03_PROETM] = 'CCC_010_01'			-- Este es el final del proceso
	,[PCC03_PRETCOM] = 'Act aut, por no estar m�s pte en calipso'
	,[PCC03_PRETCOM02] = 'Act aut, por no estar m�s pte en calipso'
	,[PCC03_PRETFECH] = CAST(GETDATE() AS SMALLDATETIME)
WHERE [PCC03_ACTCOD] = 'CPTE_NO_PTE'


-- INSERTA LOS DATOS QUE YA TIENEN EL FINAL A LA TABLA HISTORICO
INSERT INTO [PVTWEB].[dbo].[PCC04_SDOHST]
           ([PCC04_CTAID]
		   ,[PCC04_CTACOD]
           ,[PCC04_CTADEN]
           ,[PCC04_CTACLI]
           ,[PCC04_CLITIPO]
           ,[PCC04_CLITELCONT]
           ,[PCC04_CLICELU]
           ,[PCC04_CLITELLAB]
           ,[PCC04_CLITELPART]
           ,[PCC04_CLIEMAIL]
           ,[PCC04_CLIPROV]
           ,[PCC04_CLICIUD]
           ,[PCC04_CPBFECEMI]
           ,[PCC04_CPBFECVTO]
           ,[PCC04_CPBTETIPO]
           ,[PCC04_CPBTESLDO]
           ,[PCC04_CPBTENUM]
           ,[PCC04_CPBTEID]
           ,[PCC04_CPBCCCOD]
           ,[PCC04_CPBCCDES]
           ,[PCC04_CPBTETOT]
           ,[PCC04_CPBTEAUX1]
           ,[PCC04_CPBTEAUX2]
           ,[PCC04_TIPOVTACOD]
           ,[PCC04_TIPOVTANOM]
           ,[PCC04_CPBTESOL]
           ,[PCC04_CPBTEGRUP]
           ,[PCC04_CPBTENOTA]
           ,[PCC04_CPBTEDETA]
           ,[PCC04_SUCCOD]
           ,[PCC04_SUCNOMB]
           ,[PCC04_TIPOTALLER]
           ,[PCC04_CPBTEORD]
           ,[PCC04_OTRECEPT]
           ,[PCC04_OTTIPTRAB]
           ,[PCC04_OTCARGO]
           ,[PCC04_OTESTADO]
           ,[PCC04_OTMES]
           ,[PCC04_OTFECHA]
           ,[PCC04_OTFECHEJEC]
           ,[PCC04_OTFECHFIN]
           ,[PCC04_OTIMPED]
           ,[PCC04_OTANOMAL]
           ,[PCC04_OTDIAGNOST]
           ,[PCC04_OTINCIDENT]
           ,[PCC04_OTDETALLE]
           ,[PCC04_OTVEHDOMIN]
           ,[PCC04_OTVEHKILOM]
           ,[PCC04_OTVEHMARC]
           ,[PCC04_OTVEHMODE]
           ,[PCC04_OTVEHSUBMOD]
           ,[PCC04_OTVEHMOTOR]
           ,[PCC04_OTVEHNUMCHAS]
           ,[PCC04_OTVEHUSUABRIOT]
           ,[PCC04_OTFVID]
           ,[GPR04_PROETM]
           ,[PCC04_PRETCOM]
		   ,[PCC04_PRETCOM02]
           ,[PCC04_PRETFECH]
           ,[PCC04_ACTCOD])
	SELECT [PCC03_CTAID]
		  ,[PCC03_CTACOD]
		  ,[PCC03_CTADEN]
		  ,[PCC03_CTACLI]
		  ,[PCC03_CLITIPO]
		  ,[PCC03_CLITELCONT]
		  ,[PCC03_CLICELU]
		  ,[PCC03_CLITELLAB]
		  ,[PCC03_CLITELPART]
		  ,[PCC03_CLIEMAIL]
		  ,[PCC03_CLIPROV]
		  ,[PCC03_CLICIUD]
		  ,[PCC03_CPBFECEMI]
		  ,[PCC03_CPBFECVTO]
		  ,[PCC03_CPBTETIPO]
		  ,[PCC03_CPBTESLDO]
		  ,[PCC03_CPBTENUM]
		  ,[PCC03_CPBTEID]
		  ,[PCC03_CPBCCCOD]
		  ,[PCC03_CPBCCDES]
		  ,[PCC03_CPBTETOT]
		  ,[PCC03_CPBTEAUX1]
		  ,[PCC03_CPBTEAUX2]
		  ,[PCC03_TIPOVTACOD]
		  ,[PCC03_TIPOVTANOM]
		  ,[PCC03_CPBTESOL]
		  ,[PCC03_CPBTEGRUP]
		  ,[PCC03_CPBTENOTA]
		  ,[PCC03_CPBTEDETA]
		  ,[PCC03_SUCCOD]
		  ,[PCC03_SUCNOMB]
		  ,[PCC03_TIPOTALLER]
		  ,[PCC03_CPBTEORD]
		  ,[PCC03_OTRECEPT]
		  ,[PCC03_OTTIPTRAB]
		  ,[PCC03_OTCARGO]
		  ,[PCC03_OTESTADO]
		  ,[PCC03_OTMES]
		  ,[PCC03_OTFECHA]
		  ,[PCC03_OTFECHEJEC]
		  ,[PCC03_OTFECHFIN]
		  ,[PCC03_OTIMPED]
		  ,[PCC03_OTANOMAL]
		  ,[PCC03_OTDIAGNOST]
		  ,[PCC03_OTINCIDENT]
		  ,[PCC03_OTDETALLE]
		  ,[PCC03_OTVEHDOMIN]
		  ,[PCC03_OTVEHKILOM]
		  ,[PCC03_OTVEHMARC]
		  ,[PCC03_OTVEHMODE]
		  ,[PCC03_OTVEHSUBMOD]
		  ,[PCC03_OTVEHMOTOR]
		  ,[PCC03_OTVEHNUMCHAS]
		  ,[PCC03_OTVEHUSUABRIOT]
		  ,[PCC03_OTFVID]
		  ,[GPR03_PROETM]
		  ,[PCC03_PRETCOM]
		  ,[PCC03_PRETCOM02]
		  ,[PCC03_PRETFECH]
		  ,[PCC03_ACTCOD]
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
	WHERE [PCC03_ACTCOD] = 'CPTE_NO_PTE'
		AND GPR03_PROETM = 'CCC_010_01'	-- Ultima etapa del proceso

-- Borra los comprobantes que ya fueron pasados al hist�rico
DELETE FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
WHERE [PCC03_ACTCOD] = 'CPTE_NO_PTE'
		AND GPR03_PROETM = 'CCC_010_01'
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--                                          FIN
-- #############################################################################################################


-- #############################################################################################################
--                                          INICIO
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Actualiza EL ESTADO Y PROCESO DE los comprobantes de la Tabla PCC02_DATEMP desde la Tabla PCC03_SDOPTE que luego se borrar�n
UPDATE [PVTWEB].[dbo].[PCC02_DATEMP]
SET [PCC02_ACTCOD] = 'CPTE_SI_PTE'
	,[GPR02_PROETM] = SDOLU.[GPR03_PROETM]
	,[PCC02_PRETCOM] = SDOLU.[PCC03_PRETCOM]
	,[PCC02_PRETCOM02] = SDOLU.[PCC03_PRETCOM02]
	,[PCC02_PRETFECH] = SDOLU.[PCC03_PRETFECH]
--SELECT TOP 100 SDOLU.[GPR01_PROETM], *
FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS SDO 
	INNER JOIN (-- NOS DA EL LISTADO DE LOS CPTES PENDIENTES UNICOS
				SELECT [PCC03_CPBTEID] AS CLAVE03
						,[GPR03_PROETM]
						,[PCC03_PRETCOM]
						,[PCC03_PRETCOM02]
						,[PCC03_PRETFECH]
				FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
				GROUP BY [PCC03_CPBTEID]
						,[GPR03_PROETM]
						,[PCC03_PRETCOM]
						,[PCC03_PRETCOM02]
						,[PCC03_PRETFECH]
				HAVING COUNT(*) = 1
				) AS SDOLU ON 
					SDO.[PCC02_CPBTEID] = SDOLU.CLAVE03

-- Actualiza los registros nuevos en la etapa inicial
UPDATE [PVTWEB].[dbo].[PCC02_DATEMP]
SET [GPR02_PROETM] = 'CCC_001_01' 
	,[PCC02_ACTCOD] = 'CPTE_SI_PTE_NVO'
WHERE [PCC02_ACTCOD] IS NULL
	AND [GPR02_PROETM] IS NULL

-- Actualiza la Fecha del Inicio del Proceso con la Fecha de Emisi�n del comprobante si el estado del proceso es inicial
UPDATE [PVTWEB].[dbo].[PCC02_DATEMP]
   SET [PCC02_PRETFECH] = CAST([PCC02_CPBFECEMI] AS SMALLDATETIME)
 WHERE [GPR02_PROETM] = 'CCC_001_01'

-- ACTUALIZA EL C�DIGO DE LA ODR DESDE EL TELSOL (este es para asegurarnos que todas las FC tienen Numero de ODR)
UPDATE [PVTWEB].[dbo].[PCC02_DATEMP]
   SET [PCC02_CPBTEORD] = [PCC02_CPBTESOL]
 WHERE [PCC02_CPBTEORD] IS NULL 
	AND [PCC02_CPBTESOL] IS NOT NULL

--SELECT TOP 10000 [PCC03_CPBTEORD], [PCC03_CPBTESOL]
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
-- WHERE [PCC03_CPBTEORD] IS NULL AND [PCC03_CPBTESOL] IS NOT NULL

-- ACTUALIZA EL C�DIGO DE LA ODR DESDE EL AUX1
UPDATE [PVTWEB].[dbo].[PCC02_DATEMP]
   SET [PCC02_CPBTEORD] = CASE WHEN ISNUMERIC(LEFT([PCC02_CPBTEAUX1],10)) = 1 THEN LEFT([PCC02_CPBTEAUX1],10) ELSE NULL END
 WHERE [PCC02_CPBTEORD] IS NULL 
	AND CASE WHEN ISNUMERIC(LEFT([PCC02_CPBTEAUX1],10)) = 1 THEN LEFT([PCC02_CPBTEAUX1],10) ELSE NULL END IS NOT NULL

--SELECT TOP 10000 [PCC03_CPBTEORD]
--	,CASE WHEN ISNUMERIC(LEFT([PCC03_CPBTEAUX1],10)) = 1 THEN LEFT([PCC03_CPBTEAUX1],10) ELSE NULL END AS ODRIZQ
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
-- WHERE [PCC03_CPBTEORD] IS NULL AND CASE WHEN ISNUMERIC(LEFT([PCC03_CPBTEAUX1],10)) = 1 THEN LEFT([PCC03_CPBTEAUX1],10) ELSE NULL END IS NOT NULL

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

-- Borra TODOS los comprobantes de la base de pendientes, ya que se van a importar nuevamente de la base [PCC03_SDOPTE]
DELETE FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
-- Inserta los datos nuevos ya actualizados
INSERT INTO [PVTWEB].[dbo].[PCC03_SDOPTE]
           ([PCC03_CTAID]
		   ,[PCC03_CTACOD]
           ,[PCC03_CTADEN]
           ,[PCC03_CTACLI]
           ,[PCC03_CLITIPO]
           ,[PCC03_CLITELCONT]
           ,[PCC03_CLICELU]
           ,[PCC03_CLITELLAB]
           ,[PCC03_CLITELPART]
           ,[PCC03_CLIEMAIL]
           ,[PCC03_CLIPROV]
           ,[PCC03_CLICIUD]
           ,[PCC03_CPBFECEMI]
           ,[PCC03_CPBFECVTO]
           ,[PCC03_CPBTETIPO]
           ,[PCC03_CPBTESLDO]
           ,[PCC03_CPBTENUM]
           ,[PCC03_CPBTEID]
           ,[PCC03_CPBCCCOD]
           ,[PCC03_CPBCCDES]
           ,[PCC03_CPBTETOT]
           ,[PCC03_CPBTEAUX1]
           ,[PCC03_CPBTEAUX2]
           ,[PCC03_TIPOVTACOD]
           ,[PCC03_TIPOVTANOM]
           ,[PCC03_CPBTESOL]
           ,[PCC03_CPBTEGRUP]
           ,[PCC03_CPBTENOTA]
           ,[PCC03_CPBTEDETA]
           ,[PCC03_SUCCOD]
           ,[PCC03_SUCNOMB]
           ,[PCC03_TIPOTALLER]
           ,[PCC03_CPBTEORD]
           ,[PCC03_OTRECEPT]
           ,[PCC03_OTTIPTRAB]
           ,[PCC03_OTCARGO]
           ,[PCC03_OTESTADO]
           ,[PCC03_OTMES]
           ,[PCC03_OTFECHA]
           ,[PCC03_OTFECHEJEC]
           ,[PCC03_OTFECHFIN]
           ,[PCC03_OTIMPED]
           ,[PCC03_OTANOMAL]
           ,[PCC03_OTDIAGNOST]
           ,[PCC03_OTINCIDENT]
           ,[PCC03_OTDETALLE]
           ,[PCC03_OTVEHDOMIN]
           ,[PCC03_OTVEHKILOM]
           ,[PCC03_OTVEHMARC]
           ,[PCC03_OTVEHMODE]
           ,[PCC03_OTVEHSUBMOD]
           ,[PCC03_OTVEHMOTOR]
           ,[PCC03_OTVEHNUMCHAS]
           ,[PCC03_OTVEHUSUABRIOT]
           ,[PCC03_OTFVID]
           ,[GPR03_PROETM]
           ,[PCC03_PRETCOM]
		   ,[PCC03_PRETCOM02]
           ,[PCC03_PRETFECH]
           ,[PCC03_ACTCOD])
		SELECT [PCC02_CTAID]
		  ,[PCC02_CTACOD]
		  ,[PCC02_CTADEN]
		  ,[PCC02_CTACLI]
		  ,[PCC02_CLITIPO]
		  ,[PCC02_CLITELCONT]
		  ,[PCC02_CLICELU]
		  ,[PCC02_CLITELLAB]
		  ,[PCC02_CLITELPART]
		  ,[PCC02_CLIEMAIL]
		  ,[PCC02_CLIPROV]
		  ,[PCC02_CLICIUD]
		  ,[PCC02_CPBFECEMI]
		  ,[PCC02_CPBFECVTO]
		  ,[PCC02_CPBTETIPO]
		  ,[PCC02_CPBTESLDO]
		  ,[PCC02_CPBTENUM]
		  ,[PCC02_CPBTEID]
		  ,[PCC02_CPBCCCOD]
		  ,[PCC02_CPBCCDES]
		  ,[PCC02_CPBTETOT]
		  ,[PCC02_CPBTEAUX1]
		  ,[PCC02_CPBTEAUX2]
		  ,[PCC02_TIPOVTACOD]
		  ,[PCC02_TIPOVTANOM]
		  ,[PCC02_CPBTESOL]
		  ,[PCC02_CPBTEGRUP]
		  ,[PCC02_CPBTENOTA]
		  ,[PCC02_CPBTEDETA]
		  ,[PCC02_SUCCOD]
		  ,[PCC02_SUCNOMB]
		  ,[PCC02_TIPOTALLER]
		  ,[PCC02_CPBTEORD]
		  ,[PCC02_OTRECEPT]
		  ,[PCC02_OTTIPTRAB]
		  ,[PCC02_OTCARGO]
		  ,[PCC02_OTESTADO]
		  ,[PCC02_OTMES]
		  ,[PCC02_OTFECHA]
		  ,[PCC02_OTFECHEJEC]
		  ,[PCC02_OTFECHFIN]
		  ,[PCC02_OTIMPED]
		  ,[PCC02_OTANOMAL]
		  ,[PCC02_OTDIAGNOST]
		  ,[PCC02_OTINCIDENT]
		  ,[PCC02_OTDETALLE]
		  ,[PCC02_OTVEHDOMIN]
		  ,[PCC02_OTVEHKILOM]
		  ,[PCC02_OTVEHMARC]
		  ,[PCC02_OTVEHMODE]
		  ,[PCC02_OTVEHSUBMOD]
		  ,[PCC02_OTVEHMOTOR]
		  ,[PCC02_OTVEHNUMCHAS]
		  ,[PCC02_OTVEHUSUABRIOT]
		  ,[PCC02_OTFVID]
		  ,[GPR02_PROETM]
		  ,[PCC02_PRETCOM]
		  ,[PCC02_PRETCOM02]
		  ,[PCC02_PRETFECH]
		  ,[PCC02_ACTCOD]
	  FROM [PVTWEB].[dbo].[PCC02_DATEMP]

-- BORRA EL CAMPO QUE SIRVE PARA MARCAR LAS ACTUALIZACIONES Y LA FECHA EN QUE SE ACTUALIZARON LOS DATOS
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
SET [PCC03_ACTCOD] = NULL
	, [PCC03_FECACT] = CAST(CONVERT(NVARCHAR(10), GETDATE(), 103) AS SMALLDATETIME)


-- ACTUALIZA LA FECHA DE ACTUALIZACION
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_FECACT] = CAST(CONVERT(VARCHAR(10), GETDATE(),103) AS SMALLDATETIME)

-- Borra los datos de la tabla temporaria
DELETE FROM [PVTWEB].[dbo].[PCC02_DATEMP]

-- CONTROL
--SELECT *
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
--WHERE [PCC03_TIPOVTANOM] = 'Taller de Chapa'
--	AND [PCC03_CTACOD] = 201023450
	
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--                                          FIN
-- #############################################################################################################



-- #############################################################################################################
--											INICIO	AJUSTES + o -
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@

---- PONE TODO A CERO, EXCEPTO LO QUE ES IGUAL AL MOMENTO INICIAL
--UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
--   SET [PCC03_ACTCOD] = NULL
--	  ,[GPR03_PROETM] = 'CCC_001_01'
--      ,[PCC03_PRETCOM] = NULL
--	  ,[PCC03_PRETFECH] = NULL
--WHERE [GPR03_PROETM] <> 'CCC_001_01'
-- PONE A NULL EL CAMPO QUE MARCA LAS ACTUALIZACIONES
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE] SET [PCC03_ACTCOD] = NULL
-- ########################################################################################################################
-- ##################################################  INICIO PROCESO EnProcActFC+- $ ######################################
-- ########################################################################################################################
DECLARE @SaldoPesos AS INT
SET @SaldoPesos = 40		-- PESOS, PROCESE $20 Y $40
--
---- VERIFICA EL IMPACTO DEL MONTO DE LOS COMPROBANTES
--SELECT COUNT(*) AS CANTCOMP, CAST(SUM([PCC03_CPBTESLDO]) AS INT) AS TotPes
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
--WHERE [GPR03_PROETM] = 'CCC_001_01'
--	AND ([PCC03_CPBTESLDO] <= @SaldoPesos AND [PCC03_CPBTESLDO] >= -@SaldoPesos)

-- CENTROS DE COSTOS
--SELECT [PCC03_CPBCCCOD], COUNT(*) AS TOTAL
--	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
--GROUP BY [PCC03_CPBCCCOD]
--ORDER BY [PCC03_CPBCCCOD]

---- PRIMERO DEBE MARCAR LOS REGISTROS QUE ESTAR�N SUJETOS A ACTUALIZACI�N
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_ACTCOD] = 'EnProcActFC+-'
-- SELECT TOP 100 *
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [GPR03_PROETM] = 'CCC_001_01'
			AND ([PCC03_CPBTESLDO] <= @SaldoPesos AND [PCC03_CPBTESLDO] >= -@SaldoPesos)
--			AND ([PCC03_CPBCCCOD] = '2020101' OR [PCC03_CPBCCCOD] = '2020102' OR [PCC03_CPBCCCOD] = '2020103' OR [PCC03_CPBCCCOD] = '2020104' OR [PCC03_CPBCCCOD] = '2020105' OR [PCC03_CPBCCCOD] = '2020106' OR [PCC03_CPBCCCOD] = '2020107' OR [PCC03_CPBCCCOD] = '2020108')


-- SEGUNDO DEBE PASAR LA INFORMACI�N AL HIST�RICO
INSERT INTO [PVTWEB].[dbo].[PCC07_PROHIST]
           ([PCC07_CPBTEID]
           ,[PCC07_PROETM_ANT]
           ,[PCC07_PRETCOM_ANT]
		   ,[PCC07_PRETCOM2_ANT]
           ,[PCC07_PRETFECH_ANT]
           ,[PCC07_PROETM_ACT]
           ,[PCC07_PRETCOM_ACT]
		   ,[PCC07_PRETCOM2_ACT]
           ,[PCC07_PRETFECH_ACT]
		   ,[PCC07_CPBCCCOD]
		   ,[PCC07_CTASLDO])
	SELECT [PCC03_CPBTEID]
			,[GPR03_PROETM] AS [PROETM_ANT]
			,[PCC03_PRETCOM] AS [PRETCOM_ANT]
			,[PCC03_PRETCOM02] AS [PRETCOM2_ANT]
			,[PCC03_PRETFECH] AS [PRETFECH_ANT]
			,'CCC_009_02' AS [PROETM_ACT]
			,'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos' AS [PRETCOM_ACT]
		    ,'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos' AS [PRETCOM2_ACT]
			,CAST(GETDATE() AS SMALLDATETIME) AS [PRETFECH_ACT]
			,[PCC03_CPBCCCOD]
			,[PCC03_CPBTESLDO]
--SELECT TOP 100 COUNT(*) AS TOTAL
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [PCC03_ACTCOD] = 'EnProcActFC+-'


-- LUEGO DEBE ACTUALIZAR LA NUEVA INFO
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [GPR03_PROETM] = 'CCC_009_02'
      ,[PCC03_PRETCOM] = 'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos'
	  ,[PCC03_PRETCOM02] = 'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos'
	  ,[PCC03_PRETFECH] = CAST(GETDATE() AS SMALLDATETIME)
--SELECT TOP 1000 [PCC03_CPBTEID], [GPR01_PROETM],[PCC03_PRETCOM], DA.*
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [PCC03_ACTCOD] = 'EnProcActFC+-'

-- BORRA LA MARCA
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_ACTCOD] = NULL
WHERE [PCC03_ACTCOD] = 'EnProcActFC+-'


--
--
--UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
--   SET [PCC03_PRETCOM02] = [PCC03_PRETCOM]
--WHERE [GPR03_PROETM] = 'CCC_009_02'
--
--
--SELECT [GPR03_PROETM], [PCC03_PRETCOM], [PCC03_PRETCOM02], COUNT(*) AS TOTAL
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
--WHERE [GPR03_PROETM] = 'CCC_009_02'
--GROUP BY [GPR03_PROETM], [PCC03_PRETCOM], [PCC03_PRETCOM02]
-- ************************************************************************************************************************************
---- CONTROL DE LA ACTUALIZACI�N
SELECT [PCC03_PRETCOM]
		, COUNT(*) AS CANTCOMP
		, CAST(SUM(CASE WHEN [PCC03_CPBTETIPO] = 'Fac' THEN [PCC03_CPBTESLDO] 
					 WHEN [PCC03_CPBTETIPO] = 'Deb' THEN [PCC03_CPBTESLDO] 
					 WHEN [PCC03_CPBTETIPO] = 'Rec' THEN [PCC03_CPBTESLDO] * -1
					 WHEN [PCC03_CPBTETIPO] = 'Cre' THEN [PCC03_CPBTESLDO] * -1
					 END) AS INT) AS TotPes
FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
WHERE [GPR03_PROETM] = 'CCC_009_02'
GROUP BY [PCC03_PRETCOM]


DECLARE @SaldoPesos AS INT
SET @SaldoPesos = 20		-- PESOS, PROCESE $5 Y $20

SELECT *
FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
WHERE [GPR03_PROETM] = 'CCC_009_02'
	AND [PCC03_PRETCOM] = 'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos'
ORDER BY [PCC03_CPBTESLDO]

-- ########################################################################################################################
-- ##################################################  FIN PROCESO EnProcActFC+- $ #########################################
-- ########################################################################################################################


-- ########################################################################################################################
-- INICIO -- CARGA LOS CLIENTES EN LA TABLA DE CLIENTE RESP (ESTO ES POR CLIENTE Y CENTRO DE COSTOS)
-- ########################################################################################################################
-- INICIO ACTUALIZA ID DE CLIENTE ############################################################################################################################
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_CTAID] = CLI.[GRL010_CLIID]
--		SELECT TOP 10 CLI.[GRL010_CLIID], *
		FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CCT 
			INNER JOIN [PVTWEB].[dbo].[GRL010_CLIENT] AS CLI ON
				CCT.[PCC03_CTACOD] = CLI.[GRL010_CLICOD]


UPDATE [PVTWEB].[dbo].[PCC031_SDOPTEEVOL]
   SET [PCC031_CTAID] = CLI.[GRL010_CLIID]
--		SELECT TOP 10 CLI.[GRL010_CLIID], *
		FROM [PVTWEB].[dbo].[PCC031_SDOPTEEVOL] AS CCE 
			INNER JOIN [PVTWEB].[dbo].[GRL010_CLIENT] AS CLI ON
				CCE.[PCC031_CTACOD] = CLI.[GRL010_CLICOD]


UPDATE [PVTWEB].[dbo].[PCC04_SDOHST]
   SET [PCC04_CTAID] = CLI.[GRL010_CLIID]
--		SELECT TOP 10 CLI.[GRL010_CLIID], *
		FROM [PVTWEB].[dbo].[PCC04_SDOHST] AS CCH 
			INNER JOIN [PVTWEB].[dbo].[GRL010_CLIENT] AS CLI ON
				CCH.[PCC04_CTACOD] = CLI.[GRL010_CLICOD]


-- FIN ############################################################################################################################


INSERT INTO [PVTWEB].[dbo].[GRL012_CLIRESP]
           (
			[GRL012_CLIID]
           ,[GRL012_CLICOD]
           ,[GRL012_CLICCTO]
           ,[GRL012_CLIRAZSOC]
           ,[GRL012_CLINOMABR]
--           ,[GRL012_CLIRESPNOM]
--           ,[GRL012_CLIRESPID]
			)
	-- LISTA LOS CLIENTES Y SUS CENTROS DE COSTOS QUE TODAVIA NO ESTAN EN LA TABLA DE RESPONSABLES
     SELECT [PCC03_CTAID], [PCC03_CTACOD], [PCC03_CPBCCCOD], [PCC03_CTADEN], LEFT([PCC03_CTADEN], 15) AS CLINOMABR
		FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CTACTE
			LEFT OUTER JOIN [PVTWEB].[dbo].[GRL012_CLIRESP] AS CLRES ON
				CTACTE.[PCC03_CTACOD] = CLRES.[GRL012_CLICOD]
					AND
				CTACTE.[PCC03_CPBCCCOD] = CLRES.[GRL012_CLICCTO]
	 WHERE CLRES.[GRL012_CLICOD] IS NULL
	 GROUP BY [PCC03_CTAID], [PCC03_CTACOD], [PCC03_CPBCCCOD], [PCC03_CTADEN], LEFT([PCC03_CTADEN], 15)
	 ORDER BY [PCC03_CTAID], [PCC03_CTACOD], [PCC03_CPBCCCOD]



-- ########################################################################################################################
-- FIN -- CARGA LOS CLIENTES EN LA TABLA DE CLIENTE RESP (ESTO ES POR CLIENTE Y CENTRO DE COSTOS)
-- ########################################################################################################################



-- ########################################################################################################################
-- INICIO -- BORRA LOS ESTADOS PASANDO LA INFO AL HISTORICO PRIMERO
-- ########################################################################################################################
DECLARE @PROETMAJUSTAR AS NVARCHAR(20)
SET @PROETMAJUSTAR = 'CCC_009_02'

-- MARCA LOS REGISTROS QUE SE VAN A ACTUALIZAR
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_ACTCOD] = 'MOD ESTADO'
--SELECT *
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [GPR03_PROETM] = @PROETMAJUSTAR
			AND [PCC03_PRETCOM] = 'Factura >=-$20 y <= $20 Pesos'
			AND [PCC03_CPBTESLDO] > 20
--			AND ([PCC03_CPBCCCOD] = '2020101' OR [PCC03_CPBCCCOD] = '2020102' OR [PCC03_CPBCCCOD] = '2020103' OR [PCC03_CPBCCCOD] = '2020104' OR [PCC03_CPBCCCOD] = '2020105' OR [PCC03_CPBCCCOD] = '2020106' OR [PCC03_CPBCCCOD] = '2020107' OR [PCC03_CPBCCCOD] = '2020108')
	
-- PRIMERO PASA LOS DATOS AL HISTORICO DE MOVIMIENTOS
INSERT INTO [PVTWEB].[dbo].[PCC07_PROHIST]
           ([PCC07_CPBTEID]
           ,[PCC07_PROETM_ANT]
           ,[PCC07_PRETCOM_ANT]
		   ,[PCC07_PRETCOM2_ANT]
           ,[PCC07_PRETFECH_ANT]
           ,[PCC07_PROETM_ACT]
           ,[PCC07_PRETCOM_ACT]
		   ,[PCC07_PRETCOM2_ACT]
           ,[PCC07_PRETFECH_ACT])
	SELECT [PCC03_CPBTEID]
			,[GPR03_PROETM] AS [PROETM_ANT]
			,[PCC03_PRETCOM] AS [PRETCOM_ANT]
			,[PCC03_PRETCOM02] AS [PRETCOM2_ANT]
			,[PCC03_PRETFECH] AS [PRETFECH_ANT]
			,'CCC_001_01' AS [PROETM_ACT]
			,'Borra la Info' AS [PRETCOM_ACT]
			,'Borra la Info' AS [PRETCOM2_ACT]
			,CAST(GETDATE() AS SMALLDATETIME) AS [PRETFECH_ACT]
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [PCC03_ACTCOD] = 'MOD ESTADO'

-- LUEGO DEBE ACTUALIZAR LA NUEVA INFO
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [GPR03_PROETM] = 'CCC_001_01'
      ,[PCC03_PRETCOM] = NULL
	  ,[PCC03_PRETCOM02] = NULL
	  ,[PCC03_PRETFECH] = CAST(GETDATE() AS SMALLDATETIME)
--SELECT TOP 1000 [PCC03_CPBTEID], [GPR01_PROETM],[PCC03_PRETCOM], DA.*
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [PCC03_ACTCOD] = 'MOD ESTADO'

-- BORRA LA MARCA LOS REGISTROS QUE SE VAN A ACTUALIZAR
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_ACTCOD] = NULL
FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
WHERE [PCC03_ACTCOD] = 'MOD ESTADO'


-- ########################################################################################################################
-- FIN -- BORRA LOS ESTADOS PASANDO LA INFO AL HISTORICO PRIMERO
-- ########################################################################################################################




-- ########################################################################################################################
--														PAPELES DE TRABAJO
-- ########################################################################################################################

--Nos da la info de un determinado c�digo
SELECT TOP 1000 * 
FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
WHERE [GPR03_PROETM] = 'CCC_009_02'

-- Resumen del Estado Motivo del Historico
SELECT PCC07_PROETM_ACT
	,PCC07_PROETM_ANT
	,COUNT(*) AS TOTAL
--SELECT TOP 10 *
FROM [PVTWEB].[dbo].[PCC07_PROHIST]
GROUP BY PCC07_PROETM_ACT
	,PCC07_PROETM_ANT
ORDER BY PCC07_PROETM_ACT
	,PCC07_PROETM_ANT





-- DETERMINA EL ANCHO DE CADA CAMPO
SELECT DISTINCT MAX(LEN([PCC01_CTAID])) AS [PCC01_CTAID] 
			  ,MAX(LEN(CAST(REPLACE(RTRIM(LTRIM([PCC01_CTACOD])), '	', '') AS INT))) AS [PCC02_CTACOD]
			  ,MAX(LEN([PCC01_CTADEN])) AS [PCC02_CTADEN]
			  ,MAX(LEN([PCC01_CTACLI])) AS [PCC02_CTACLI]
			  ,MAX(LEN([PCC01_CLITIPO])) AS [PCC02_CLITIPO]
			  ,MAX(LEN([PCC01_CLITELCONT])) AS [PCC02_CLITELCONT]
			  ,MAX(LEN([PCC01_CLICELU])) AS [PCC02_CLICELU]
			  ,MAX(LEN([PCC01_CLITELLAB])) AS [PCC02_CLITELLAB]
			  ,MAX(LEN([PCC01_CLITELPART])) AS [PCC02_CLITELPART]
			  ,MAX(LEN([PCC01_CLIEMAIL])) AS [PCC02_CLIEMAIL]
			  ,MAX(LEN([PCC01_CLIPROV])) AS [PCC02_CLIPROV]
			  ,MAX(LEN([PCC01_CLICIUD])) AS [PCC02_CLICIUD]
			  ,MAX(LEN(CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBFECEMI])), '	', '') AS SMALLDATETIME))) AS [PCC02_CPBFECEMI]
			  ,MAX(LEN(CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBFECVTO])), '	', '') AS SMALLDATETIME))) AS [PCC02_CPBFECVTO]
			  ,MAX(LEN([PCC01_CPBTETIPO])) AS [PCC02_CPBTETIPO]
			  ,MAX(LEN(CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBTESLDO])), '	', '') AS DECIMAL(22,4)))) AS [PCC02_CPBTESLDO]
			  ,MAX(LEN([PCC01_CPBTENUM])) AS [PCC02_CPBTENUM]
			  ,MAX(LEN([PCC01_CPBTEID])) AS [PCC02_CPBTEID]
			  ,MAX(LEN(CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBCCCOD])), '	', '') AS INT))) AS [PCC02_CPBCCCOD]
			  ,MAX(LEN([PCC01_CPBCCDES])) AS [PCC02_CPBCCDES]
			  ,MAX(LEN([PCC01_CPBTETOT])) AS [PCC02_CPBTETOT]
			  ,MAX(LEN([PCC01_CPBTEAUX1])) AS [PCC02_CPBTEAUX1]
			  ,MAX(LEN([PCC01_CPBTEAUX2])) AS [PCC02_CPBTEAUX2]
			  ,MAX(LEN(CAST(REPLACE(RTRIM(LTRIM([PCC01_TIPOVTACOD])), '	', '') AS SMALLINT))) AS [PCC02_TIPOVTACOD]
			  ,MAX(LEN([PCC01_TIPOVTANOM])) AS [PCC02_TIPOVTANOM]
			  ,MAX(LEN([PCC01_CPBTESOL])) AS [PCC02_CPBTESOL]
			  ,MAX(LEN([PCC01_CPBTEGRUP])) AS [PCC02_CPBTEGRUP]
			  ,MAX(LEN([PCC01_CPBTENOTA])) AS [PCC02_CPBTENOTA]
			  ,MAX(LEN([PCC01_CPBTEDETA])) AS [PCC02_CPBTEDETA]
--			  ,[PCC01_CODTIPVTA]
			  ,MAX(LEN(CAST(REPLACE(RTRIM(LTRIM([PCC01_SUCCOD])), '	', '') AS SMALLINT))) AS [PCC02_SUCCOD]
			  ,MAX(LEN([PCC01_SUCNOMB])) AS [PCC02_SUCNOMB]
			  ,MAX(LEN([PCC01_TIPOTALLER])) AS [PCC02_TIPOTALLER]
			  ,MAX(LEN([PCC01_CPBTEORD])) AS [PCC02_CPBTEORD]
			  ,MAX(LEN([PCC01_OTRECEPT])) AS [PCC02_OTRECEPT]
			  ,MAX(LEN([PCC01_OTTIPTRAB])) AS [PCC02_OTTIPTRAB]
			  ,MAX(LEN([PCC01_OTCARGO])) AS [PCC02_OTCARGO]
			  ,MAX(LEN([PCC01_OTESTADO])) AS [PCC02_OTESTADO]
			  ,MAX(LEN([PCC01_OTMES])) AS [PCC02_OTMES]
			  ,MAX(LEN(CAST(REPLACE(RTRIM(LTRIM([PCC01_OTFECHA])), '	', '') AS SMALLDATETIME))) AS [PCC02_OTFECHA]
			  ,MAX(LEN(CAST(REPLACE(RTRIM(LTRIM([PCC01_OTFECHEJEC])), '	', '') AS SMALLDATETIME))) AS [PCC02_OTFECHEJEC]
			  ,MAX(LEN(CAST(REPLACE(RTRIM(LTRIM([PCC01_OTFECHFIN])), '	', '') AS SMALLDATETIME))) AS [PCC02_OTFECHFIN]
			  ,MAX(LEN([PCC01_OTIMPED])) AS [PCC02_OTIMPED]
			  ,MAX(LEN([PCC01_OTANOMAL])) AS [PCC02_OTANOMAL]
			  ,MAX(LEN([PCC01_OTDIAGNOST])) AS [PCC02_OTDIAGNOST]
			  ,MAX(LEN([PCC01_OTINCIDENT])) AS [PCC02_OTINCIDENT]
			  ,MAX(LEN([PCC01_OTDETALLE])) AS [PCC02_OTDETALLE]
			  ,MAX(LEN([PCC01_OTVEHDOMIN])) AS [PCC02_OTVEHDOMIN]
			  ,MAX(LEN([PCC01_OTVEHKILOM])) AS [PCC02_OTVEHKILOM]
			  ,MAX(LEN([PCC01_OTVEHMARC])) AS [PCC02_OTVEHMARC]
			  ,MAX(LEN([PCC01_OTVEHMODE])) AS [PCC02_OTVEHMODE]
			  ,MAX(LEN([PCC01_OTVEHSUBMOD])) AS [PCC02_OTVEHSUBMOD]
			  ,MAX(LEN([PCC01_OTVEHMOTOR])) AS [PCC02_OTVEHMOTOR]
			  ,MAX(LEN([PCC01_OTVEHNUMCHAS])) AS [PCC02_OTVEHNUMCHAS]
			  ,MAX(LEN([PCC01_OTVEHUSUABRIOT])) AS [PCC02_OTVEHUSUABRIOT]
			  ,MAX(LEN([PCC01_OTFVID])) AS [PCC02_OTFVID]
		  FROM [PVTWEB].[dbo].[PCC01_DATIMP]

