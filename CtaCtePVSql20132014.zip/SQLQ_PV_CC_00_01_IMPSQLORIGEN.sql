SELECT TOP 100 CLI.CODIGO AS [PCC01_CTACOD]	-- TABLA DATOS DE LOS CLIENTES
		, CLI.DENOMINACION AS [PCC01_CTADEN]	-- TABLA DATOS DE LOS CLIENTES
		, PER.NOMBRE AS [PCC01_CTACLI]	-- TABLA DATOS DEL PERSONAL
		, FOT.[TipoCliente] AS [PCC01_CLITIPO]
		, FOT.[TelefonoContacto] AS [PCC01_CLITELCONT]
		, FOT.[Celular] AS [PCC01_CLICELU]
		, FOT.[TelefonoLaboral] AS [PCC01_CLITELLAB]
		, FOT.[TelefonoParticular] AS [PCC01_CLITELPART]
		, FOT.[Email] AS [PCC01_CLIEMAIL]
		, FOT.[ProvinciaCliente] AS [PCC01_CLIPROV]
		, FOT.[CiudadCliente] AS [PCC01_CLICIUD]
		, SUBSTRING(CP.FECHAEMISION,7,2) + '/' + SUBSTRING(CP.FECHAEMISION,5,2) + '/' + SUBSTRING(CP.FECHAEMISION,0,5) AS [PCC01_CPBFECEMI]
		, SUBSTRING(CP.FECHAVENCIMIENTO,7,2) + '/' + SUBSTRING(CP.FECHAVENCIMIENTO,5,2) + '/' + SUBSTRING(CP.FECHAVENCIMIENTO,0,5) AS [PCC01_CPBFECVTO]
--			, CP.FECHAEMISION
--			, CP.FECHAVENCIMIENTO
		, CASE CP.TIPO WHEN 'CPFACTURA' THEN 'Fac' 
						WHEN 'CPDEBITO' THEN 'Deb' 
						WHEN 'CPCREDITO' THEN 'Cre' 
						WHEN 'CPRECIBO' THEN 'Rec'
						END AS [PCC01_CPBTETIPO]
		, CP.SALDO2_IMPORTE AS [PCC01_CPBTESLDO]
		, CP.DESCRIPCION AS [PCC01_CPBTENUM]
		, CP.TRORIGINANTE_ID AS [PCC01_CPBTEID]
		, CC.CODIGO AS [PCC01_CPBCCCOD]
		, CC.NOMBRE AS [PCC01_CPBCCDES]
		, CASE WHEN (CP.TIPO IN ('CPFACTURA', 'CPDEBITO') AND CP.IMTOTAL2_UNIDADVALORIZACION_ID = '0AB552E0-31DE-455B-A3F1-3A2FC195AFE2') THEN CP.IMTOTAL2_IMPORTE 
				ELSE CASE WHEN (CP.TIPO IN ('CPFACTURA', 'CPDEBITO') AND CP.IMTOTAL2_UNIDADVALORIZACION_ID <> '0AB552E0-31DE-455B-A3F1-3A2FC195AFE2') THEN CP.IMTOTAL2_IMPORTE * CP.TRCOTIZACION 
							ELSE CASE WHEN CP.IMTOTAL2_UNIDADVALORIZACION_ID = '0AB552E0-31DE-455B-A3F1-3A2FC195AFE2' THEN - 1 * CP.IMTOTAL2_IMPORTE 
										ELSE - 1 * CP.IMTOTAL2_IMPORTE * CP.TRCOTIZACION 
										END 
							END 
				END AS [PCC01_CPBTETOT]
		, CP.AUXILIAR1 AS [PCC01_CPBTEAUX1]
		, CP.AUXILIAR2 AS [PCC01_CPBTEAUX2]
--			, tf.sutipo AS TIPOCTACTE_ID
		, LEFT(CP.NOMCLASIFICADOR, 3) AS [PCC01_TIPOVTACOD]
		, CASE WHEN LEN(CP.NOMCLASIFICADOR) > 6 THEN RIGHT(CP.NOMCLASIFICADOR, LEN(CP.NOMCLASIFICADOR) - 6) 
				ELSE '' 
				END AS [PCC01_TIPOVTANOM]
--			, tf.AgrupadorTipoVenta_ID AS AGRUPADOR
		, tf.solicitud AS [PCC01_CPBTESOL]
		, tf.Grupo AS [PCC01_CPBTEGRUP]
		, tf.NOTA AS [PCC01_CPBTENOTA]
		, tf.DETALLE AS [PCC01_CPBTEDETA]
		, tf.CodigoTipoVenta AS [PCC01_CODTIPVTA]
--				, CP.OPERADORCOMERCIAL_ID
--			, tf.SUCURSAL_ID
		, SC.CODIGO AS [PCC01_SUCCOD] 
		, SC.NOMBRE AS [PCC01_SUCNOMB]
		, FOT.[TipoTaller] AS [PCC01_TIPOTALLER]
		, tf.Orden AS [PCC01_CPBTEORD]
		, FOT.[Receptor] AS [PCC01_OTRECEPT]
		, FOT.[TipoTrabajo] AS [PCC01_OTTIPTRAB]
--		, FOT.[TipoService] AS [PCC01_OTTIPSERV]
		, CASE WHEN FOT.[CargoOT] IS NULL THEN FOT.[Cargo] ELSE FOT.[CargoOT] END AS [PCC01_OTCARGO]
		, FOT.[Estado] AS [PCC01_OTESTADO]
		, FOT.[MesOT] AS [PCC01_OTMES]
	    , FOT.[FechaOT] AS [PCC01_OTFECHA]
	    , FOT.[FechaEjecucion] AS [PCC01_OTFECHEJEC]
	    , FOT.[FechaFinalizada] AS [PCC01_OTFECHFIN]
	    , FOT.[Impedimento] AS [PCC01_OTIMPED]
	    , FOT.Anomalias AS [PCC01_OTANOMAL]
	    , FOT.Diagnostico AS [PCC01_OTDIAGNOST]
	    , FOT.Incidentes AS [PCC01_OTINCIDENT]
--		, FOT.[AvisoCliente] AS [PCC01_OTAVISOCLI]
	    , FOT.[Detalle] AS [PCC01_OTDETALLE]
	    , FOT.[Dominio] AS [PCC01_OTVEHDOMIN]
		, FOT.[Kilometros] AS [PCC01_OTVEHKILOM]
	    , FOT.[Marca] AS [PCC01_OTVEHMARC]
	    , FOT.[Modelo] AS [PCC01_OTVEHMODE]
	    , FOT.[Submodelo] AS [PCC01_OTVEHSUBMOD]
	    , FOT.[Motor] AS [PCC01_OTVEHMOTOR]
	    , FOT.[NumeroChasis] AS [PCC01_OTVEHNUMCHAS]
		, FOT.USUABRIOOT AS [PCC01_OTVEHUSUABRIOT]
		, FOT.FVID AS [PCC01_OTFVID]
   FROM	[CalipsoProduccion].[dbo].[V_COMPROMISOPAGO] AS CP WITH (NOLOCK) 
		INNER JOIN [CalipsoProduccion].[dbo].[V_CLIENTE] AS CLI WITH (NOLOCK)	-- Tabla 
				ON CP.OPERADORCOMERCIAL_ID = CLI.ID 
		INNER JOIN [CalipsoProduccion].[dbo].[CLI_PETRI] AS CPVTA WITH (NOLOCK) 
				ON CP.CODIGOOPERADORCOMERCIAL = CPVTA.[cli_codigo] 
		INNER JOIN [CalipsoProduccion].[dbo].[V_PERSONA] AS PER WITH (NOLOCK)	-- Tabla con los datos de las personas
				ON CLI.ENTEASOCIADO_ID = PER.ID 
		INNER JOIN [CalipsoProduccion].[dbo].[CENTROCOSTOS] AS CC WITH (nolock) ON 
			CP.CENTROCOSTOS_ID = CC.ID 
		INNER JOIN (SELECT ID
							, TipoVenta_ID AS sutipo
							, AgrupadorTipoVenta_ID
							, solicitud
							, Grupo
							, Orden
							, NOTA
							, DETALLE
							, CodigoTipoVenta
							, SUCURSAL_ID
						FROM  [CalipsoProduccion].[dbo].[Vc_TipoFacturas_]
                     UNION ALL
                     SELECT ID
							, TipoVenta_ID AS sutipo
							, AgrupadorTipoVenta_ID
							, solicitud
							, Grupo
							, Orden
							, NOTA
							, DETALLE
							, CodigoTipoVenta
							, SUCURSAL_ID
						FROM [CalipsoProduccion].[dbo].[Vc_TipoDebitos_]
                     UNION ALL
                     SELECT ID
							, TipoVenta_ID AS sutipo
							, AgrupadorTipoVenta_ID
							, solicitud
							, Grupo
							, Orden
							, NOTA
							, DETALLE
							, CodigoTipoVenta
							, SUCURSAL_ID
						FROM [CalipsoProduccion].[dbo].[Vc_TipoCreditos_]
                     UNION ALL
                     SELECT ID
							, TipoRecibo_ID AS sutipo
							, AgrupadorTipoVenta_ID
							, solicitud
							, Grupo
							, Orden
							, NOTA
							, DETALLE
							, CodigoTipoVenta
							, SUCURSAL_ID
						FROM [CalipsoProduccion].[dbo].[Vc_TipoRecibos_]
					) AS tf 
							ON tf.ID = CP.TRORIGINANTE_ID
		INNER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS SC WITH (NOLOCK) ON
				tf.SUCURSAL_ID = SC.ID
		LEFT OUTER JOIN (SELECT OT.*
							, OV.USUARIO AS USUABRIOOT
	--						, OV.NOMBRE AS OV
	--						, FV.NOMBRE AS FV
							, FV.ID AS FVID
						FROM [CalipsoProduccion].[dbo].[TRORDENVENTA] OV  WITH (NOLOCK)
							INNER JOIN	[CalipsoProduccion].[dbo].[TRPROCESOPORLOTE] AS TRPPL  WITH (NOLOCK) ON
								OV.ID = TRPPL.TRANSACCION_ID 
									AND	RELACION_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8' 
							INNER JOIN	[CalipsoProduccion].[dbo].[AGENTEPROCESOPORLOTE] AS APL WITH (NOLOCK) ON
								APL.TRSORIGEN_ID = TRPPL.BO_PLACE_ID
									AND	APL.RELACIONORIGEN_ID = '84F37DBB-911D-46C6-8645-92CEE27283D8' 
							INNER JOIN	[CalipsoProduccion].[dbo].[TRFACTURAVENTA] AS FV WITH (NOLOCK) ON
								APL.ID = FV.GENERADAPOR_ID
							INNER JOIN (SELECT DISTINCT [id]  -- VP ORDEN TRABAJO DETALLE
											  , [TipoTaller]
											  , [Sucursal]
											  , [OrdenTrabajo]
											  , [TipoTrabajo]
											  , [TipoService]
											  , [CargoOT]
											  , [Estado]
											  , [MesOT]
											  , [FechaOT]
											  , [FechaEjecucion]
											  , [FechaFinalizada]
										--      ,[MesUltimoestado]
										--      ,[MesTurno]
											  , [Receptor]
											  , [Cliente]
											  , [Empresa]
											  , [TipoCliente]
											  , [Retira]
											  , [TelefonoContacto]
											  , [Celular]
											  , [TelefonoLaboral]
											  , [TelefonoParticular]
											  , [Email]
											  , [ProvinciaCliente]
											  , [CiudadCliente]
										--      , [CodigoPostal]
										--      , [CALLE]
										--      , [FechaUltimoEstado]
										--      , [FechaVentaVehiculo]
										--      , [Fechaturno]
											  , [Impedimento]
										--      , [FechaFinGarantia]
											  , CAST([Anomalias] AS NVARCHAR(MAX)) AS Anomalias
											  , CAST([Diagnostico] AS NVARCHAR(MAX)) AS Diagnostico
											  , CAST([Incidentes] AS NVARCHAR(MAX)) AS Incidentes
											  , [Detalle]
											  , [Cargo]
											  , [Centrocostos]
											  , [DESCRIPCION]
											  , [Dominio]
											  , [Marca]
											  , [Modelo]
											  , [Submodelo]
											  , [Motor]
											  , [NumeroChasis]
											  , [Kilometros]
										--      , [CodigoReferencia]
										--      , [DescripcionReferencia]
										--      , [Cantidad]
										--      , [TotalCosto]
										--      , [TotalDescuento]
										--      , [TotalNeto]
										--      , [Rubro]
										--      , [Tipo]
										--      , [Canal]
											  , [AvisoCliente]
										  FROM [CalipsoProduccion].[dbo].[VP_OrdenTrabajo] WITH (NOLOCK)
										--WHERE ORDENTRABAJO = 16004
										) AS OT ON
								OV.ID = OT.ID
						 WHERE OV.TIPOTRANSACCION_ID = 'AEDA2553-10E7-4258-9E74-ACC1EAE15580'
					) AS FOT ON 
						CP.TRORIGINANTE_ID = FOT.FVID
	WHERE (CP.CPCOMPRAS = 'F') 
			AND (CP.PRIMERNIVEL = 'T') 
			AND (SUBSTRING(CLI.CODIGO, 1, 1) = '2') 
			AND (CP.SALDO2_IMPORTE <> '0') 
			AND (CP.SALDADO = 'F')
