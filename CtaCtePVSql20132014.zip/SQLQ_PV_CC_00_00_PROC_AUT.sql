-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 1
-- ###################################################################################################################################
DECLARE @NUEVOIDACT AS NVARCHAR(36) 
DECLARE @PROCNUM AS NUMERIC(18,0)

-- GENERA EL CODIGO PARA ESTE PROCESO, ESTO PERMITE QUE EN CADA ETAPA SEPARADA CARGUE EL MISMO CODIGO
-- PRIMERO BORRA EL CODIGO DEL PROCESO, ES POR LAS DUDAS SI HUBIERE
DELETE FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WHERE [GRL098_PROC] = 'CCTE_ACT'
INSERT INTO [PVTWEB].[dbo].[GRL098_PROCLAVE]
           ([GRL098_PROC]
           ,[GRL098_PROCNUM])
       SELECT 'CCTE_ACT', REPLACE(REPLACE(REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 120), '-', ''), ':', ''), ' ', '')

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'CCTE_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

-- Borra la Tabla donde importa los datos desde el TXT.
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC]              , [GRL099_FECINIC]                , [GRL099_FECFIN])
	 SELECT  @NUEVOIDACT   , 'CCTE_ACT'   , 1                 , @PROCNUM      , 'CCTE_IMPDAT'   , 'CCTE_DATBORR'  , '[PCC02_DATEMP]'  , 'Elimina datos de [PCC02_DATEMP]', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
DELETE FROM [PVTWEB].[dbo].[PCC01_DATIMP]
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 1
-- ###################################################################################################################################



-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 2
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'CCTE_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 2, @PROCNUM, 'CCTE_IMPDAT', 'CCTE_DATIMP', '[PCC02_DATEMP]', 'Importa datos del servidor', CAST(GETDATE() AS DATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
---- CARGA LOS NUEVOS CLIENTES QUE TIENEN SALDO EN POSTVENTA
DECLARE @RC int
EXECUTE @RC = [SYS-REPLICA].[CalipsoReplicado].[dbo].[JCP_CTACTECLIENTES] 

-- Importa el Detalle cuentas corrientes
INSERT INTO [PVTWEB].[dbo].[PCC02_DATEMP]
           ([PCC02_CTAID]
           ,[PCC02_CTACOD]
           ,[PCC02_CTADEN]
           ,[PCC02_CTACLI]
           ,[PCC02_CLITIPO]
           ,[PCC02_CLITELCONT]
           ,[PCC02_CLICELU]
           ,[PCC02_CLITELLAB]
           ,[PCC02_CLITELPART]
           ,[PCC02_CLIEMAIL]
           ,[PCC02_CLIPROV]
           ,[PCC02_CLICIUD]
           ,[PCC02_CPBFECEMI]
           ,[PCC02_CPBFECVTO]
           ,[PCC02_CPBTETIPO]
           ,[PCC02_CPBTESLDO]
           ,[PCC02_CPBTENUM]
           ,[PCC02_CPBTEID]
           ,[PCC02_CPBCCCOD]
           ,[PCC02_CPBCCDES]
           ,[PCC02_CPBTETOT]
           ,[PCC02_CPBTEAUX1]
           ,[PCC02_CPBTEAUX2]
           ,[PCC02_TIPOVTACOD]
           ,[PCC02_TIPOVTANOM]
           ,[PCC02_CPBTESOL]
           ,[PCC02_CPBTEGRUP]
           ,[PCC02_CPBTENOTA]
           ,[PCC02_CPBTEDETA]
           ,[PCC02_SUCCOD]
           ,[PCC02_SUCNOMB]
           ,[PCC02_TIPOTALLER]
           ,[PCC02_CPBTEORD]
           ,[PCC02_OTRECEPT]
           ,[PCC02_OTTIPTRAB]
           ,[PCC02_OTCARGO]
           ,[PCC02_OTESTADO]
           ,[PCC02_OTMES]
           ,[PCC02_OTFECHA]
           ,[PCC02_OTFECHEJEC]
           ,[PCC02_OTFECHFIN]
           ,[PCC02_OTIMPED]
           ,[PCC02_OTANOMAL]
           ,[PCC02_OTDIAGNOST]
           ,[PCC02_OTINCIDENT]
           ,[PCC02_OTDETALLE]
           ,[PCC02_OTVEHDOMIN]
           ,[PCC02_OTVEHKILOM]
           ,[PCC02_OTVEHMARC]
           ,[PCC02_OTVEHMODE]
           ,[PCC02_OTVEHSUBMOD]
           ,[PCC02_OTVEHMOTOR]
           ,[PCC02_OTVEHNUMCHAS]
           ,[PCC02_OTVEHUSUABRIOT]
           ,[PCC02_OTFVID]
--           ,[GPR02_PROETM]
--           ,[PCC02_PRETCOM]
--           ,[PCC02_PRETCOM02]
--           ,[PCC02_PRETFECH]
--           ,[PCC02_ACTCOD]
           ,[PCC02_FECACT])
		SELECT DISTINCT [PCC01_CTAID]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_CTACOD])), '	', '') AS INT) AS [PCC02_CTACOD]
			  ,[PCC01_CTADEN] AS [PCC02_CTADEN]
			  ,[PCC01_CTACLI] AS [PCC02_CTACLI]
			  ,[PCC01_CLITIPO] AS [PCC02_CLITIPO]
			  ,[PCC01_CLITELCONT] AS [PCC02_CLITELCONT]
			  ,[PCC01_CLICELU] AS [PCC02_CLICELU]
			  ,[PCC01_CLITELLAB] AS [PCC02_CLITELLAB]
			  ,[PCC01_CLITELPART] AS [PCC02_CLITELPART]
			  ,[PCC01_CLIEMAIL] AS [PCC02_CLIEMAIL]
			  ,[PCC01_CLIPROV] AS [PCC02_CLIPROV]
			  ,[PCC01_CLICIUD] AS [PCC02_CLICIUD]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBFECEMI])), '	', '') AS SMALLDATETIME) AS [PCC02_CPBFECEMI]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBFECVTO])), '	', '') AS SMALLDATETIME) AS [PCC02_CPBFECVTO]
			  ,[PCC01_CPBTETIPO] AS [PCC02_CPBTETIPO]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBTESLDO])), '	', '') AS DECIMAL(22,4)) AS [PCC02_CPBTESLDO]
			  ,[PCC01_CPBTENUM] AS [PCC02_CPBTENUM]
			  ,[PCC01_CPBTEID] AS [PCC02_CPBTEID]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBCCCOD])), '	', '') AS INT) AS [PCC02_CPBCCCOD]
			  ,[PCC01_CPBCCDES] AS [PCC02_CPBCCDES]
			  ,[PCC01_CPBTETOT] AS [PCC02_CPBTETOT]
			  ,[PCC01_CPBTEAUX1] AS [PCC02_CPBTEAUX1]
			  ,[PCC01_CPBTEAUX2] AS [PCC02_CPBTEAUX2]
			  ,[PCC01_TIPOVTACOD] AS [PCC02_TIPOVTACOD]
			  ,[PCC01_TIPOVTANOM] AS [PCC02_TIPOVTANOM]
			  ,[PCC01_CPBTESOL] AS [PCC02_CPBTESOL]
			  ,[PCC01_CPBTEGRUP] AS [PCC02_CPBTEGRUP]
			  ,[PCC01_CPBTENOTA] AS [PCC02_CPBTENOTA]
			  ,[PCC01_CPBTEDETA] AS [PCC02_CPBTEDETA]
--			  ,[PCC01_CODTIPVTA]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_SUCCOD])), '	', '') AS SMALLINT) AS [PCC02_SUCCOD]
			  ,[PCC01_SUCNOMB] AS [PCC02_SUCNOMB]
			  ,[PCC01_TIPOTALLER] AS [PCC02_TIPOTALLER]
			  ,[PCC01_CPBTEORD] AS [PCC02_CPBTEORD]
			  ,[PCC01_OTRECEPT] AS [PCC02_OTRECEPT]
			  ,[PCC01_OTTIPTRAB] AS [PCC02_OTTIPTRAB]
			  ,[PCC01_OTCARGO] AS [PCC02_OTCARGO]
			  ,[PCC01_OTESTADO] AS [PCC02_OTESTADO]
			  ,[PCC01_OTMES] AS [PCC02_OTMES]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_OTFECHA])), '	', '') AS SMALLDATETIME) AS [PCC02_OTFECHA]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_OTFECHEJEC])), '	', '') AS SMALLDATETIME) AS [PCC02_OTFECHEJEC]
			  ,CAST(REPLACE(RTRIM(LTRIM([PCC01_OTFECHFIN])), '	', '') AS SMALLDATETIME) AS [PCC02_OTFECHFIN]
			  ,[PCC01_OTIMPED] AS [PCC02_OTIMPED]
			  ,[PCC01_OTANOMAL] AS [PCC02_OTANOMAL]
			  ,[PCC01_OTDIAGNOST] AS [PCC02_OTDIAGNOST]
			  ,[PCC01_OTINCIDENT] AS [PCC02_OTINCIDENT]
			  ,[PCC01_OTDETALLE] AS [PCC02_OTDETALLE]
			  ,[PCC01_OTVEHDOMIN] AS [PCC02_OTVEHDOMIN]
			  ,[PCC01_OTVEHKILOM] AS [PCC02_OTVEHKILOM]
			  ,[PCC01_OTVEHMARC] AS [PCC02_OTVEHMARC]
			  ,[PCC01_OTVEHMODE] AS [PCC02_OTVEHMODE]
			  ,[PCC01_OTVEHSUBMOD] AS [PCC02_OTVEHSUBMOD]
			  ,[PCC01_OTVEHMOTOR] AS [PCC02_OTVEHMOTOR]
			  ,[PCC01_OTVEHNUMCHAS] AS [PCC02_OTVEHNUMCHAS]
			  ,[PCC01_OTVEHUSUABRIOT] AS [PCC02_OTVEHUSUABRIOT]
			  ,[PCC01_OTFVID] AS [PCC02_OTFVID]
			  ,CAST(CONVERT(VARCHAR(10), GETDATE(),103) AS SMALLDATETIME) AS [PCC02_FECACT]
		  FROM	[SYS-REPLICA].[CalipsoReplicado].[dbo].[JCP_VP_CTACTE] WITH (NOLOCK)

-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 2
-- ###################################################################################################################################


---- ###################################################################################################################################
---- Tamano de campos
--SELECT DISTINCT max(len([PCC01_CTAID])) as [PCC01_CTAID]
--			  ,max(len(CAST(REPLACE(RTRIM(LTRIM([PCC01_CTACOD])), '	', '') AS INT))) AS [PCC02_CTACOD]
--			  ,max(len([PCC01_CTADEN])) AS [PCC02_CTADEN]
--			  ,max(len([PCC01_CTACLI])) AS [PCC02_CTACLI]
--			  ,max(len([PCC01_CLITIPO])) AS [PCC02_CLITIPO]
--			  ,max(len([PCC01_CLITELCONT])) AS [PCC02_CLITELCONT]
--			  ,max(len([PCC01_CLICELU])) AS [PCC02_CLICELU]
--			  ,max(len([PCC01_CLITELLAB])) AS [PCC02_CLITELLAB]
--			  ,max(len([PCC01_CLITELPART])) AS [PCC02_CLITELPART]
--			  ,max(len([PCC01_CLIEMAIL])) AS [PCC02_CLIEMAIL]
--			  ,max(len([PCC01_CLIPROV])) AS [PCC02_CLIPROV]
--			  ,max(len([PCC01_CLICIUD])) AS [PCC02_CLICIUD]
--			  ,max(len(CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBFECEMI])), '	', '') AS SMALLDATETIME))) AS [PCC02_CPBFECEMI]
--			  ,max(len(CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBFECVTO])), '	', '') AS SMALLDATETIME))) AS [PCC02_CPBFECVTO]
--			  ,max(len([PCC01_CPBTETIPO])) AS [PCC02_CPBTETIPO]
--			  ,max(len(CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBTESLDO])), '	', '') AS DECIMAL(22,4)))) AS [PCC02_CPBTESLDO]
--			  ,max(len([PCC01_CPBTENUM])) AS [PCC02_CPBTENUM]
--			  ,max(len([PCC01_CPBTEID])) AS [PCC02_CPBTEID]
--			  ,max(len(CAST(REPLACE(RTRIM(LTRIM([PCC01_CPBCCCOD])), '	', '') AS INT))) AS [PCC02_CPBCCCOD]
--			  ,max(len([PCC01_CPBCCDES])) AS [PCC02_CPBCCDES]
--			  ,max(len([PCC01_CPBTETOT])) AS [PCC02_CPBTETOT]
--			  ,max(len([PCC01_CPBTEAUX1])) AS [PCC02_CPBTEAUX1]
--			  ,max(len([PCC01_CPBTEAUX2])) AS [PCC02_CPBTEAUX2]
--			  ,max(len([PCC01_TIPOVTACOD])) AS [PCC02_TIPOVTACOD]
--			  ,max(len([PCC01_TIPOVTANOM])) AS [PCC02_TIPOVTANOM]
--			  ,max(len([PCC01_CPBTESOL])) AS [PCC02_CPBTESOL]
--			  ,max(len([PCC01_CPBTEGRUP])) AS [PCC02_CPBTEGRUP]
--			  ,max(len([PCC01_CPBTENOTA])) AS [PCC02_CPBTENOTA]
--			  ,max(len([PCC01_CPBTEDETA])) AS [PCC02_CPBTEDETA]
----			  ,[PCC01_CODTIPVTA]
--			  ,max(len(CAST(REPLACE(RTRIM(LTRIM([PCC01_SUCCOD])), '	', '') AS SMALLINT))) AS [PCC02_SUCCOD]
--			  ,max(len([PCC01_SUCNOMB])) AS [PCC02_SUCNOMB]
--			  ,max(len([PCC01_TIPOTALLER])) AS [PCC02_TIPOTALLER]
--			  ,max(len([PCC01_CPBTEORD])) AS [PCC02_CPBTEORD]
--			  ,max(len([PCC01_OTRECEPT])) AS [PCC02_OTRECEPT]
--			  ,max(len([PCC01_OTTIPTRAB])) AS [PCC02_OTTIPTRAB]
--			  ,max(len([PCC01_OTCARGO])) AS [PCC02_OTCARGO]
--			  ,max(len([PCC01_OTESTADO])) AS [PCC02_OTESTADO]
--			  ,max(len([PCC01_OTMES])) AS [PCC02_OTMES]
--			  ,max(len(CAST(REPLACE(RTRIM(LTRIM([PCC01_OTFECHA])), '	', '') AS SMALLDATETIME))) AS [PCC02_OTFECHA]
--			  ,max(len(CAST(REPLACE(RTRIM(LTRIM([PCC01_OTFECHEJEC])), '	', '') AS SMALLDATETIME))) AS [PCC02_OTFECHEJEC]
--			  ,max(len(CAST(REPLACE(RTRIM(LTRIM([PCC01_OTFECHFIN])), '	', '') AS SMALLDATETIME))) AS [PCC02_OTFECHFIN]
--			  ,max(len([PCC01_OTIMPED])) AS [PCC02_OTIMPED]
--			  ,max(len([PCC01_OTANOMAL])) AS [PCC02_OTANOMAL]
--			  ,max(len([PCC01_OTDIAGNOST])) AS [PCC02_OTDIAGNOST]
--			  ,max(len([PCC01_OTINCIDENT])) AS [PCC02_OTINCIDENT]
--			  ,max(len([PCC01_OTDETALLE])) AS [PCC02_OTDETALLE]
--			  ,max(len([PCC01_OTVEHDOMIN])) AS [PCC02_OTVEHDOMIN]
--			  ,max(len([PCC01_OTVEHKILOM])) AS [PCC02_OTVEHKILOM]
--			  ,max(len([PCC01_OTVEHMARC])) AS [PCC02_OTVEHMARC]
--			  ,max(len([PCC01_OTVEHMODE])) AS [PCC02_OTVEHMODE]
--			  ,max(len([PCC01_OTVEHSUBMOD])) AS [PCC02_OTVEHSUBMOD]
--			  ,max(len([PCC01_OTVEHMOTOR])) AS [PCC02_OTVEHMOTOR]
--			  ,max(len([PCC01_OTVEHNUMCHAS])) AS [PCC02_OTVEHNUMCHAS]
--			  ,max(len([PCC01_OTVEHUSUABRIOT])) AS [PCC02_OTVEHUSUABRIOT]
--			  ,max(len([PCC01_OTFVID])) AS [PCC02_OTFVID]
--		  FROM [PVTWEB].[dbo].[PCC01_DATIMP]
---- ################################################################################################################################




-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 3
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)
-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'CCTE_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 3, @PROCNUM, 'DAT_DEPURA', 'ELIMA_DUPL', '[PCC02_DATEMP]', 'Elimina duplicados', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- INICIO				VERIFICA QUE NO HAYA VALORES DUPLICADOS
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--SELECT PC.*
--FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
--	INNER JOIN (-- VALORES DUPLICADOS
--				SELECT [PCC02_CPBTEID] AS CLAVE02 
--				FROM [PVTWEB].[dbo].[PCC02_DATEMP]
--				GROUP BY [PCC02_CPBTEID]
--				HAVING COUNT(*) > 1
--				) AS CD ON
--		PC.[PCC02_CPBTEID] = CD.CLAVE02
--ORDER BY PC.[PCC02_CPBTEID]

-- ELIMINA DUPLICADOS, DONDE EL OTCARGO ES VACIO
DELETE [PVTWEB].[dbo].[PCC02_DATEMP]
WHERE [PCC02_OTCARGO] = ''
	AND [PCC02_CPBTEID] IN (
							SELECT PC.[PCC02_CPBTEID]
--								, PC.*
							FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
								INNER JOIN (-- VALORES DUPLICADOS
											SELECT [PCC02_CPBTEID] AS CLAVE02 
											FROM [PVTWEB].[dbo].[PCC02_DATEMP]
											GROUP BY [PCC02_CPBTEID]
											HAVING COUNT(*) > 1
											) AS CD ON
									PC.[PCC02_CPBTEID] = CD.CLAVE02
							WHERE [PCC02_OTCARGO] = ''
--							ORDER BY PC.[PCC02_CPBTEID]
							)


-- ELIMINA DUPLICADOS, DONDE EL OTCARGO ES Tagle - Clientes Y Tagle - Garantias Fabrica
DELETE [PVTWEB].[dbo].[PCC02_DATEMP]
WHERE [PCC02_OTCARGO] = 'Tagle - Garantias Fabrica'
	AND [PCC02_CPBTEID] IN (
							SELECT PC.[PCC02_CPBTEID]
--								, PC.*
							FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
								INNER JOIN (-- VALORES DUPLICADOS
											SELECT [PCC02_CPBTEID] AS CLAVE02 
											FROM [PVTWEB].[dbo].[PCC02_DATEMP]
											GROUP BY [PCC02_CPBTEID]
											HAVING COUNT(*) > 1
											) AS CD ON
									PC.[PCC02_CPBTEID] = CD.CLAVE02
--							ORDER BY PC.[PCC02_CPBTEID]
							)


-- ELIMINA DUPLICADOS, DONDE EL OTCARGO ES Tagle - Clientes Y Tagle - Ventas
DELETE [PVTWEB].[dbo].[PCC02_DATEMP]
WHERE [PCC02_OTCARGO] = 'Tagle - Ventas'
	AND [PCC02_CPBTEID] IN (
							SELECT PC.[PCC02_CPBTEID]
--								, PC.*
							FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
								INNER JOIN (-- VALORES DUPLICADOS
											SELECT [PCC02_CPBTEID] AS CLAVE02 
											FROM [PVTWEB].[dbo].[PCC02_DATEMP]
											GROUP BY [PCC02_CPBTEID]
											HAVING COUNT(*) > 1
											) AS CD ON
									PC.[PCC02_CPBTEID] = CD.CLAVE02
--							ORDER BY PC.[PCC02_CPBTEID]
							)

-- ELIMINA DUPLICADOS, DONDE EL OTCARGO ES Tagle - Clientes Y Tagle - Ventas
DELETE [PVTWEB].[dbo].[PCC02_DATEMP]
WHERE [PCC02_OTCARGO] = 'Tagle - Planes Ahorro'
	AND [PCC02_CPBTEID] IN (
							SELECT PC.[PCC02_CPBTEID]
--								, PC.*
							FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
								INNER JOIN (-- VALORES DUPLICADOS
											SELECT [PCC02_CPBTEID] AS CLAVE02 
											FROM [PVTWEB].[dbo].[PCC02_DATEMP]
											GROUP BY [PCC02_CPBTEID]
											HAVING COUNT(*) > 1
											) AS CD ON
									PC.[PCC02_CPBTEID] = CD.CLAVE02
--							ORDER BY PC.[PCC02_CPBTEID]
							)

DELETE [PVTWEB].[dbo].[PCC02_DATEMP]
WHERE [PCC02_OTCARGO] = 'Tagle - Gerencia'
	AND [PCC02_CPBTEID] IN (
							SELECT PC.[PCC02_CPBTEID]
--								, PC.*
							FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
								INNER JOIN (-- VALORES DUPLICADOS
											SELECT [PCC02_CPBTEID] AS CLAVE02 
											FROM [PVTWEB].[dbo].[PCC02_DATEMP]
											GROUP BY [PCC02_CPBTEID]
											HAVING COUNT(*) > 1
											) AS CD ON
									PC.[PCC02_CPBTEID] = CD.CLAVE02
--							ORDER BY PC.[PCC02_CPBTEID]
							)
--
---- VERIFICA QUE NO HAYA DUPLICADOS
--SELECT PC.*
--FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS PC
--	INNER JOIN (-- VALORES DUPLICADOS
--				SELECT [PCC02_CPBTEID] AS CLAVE02 
--				FROM [PVTWEB].[dbo].[PCC02_DATEMP]
--				GROUP BY [PCC02_CPBTEID]
--				HAVING COUNT(*) > 1
--				) AS CD ON
--		PC.[PCC02_CPBTEID] = CD.CLAVE02
--ORDER BY PC.[PCC02_CPBTEID]
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- FIN					VERIFICA QUE NO HAYA VALORES DUPLICADOS
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT

-- ###################################################################################################################################
-- FIN - ACTCC_PASO 3
-- ###################################################################################################################################


---- CONTROL DE UN CLIENTE PUNTUAL
--SELECT TOP 100 *
--FROM [PVTWEB].[dbo].[PCC02_DATEMP]
--WHERE [PCC02_CTACOD] = 200018616

-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 4  -- ACTUALIZA DATOS HISTORICOS
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'CCTE_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 4, @PROCNUM, 'DAT_ACT_BASE', 'DAT_a_HIST', '[PCC03_SDOPTE]', 'Act datos y pasa a historico [PCC03_SDOPTE]/[PCC07_PROHIST]/[PCC04_SDOHST]', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- Ahora hay que actualizar la base SDOPTE y pasar al Hist�rico los comprobantes cancelados
--SELECT *
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
--WHERE [PCC03_CPBTEID] IN (-- AQU� LISTAMOS LOS COMPROBANTES QUE ESTAN EN LA TABLA [PCC03_SDOPTE] Y NO EN LA TABLA [PCC02_DATEMP]
--						  SELECT [PCC03_CPBTEID] AS CLAVEN 
--						   FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SDO 
--								LEFT OUTER JOIN (-- NOS DA EL LISTADO DE LOS CPTES PENDIENTES UNICOS
--												  SELECT [PCC02_CPBTEID] AS CLAVE02 
--												  FROM [PVTWEB].[dbo].[PCC02_DATEMP]
--												  GROUP BY [PCC02_CPBTEID]
--												  HAVING COUNT(*) = 1
--												 ) AS SDOLU ON
--														SDO.[PCC03_CPBTEID] = SDOLU.CLAVE02
--							WHERE SDOLU.CLAVE02 IS NULL
--						   )
--
-- PRIMERO SE DEBE MARCAR LOS REGISTROS A ACTUALIZAR
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
SET [PCC03_ACTCOD] = 'CPTE_NO_PTE'
WHERE [PCC03_CPBTEID] IN (-- AQU� LISTAMOS LOS COMPROBANTES QUE ESTAN EN LA TABLA [PCC03_SDOPTE] Y NO EN LA TABLA [PCC02_DATEMP]
						  SELECT [PCC03_CPBTEID] AS CLAVEN 
						   FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SDO 
								LEFT OUTER JOIN (-- NOS DA EL LISTADO DE LOS CPTES PENDIENTES UNICOS
												  SELECT [PCC02_CPBTEID] AS CLAVE02 
												  FROM [PVTWEB].[dbo].[PCC02_DATEMP]
												  GROUP BY [PCC02_CPBTEID]
												  HAVING COUNT(*) = 1
												 ) AS SDOLU ON
														SDO.[PCC03_CPBTEID] = SDOLU.CLAVE02
							WHERE SDOLU.CLAVE02 IS NULL
						   )

-- Actualiza la Tabla de procesos, los comprobantes que no estan antes de que se les cambie 
-- el codigo de la etapa del proceso hay que actualizar el hist�rico
INSERT INTO [PVTWEB].[dbo].[PCC07_PROHIST]
           ([PCC07_CPBTEID]
           ,[PCC07_PROETM_ANT]
           ,[PCC07_PRETCOM_ANT]
		   ,[PCC07_PRETCOM2_ANT]
           ,[PCC07_PRETFECH_ANT]
           ,[PCC07_PROETM_ACT]
           ,[PCC07_PRETCOM_ACT]
		   ,[PCC07_PRETCOM2_ACT]
           ,[PCC07_PRETFECH_ACT])
	SELECT [PCC03_CPBTEID]
			,[GPR03_PROETM]
			,[PCC03_PRETCOM]
			,[PCC03_PRETCOM]
			,[PCC03_PRETFECH]
			,'CCC_010_01' AS [PROETM_ACT]
			,'Act aut, por no estar m�s pte en calipso' AS [PRETCOM_ACT]
		    ,'Act aut, por no estar m�s pte en calipso' AS [PRETCOM2_ACT]
			,CAST(GETDATE() AS SMALLDATETIME) AS [PRETFECH_ACT]
-- SELECT TOP 10 *
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
	WHERE [PCC03_ACTCOD] = 'CPTE_NO_PTE'


-- Actualiza los comprobantes que ya fueron cancelados, no estan en la nueva base de datos
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
SET [GPR03_PROETM] = 'CCC_010_01'			-- Este es el final del proceso
	,[PCC03_PRETCOM] = 'Act aut, por no estar m�s pte en calipso'
	,[PCC03_PRETCOM02] = 'Act aut, por no estar m�s pte en calipso'
	,[PCC03_PRETFECH] = CAST(GETDATE() AS SMALLDATETIME)
WHERE [PCC03_ACTCOD] = 'CPTE_NO_PTE'


-- INSERTA LOS DATOS QUE YA TIENEN EL FINAL A LA TABLA HISTORICO
INSERT INTO [PVTWEB].[dbo].[PCC04_SDOHST]
           ([PCC04_CTAID]
		   ,[PCC04_CTACOD]
           ,[PCC04_CTADEN]
           ,[PCC04_CTACLI]
           ,[PCC04_CLITIPO]
           ,[PCC04_CLITELCONT]
           ,[PCC04_CLICELU]
           ,[PCC04_CLITELLAB]
           ,[PCC04_CLITELPART]
           ,[PCC04_CLIEMAIL]
           ,[PCC04_CLIPROV]
           ,[PCC04_CLICIUD]
           ,[PCC04_CPBFECEMI]
           ,[PCC04_CPBFECVTO]
           ,[PCC04_CPBTETIPO]
           ,[PCC04_CPBTESLDO]
           ,[PCC04_CPBTENUM]
           ,[PCC04_CPBTEID]
           ,[PCC04_CPBCCCOD]
           ,[PCC04_CPBCCDES]
           ,[PCC04_CPBTETOT]
           ,[PCC04_CPBTEAUX1]
           ,[PCC04_CPBTEAUX2]
           ,[PCC04_TIPOVTACOD]
           ,[PCC04_TIPOVTANOM]
           ,[PCC04_CPBTESOL]
           ,[PCC04_CPBTEGRUP]
           ,[PCC04_CPBTENOTA]
           ,[PCC04_CPBTEDETA]
           ,[PCC04_SUCCOD]
           ,[PCC04_SUCNOMB]
           ,[PCC04_TIPOTALLER]
           ,[PCC04_CPBTEORD]
           ,[PCC04_OTRECEPT]
           ,[PCC04_OTTIPTRAB]
           ,[PCC04_OTCARGO]
           ,[PCC04_OTESTADO]
           ,[PCC04_OTMES]
           ,[PCC04_OTFECHA]
           ,[PCC04_OTFECHEJEC]
           ,[PCC04_OTFECHFIN]
           ,[PCC04_OTIMPED]
           ,[PCC04_OTANOMAL]
           ,[PCC04_OTDIAGNOST]
           ,[PCC04_OTINCIDENT]
           ,[PCC04_OTDETALLE]
           ,[PCC04_OTVEHDOMIN]
           ,[PCC04_OTVEHKILOM]
           ,[PCC04_OTVEHMARC]
           ,[PCC04_OTVEHMODE]
           ,[PCC04_OTVEHSUBMOD]
           ,[PCC04_OTVEHMOTOR]
           ,[PCC04_OTVEHNUMCHAS]
           ,[PCC04_OTVEHUSUABRIOT]
           ,[PCC04_OTFVID]
           ,[GPR04_PROETM]
           ,[PCC04_PRETCOM]
		   ,[PCC04_PRETCOM02]
           ,[PCC04_PRETFECH]
           ,[PCC04_ACTCOD])
	SELECT [PCC03_CTAID]
		  ,[PCC03_CTACOD]
		  ,[PCC03_CTADEN]
		  ,[PCC03_CTACLI]
		  ,[PCC03_CLITIPO]
		  ,[PCC03_CLITELCONT]
		  ,[PCC03_CLICELU]
		  ,[PCC03_CLITELLAB]
		  ,[PCC03_CLITELPART]
		  ,[PCC03_CLIEMAIL]
		  ,[PCC03_CLIPROV]
		  ,[PCC03_CLICIUD]
		  ,[PCC03_CPBFECEMI]
		  ,[PCC03_CPBFECVTO]
		  ,[PCC03_CPBTETIPO]
		  ,[PCC03_CPBTESLDO]
		  ,[PCC03_CPBTENUM]
		  ,[PCC03_CPBTEID]
		  ,[PCC03_CPBCCCOD]
		  ,[PCC03_CPBCCDES]
		  ,[PCC03_CPBTETOT]
		  ,[PCC03_CPBTEAUX1]
		  ,[PCC03_CPBTEAUX2]
		  ,[PCC03_TIPOVTACOD]
		  ,[PCC03_TIPOVTANOM]
		  ,[PCC03_CPBTESOL]
		  ,[PCC03_CPBTEGRUP]
		  ,[PCC03_CPBTENOTA]
		  ,[PCC03_CPBTEDETA]
		  ,[PCC03_SUCCOD]
		  ,[PCC03_SUCNOMB]
		  ,[PCC03_TIPOTALLER]
		  ,[PCC03_CPBTEORD]
		  ,[PCC03_OTRECEPT]
		  ,[PCC03_OTTIPTRAB]
		  ,[PCC03_OTCARGO]
		  ,[PCC03_OTESTADO]
		  ,[PCC03_OTMES]
		  ,[PCC03_OTFECHA]
		  ,[PCC03_OTFECHEJEC]
		  ,[PCC03_OTFECHFIN]
		  ,[PCC03_OTIMPED]
		  ,[PCC03_OTANOMAL]
		  ,[PCC03_OTDIAGNOST]
		  ,[PCC03_OTINCIDENT]
		  ,[PCC03_OTDETALLE]
		  ,[PCC03_OTVEHDOMIN]
		  ,[PCC03_OTVEHKILOM]
		  ,[PCC03_OTVEHMARC]
		  ,[PCC03_OTVEHMODE]
		  ,[PCC03_OTVEHSUBMOD]
		  ,[PCC03_OTVEHMOTOR]
		  ,[PCC03_OTVEHNUMCHAS]
		  ,[PCC03_OTVEHUSUABRIOT]
		  ,[PCC03_OTFVID]
		  ,[GPR03_PROETM]
		  ,[PCC03_PRETCOM]
		  ,[PCC03_PRETCOM02]
		  ,[PCC03_PRETFECH]
		  ,[PCC03_ACTCOD]
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
	WHERE [PCC03_ACTCOD] = 'CPTE_NO_PTE'
		AND GPR03_PROETM = 'CCC_010_01'	-- Ultima etapa del proceso

-- Borra los comprobantes que ya fueron pasados al hist�rico
DELETE FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
WHERE [PCC03_ACTCOD] = 'CPTE_NO_PTE'
		AND GPR03_PROETM = 'CCC_010_01'
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
--                                          FIN
-- #############################################################################################################
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 4  -- ACTUALIZA DATOS HISTORICOS
-- ###################################################################################################################################


-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 5  -- ACTUALIZA ESTADO DE PROCESO
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'CCTE_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 5, @PROCNUM, 'DAT_PROC', 'ACT_PROC', '[PCC02_DATEMP]', 'Act el Proceso del Comprobante', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- #############################################################################################################
--                                          INICIO
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- Actualiza EL ESTADO Y PROCESO DE los comprobantes de la Tabla PCC02_DATEMP desde la Tabla PCC03_SDOPTE que luego se borrar�n
UPDATE [PVTWEB].[dbo].[PCC02_DATEMP]
SET [PCC02_ACTCOD] = 'CPTE_SI_PTE'
	,[GPR02_PROETM] = SDOLU.[GPR03_PROETM]
	,[PCC02_PRETCOM] = SDOLU.[PCC03_PRETCOM]
	,[PCC02_PRETCOM02] = SDOLU.[PCC03_PRETCOM02]
	,[PCC02_PRETFECH] = SDOLU.[PCC03_PRETFECH]
--SELECT TOP 100 SDOLU.[GPR01_PROETM], *
FROM [PVTWEB].[dbo].[PCC02_DATEMP] AS SDO 
	INNER JOIN (-- NOS DA EL LISTADO DE LOS CPTES PENDIENTES UNICOS
				SELECT [PCC03_CPBTEID] AS CLAVE03
						,[GPR03_PROETM]
						,[PCC03_PRETCOM]
						,[PCC03_PRETCOM02]
						,[PCC03_PRETFECH]
				FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
				GROUP BY [PCC03_CPBTEID]
						,[GPR03_PROETM]
						,[PCC03_PRETCOM]
						,[PCC03_PRETCOM02]
						,[PCC03_PRETFECH]
				HAVING COUNT(*) = 1
				) AS SDOLU ON 
					SDO.[PCC02_CPBTEID] = SDOLU.CLAVE03

-- Actualiza los registros nuevos en la etapa inicial
UPDATE [PVTWEB].[dbo].[PCC02_DATEMP]
SET [GPR02_PROETM] = 'CCC_001_01' 
	,[PCC02_ACTCOD] = 'CPTE_SI_PTE_NVO'
WHERE [PCC02_ACTCOD] IS NULL
	AND [GPR02_PROETM] IS NULL

-- Actualiza la Fecha del Inicio del Proceso con la Fecha de Emisi�n del comprobante si el estado del proceso es inicial
UPDATE [PVTWEB].[dbo].[PCC02_DATEMP]
   SET [PCC02_PRETFECH] = CAST([PCC02_CPBFECEMI] AS SMALLDATETIME)
 WHERE [GPR02_PROETM] = 'CCC_001_01'

-- ACTUALIZA EL C�DIGO DE LA ODR DESDE EL TELSOL (este es para asegurarnos que todas las FC tienen Numero de ODR)
UPDATE [PVTWEB].[dbo].[PCC02_DATEMP]
   SET [PCC02_CPBTEORD] = [PCC02_CPBTESOL]
 WHERE [PCC02_CPBTEORD] IS NULL 
	AND [PCC02_CPBTESOL] IS NOT NULL

--SELECT TOP 10000 [PCC03_CPBTEORD], [PCC03_CPBTESOL]
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
-- WHERE [PCC03_CPBTEORD] IS NULL AND [PCC03_CPBTESOL] IS NOT NULL

-- ACTUALIZA EL C�DIGO DE LA ODR DESDE EL AUX1
UPDATE [PVTWEB].[dbo].[PCC02_DATEMP]
   SET [PCC02_CPBTEORD] = CASE WHEN ISNUMERIC(LEFT([PCC02_CPBTEAUX1],10)) = 1 THEN LEFT([PCC02_CPBTEAUX1],10) ELSE NULL END
 WHERE [PCC02_CPBTEORD] IS NULL 
	AND CASE WHEN ISNUMERIC(LEFT([PCC02_CPBTEAUX1],10)) = 1 THEN LEFT([PCC02_CPBTEAUX1],10) ELSE NULL END IS NOT NULL

--SELECT TOP 10000 [PCC03_CPBTEORD]
--	,CASE WHEN ISNUMERIC(LEFT([PCC03_CPBTEAUX1],10)) = 1 THEN LEFT([PCC03_CPBTEAUX1],10) ELSE NULL END AS ODRIZQ
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
-- WHERE [PCC03_CPBTEORD] IS NULL AND CASE WHEN ISNUMERIC(LEFT([PCC03_CPBTEAUX1],10)) = 1 THEN LEFT([PCC03_CPBTEAUX1],10) ELSE NULL END IS NOT NULL

-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 5  -- ACTUALIZA ESTADO DE PROCESO
-- ###################################################################################################################################


-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 6  -- PASA DATOS A LA TABLA FINAL
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'CCTE_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 6, @PROCNUM, 'DAT_TBL_DEF', 'TBL_DATBORRA', '[PCC03_SDOPTE]', 'Borra datos de Tabla Definitiva', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- Borra TODOS los comprobantes de la base de pendientes, ya que se van a importar nuevamente de la base [PCC03_SDOPTE]
DELETE FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT

SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 7, @PROCNUM, 'DAT_TBL_DEF', 'TBL_DATTRANSF', '[PCC03_SDOPTE]', 'Pasa datos a Tabla Definitiva', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- Inserta los datos nuevos ya actualizados
INSERT INTO [PVTWEB].[dbo].[PCC03_SDOPTE]
           ([PCC03_CTAID]
		   ,[PCC03_CTACOD]
           ,[PCC03_CTADEN]
           ,[PCC03_CTACLI]
           ,[PCC03_CLITIPO]
           ,[PCC03_CLITELCONT]
           ,[PCC03_CLICELU]
           ,[PCC03_CLITELLAB]
           ,[PCC03_CLITELPART]
           ,[PCC03_CLIEMAIL]
           ,[PCC03_CLIPROV]
           ,[PCC03_CLICIUD]
           ,[PCC03_CPBFECEMI]
           ,[PCC03_CPBFECVTO]
           ,[PCC03_CPBTETIPO]
           ,[PCC03_CPBTESLDO]
           ,[PCC03_CPBTENUM]
           ,[PCC03_CPBTEID]
           ,[PCC03_CPBCCCOD]
           ,[PCC03_CPBCCDES]
           ,[PCC03_CPBTETOT]
           ,[PCC03_CPBTEAUX1]
           ,[PCC03_CPBTEAUX2]
           ,[PCC03_TIPOVTACOD]
           ,[PCC03_TIPOVTANOM]
           ,[PCC03_CPBTESOL]
           ,[PCC03_CPBTEGRUP]
           ,[PCC03_CPBTENOTA]
           ,[PCC03_CPBTEDETA]
           ,[PCC03_SUCCOD]
           ,[PCC03_SUCNOMB]
           ,[PCC03_TIPOTALLER]
           ,[PCC03_CPBTEORD]
           ,[PCC03_OTRECEPT]
           ,[PCC03_OTTIPTRAB]
           ,[PCC03_OTCARGO]
           ,[PCC03_OTESTADO]
           ,[PCC03_OTMES]
           ,[PCC03_OTFECHA]
           ,[PCC03_OTFECHEJEC]
           ,[PCC03_OTFECHFIN]
           ,[PCC03_OTIMPED]
           ,[PCC03_OTANOMAL]
           ,[PCC03_OTDIAGNOST]
           ,[PCC03_OTINCIDENT]
           ,[PCC03_OTDETALLE]
           ,[PCC03_OTVEHDOMIN]
           ,[PCC03_OTVEHKILOM]
           ,[PCC03_OTVEHMARC]
           ,[PCC03_OTVEHMODE]
           ,[PCC03_OTVEHSUBMOD]
           ,[PCC03_OTVEHMOTOR]
           ,[PCC03_OTVEHNUMCHAS]
           ,[PCC03_OTVEHUSUABRIOT]
           ,[PCC03_OTFVID]
           ,[GPR03_PROETM]
           ,[PCC03_PRETCOM]
		   ,[PCC03_PRETCOM02]
           ,[PCC03_PRETFECH]
           ,[PCC03_ACTCOD])
		SELECT [PCC02_CTAID]
		  ,[PCC02_CTACOD]
		  ,[PCC02_CTADEN]
		  ,[PCC02_CTACLI]
		  ,[PCC02_CLITIPO]
		  ,[PCC02_CLITELCONT]
		  ,[PCC02_CLICELU]
		  ,[PCC02_CLITELLAB]
		  ,[PCC02_CLITELPART]
		  ,[PCC02_CLIEMAIL]
		  ,[PCC02_CLIPROV]
		  ,[PCC02_CLICIUD]
		  ,[PCC02_CPBFECEMI]
		  ,[PCC02_CPBFECVTO]
		  ,[PCC02_CPBTETIPO]
		  ,[PCC02_CPBTESLDO]
		  ,[PCC02_CPBTENUM]
		  ,[PCC02_CPBTEID]
		  ,[PCC02_CPBCCCOD]
		  ,[PCC02_CPBCCDES]
		  ,[PCC02_CPBTETOT]
		  ,[PCC02_CPBTEAUX1]
		  ,[PCC02_CPBTEAUX2]
		  ,[PCC02_TIPOVTACOD]
		  ,[PCC02_TIPOVTANOM]
		  ,[PCC02_CPBTESOL]
		  ,[PCC02_CPBTEGRUP]
		  ,[PCC02_CPBTENOTA]
		  ,[PCC02_CPBTEDETA]
		  ,[PCC02_SUCCOD]
		  ,[PCC02_SUCNOMB]
		  ,[PCC02_TIPOTALLER]
		  ,[PCC02_CPBTEORD]
		  ,[PCC02_OTRECEPT]
		  ,[PCC02_OTTIPTRAB]
		  ,[PCC02_OTCARGO]
		  ,[PCC02_OTESTADO]
		  ,[PCC02_OTMES]
		  ,[PCC02_OTFECHA]
		  ,[PCC02_OTFECHEJEC]
		  ,[PCC02_OTFECHFIN]
		  ,[PCC02_OTIMPED]
		  ,[PCC02_OTANOMAL]
		  ,[PCC02_OTDIAGNOST]
		  ,[PCC02_OTINCIDENT]
		  ,[PCC02_OTDETALLE]
		  ,[PCC02_OTVEHDOMIN]
		  ,[PCC02_OTVEHKILOM]
		  ,[PCC02_OTVEHMARC]
		  ,[PCC02_OTVEHMODE]
		  ,[PCC02_OTVEHSUBMOD]
		  ,[PCC02_OTVEHMOTOR]
		  ,[PCC02_OTVEHNUMCHAS]
		  ,[PCC02_OTVEHUSUABRIOT]
		  ,[PCC02_OTFVID]
		  ,[GPR02_PROETM]
		  ,[PCC02_PRETCOM]
		  ,[PCC02_PRETCOM02]
		  ,[PCC02_PRETFECH]
		  ,[PCC02_ACTCOD]
	  FROM [PVTWEB].[dbo].[PCC02_DATEMP]

-- BORRA EL CAMPO QUE SIRVE PARA MARCAR LAS ACTUALIZACIONES Y LA FECHA EN QUE SE ACTUALIZARON LOS DATOS
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
SET [PCC03_ACTCOD] = NULL
	, [PCC03_FECACT] = CAST(CONVERT(NVARCHAR(10), GETDATE(), 103) AS SMALLDATETIME)

-- ACTUALIZA LA FECHA DE ACTUALIZACION
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_CPBCCGEST] = [PCC03_CPBCCCOD]
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT

SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 8, @PROCNUM, 'DAT_TBL_DEF', 'TBL_DATTRANSF', '[PCC02_DATEMP]', 'Borra datos tabla temporaria [PCC02_DATEMP]', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- Borra los datos de la tabla temporaria
DELETE FROM [PVTWEB].[dbo].[PCC02_DATEMP]
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ###################################################################################################################################
-- FIN - ACTCC_PASO 6  -- PASA DATOS A LA TABLA FINAL
-- ###################################################################################################################################


---- ACTUALIZA EL CENTRO DE COSTOS DE GESTI�N - ESTO ES PARA ASIGNAR RESPONSABILIDADES
---- LAS C�AS DE SEGUROS ESTAN EN EL 2020105
--UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
--   SET [PCC03_CPBCCGEST] = CAST(CONVERT(VARCHAR(10), GETDATE(),103) AS SMALLDATETIME)

-- CONTROL
--SELECT *
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
--WHERE [PCC03_TIPOVTANOM] = 'Taller de Chapa'
--	AND [PCC03_CTACOD] = 201023450



-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 7  -- AJUSTES + -
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'CCTE_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 9, @PROCNUM, 'DAT_DEPURA', 'SDOS_MENORES +- $20', '[PCC03_SDOPTE]', 'Ajusta Saldos Menores +- $20', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- #############################################################################################################
--											INICIO	AJUSTES + o -
-- @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
---- PONE TODO A CERO, EXCEPTO LO QUE ES IGUAL AL MOMENTO INICIAL
--UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
--   SET [PCC03_ACTCOD] = NULL
--	  ,[GPR03_PROETM] = 'CCC_001_01'
--      ,[PCC03_PRETCOM] = NULL
--	  ,[PCC03_PRETFECH] = NULL
--WHERE [GPR03_PROETM] <> 'CCC_001_01'
--
---- VERIFICACI�N DE LOS ESTADOS DE LOS COMPROBANTES
--SELECT SP.[GPR03_PROETM]
--	,PR.[GPR01_ETMDEC]
--	,SP.[PCC03_PRETCOM02]
--	,COUNT(*) AS TOTAL
--	, CAST(SUM(CASE WHEN [PCC03_CPBTETIPO] = 'Fac' THEN [PCC03_CPBTESLDO] 
--					WHEN [PCC03_CPBTETIPO] = 'Deb' THEN [PCC03_CPBTESLDO] 
--					WHEN [PCC03_CPBTETIPO] = 'Rec' THEN [PCC03_CPBTESLDO] * -1
--					WHEN [PCC03_CPBTETIPO] = 'Cre' THEN [PCC03_CPBTESLDO] * -1
--					END) AS INT) AS TotPes
----SELECT TOP 100 *
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP
--	INNER JOIN (SELECT [GPR01_PROETM]
--					  ,[GPR01_PROCOD]
--					  ,[GPR01_ETACOD]
--					  ,[GPR01_MOTCOD]
--					  ,[GPR01_ETMDEC]
--				  FROM [PVTWEB].[dbo].[GPR01_PROGES]) AS PR ON 
--		SP.[GPR03_PROETM] = PR.[GPR01_PROETM]
--GROUP BY SP.[GPR03_PROETM]
--	,PR.[GPR01_ETMDEC]
--	,SP.[PCC03_PRETCOM02]
--ORDER BY SP.[GPR03_PROETM]


--
--SELECT [GPR01_PROETM]
--  ,[GPR01_PROCOD]
--  ,[GPR01_ETACOD]
--  ,[GPR01_MOTCOD]
--  ,[GPR01_ETMDEC]
--FROM [PVTWEB].[dbo].[GPR01_PROGES]
--ORDER BY [GPR01_PROETM]
--
--CCC_001_01	Cob Cta Cte	CMP EMI	PTE ENT	Comprobante Emitidas Pendientes de Entregar
--CCC_002_01	Cob Cta Cte	CMP EMI	REC CLI	Comprobante Rechazadas por el Cliente por alg�n inconveniente
--CCC_003_01	Cob Cta Cte	CMP EMI	PLA VEN	Comprobante que se venci� el plazo para entragarlas al Cliente
--CCC_004_01	Cob Cta Cte	CMP EMI	DOC EXT	Comprobante extraviadas internamente
--CCC_004_02	Cob Cta Cte	CMP EMI	DOC EXP	Comprobante extraviadas por el proveedor
--CCC_004_03	Cob Cta Cte	CMP EMI	DOC DES	Comprobante desconocido / No se conoce su origen
--CCC_005_01	Cob Cta Cte	CMP ENT	PTE COB	Comprobante entregadas pendientes de cobrar
--CCC_006_01	Cob Cta Cte	CMP ENT	PLA VEN	Comprobante que se venci� el plazo de pago comprometido
--CCC_007_01	Cob Cta Cte	CMP ENT	DOC OBJ	Comprobante entregadas con objeciones del Cliente
--CCC_007_02	Cob Cta Cte	CMP ENT	MUN HAB	Comprobante entregadas en la Habilitaci�n Municipal
--CCC_007_03	Cob Cta Cte	CMP ENT	MUN EXP	Comprobante entregadas en Expediente
--CCC_007_04	Cob Cta Cte	CMP ENT	G10 SHA	Comprobante entregadas Gestion 2010 Sin Habilitaci�n definida
--CCC_007_05	Cob Cta Cte	CMP ENT	G11 SHA	Comprobante entregadas Gestion 2011 Sin Habilitaci�n definida
--CCC_007_06	Cob Cta Cte	CMP ENT	CON CLI	Comprobante entregadas en conciliacion con Cliente
--CCC_007_07	Cob Cta Cte	CMP ENT	LIC PTE	Comprobante entregadas para una licitacion
--CCC_007_08	Cob Cta Cte	CMP ENT	CON APB	Comprobante entregadas en conciliacion Aprobadas por Cliente
--CCC_008_01	Cob Cta Cte	CMP COB	PTE IMP	Comprobante cobradas pendientes de la imputaci�n en Calipso
--CCC_008_02	Cob Cta Cte	CMP COB	G10 PIM	Comprobante cobradas Gesti�n 2010 Pendiente de Imputar
--CCC_008_03	Cob Cta Cte	CMP COB	G11 PIM	Comprobante cobradas Gesti�n 2010 Pendiente de Imputar
--CCC_008_04	Cob Cta Cte	CMP COB	ACC VTA	Comprobante cobradas en Ventas Pte imputar a Accesorios
--CCC_008_05	Cob Cta Cte	CMP COB	PIA MCC	Comprobante cobradas Pte Imputacion Autom�tica Mismo Centro de Costos
--CCC_008_06	Cob Cta Cte	CMP COB	PIA DCC	Comprobante cobradas Pte Imputacion Autom�tica Distinto Centro de Costos
--CCC_009_01	Cob Cta Cte	CMP COB	DOC IMP	Comprobante cobradas imputadas en Calipso
--CCC_009_02	Cob Cta Cte	CMP COB	DOC 001	Comprobante cobradas Pendiente de Ajustar en Calipso
--CCC_010_01	Cob Cta Cte	CMP FIN	FAC FIN	Comprobante pasadas al hist�rico
--****************************************************************************************************************************
-- fin
--****************************************************************************************************************************


-- PONE A NULL EL CAMPO QUE MARCA LAS ACTUALIZACIONES
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE] SET [PCC03_ACTCOD] = NULL
-- ########################################################################################################################
-- ##################################################  INICIO PROCESO EnProcActFC+- $ ######################################
-- ########################################################################################################################
DECLARE @SaldoPesos AS INT
SET @SaldoPesos = 20		-- PESOS, PROCESE $20 Y $40

---- VERIFICA EL IMPACTO DEL MONTO DE LOS COMPROBANTES
--SELECT COUNT(*) AS CANTCOMP, CAST(SUM([PCC03_CPBTESLDO]) AS INT) AS TotPes
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
--WHERE [GPR03_PROETM] = 'CCC_001_01'
--	AND ([PCC03_CPBTESLDO] <= @SaldoPesos AND [PCC03_CPBTESLDO] >= -@SaldoPesos)

-- CENTROS DE COSTOS
--SELECT [PCC03_CPBCCCOD], COUNT(*) AS TOTAL
--	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
--GROUP BY [PCC03_CPBCCCOD]
--ORDER BY [PCC03_CPBCCCOD]

---- PRIMERO DEBE MARCAR LOS REGISTROS QUE ESTAR�N SUJETOS A ACTUALIZACI�N
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_ACTCOD] = 'EnProcActFC+-'
-- SELECT TOP 100 *
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [GPR03_PROETM] = 'CCC_001_01'
			AND ([PCC03_CPBTESLDO] <= @SaldoPesos AND [PCC03_CPBTESLDO] >= -@SaldoPesos)
--			AND ([PCC03_CPBCCCOD] = '2020101' OR [PCC03_CPBCCCOD] = '2020102' OR [PCC03_CPBCCCOD] = '2020103' OR [PCC03_CPBCCCOD] = '2020104' OR [PCC03_CPBCCCOD] = '2020105' OR [PCC03_CPBCCCOD] = '2020106' OR [PCC03_CPBCCCOD] = '2020107' OR [PCC03_CPBCCCOD] = '2020108')


-- SEGUNDO DEBE PASAR LA INFORMACI�N AL HIST�RICO
INSERT INTO [PVTWEB].[dbo].[PCC07_PROHIST]
           ([PCC07_CPBTEID]
           ,[PCC07_PROETM_ANT]
           ,[PCC07_PRETCOM_ANT]
		   ,[PCC07_PRETCOM2_ANT]
           ,[PCC07_PRETFECH_ANT]
           ,[PCC07_PROETM_ACT]
           ,[PCC07_PRETCOM_ACT]
		   ,[PCC07_PRETCOM2_ACT]
           ,[PCC07_PRETFECH_ACT]
		   ,[PCC07_CPBCCCOD]
		   ,[PCC07_CTASLDO])
	SELECT [PCC03_CPBTEID]
			,[GPR03_PROETM] AS [PROETM_ANT]
			,[PCC03_PRETCOM] AS [PRETCOM_ANT]
			,[PCC03_PRETCOM02] AS [PRETCOM2_ANT]
			,[PCC03_PRETFECH] AS [PRETFECH_ANT]
			,'CCC_009_02' AS [PROETM_ACT]
			,'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos' AS [PRETCOM_ACT]
		    ,'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos' AS [PRETCOM2_ACT]
			,CAST(GETDATE() AS SMALLDATETIME) AS [PRETFECH_ACT]
			,[PCC03_CPBCCCOD]
			,[PCC03_CPBTESLDO]
--SELECT TOP 100 COUNT(*) AS TOTAL
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [PCC03_ACTCOD] = 'EnProcActFC+-'

-- LUEGO DEBE ACTUALIZAR LA NUEVA INFO
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [GPR03_PROETM] = 'CCC_009_02'
      ,[PCC03_PRETCOM] = 'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos'
	  ,[PCC03_PRETCOM02] = 'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos'
	  ,[PCC03_PRETFECH] = CAST(GETDATE() AS SMALLDATETIME)
--SELECT TOP 1000 [PCC03_CPBTEID], [GPR01_PROETM],[PCC03_PRETCOM], DA.*
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [PCC03_ACTCOD] = 'EnProcActFC+-'

-- BORRA LA MARCA
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_ACTCOD] = NULL
WHERE [PCC03_ACTCOD] = 'EnProcActFC+-'
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT


SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 10, @PROCNUM, 'DAT_DEPURA', 'SDOS_MENORES +- $40', '[PCC03_SDOPTE]', 'Ajusta Saldos Menores +- $40', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- AJUSTA COMPROBANTES DE $40
SET @SaldoPesos = 40		-- PESOS, PROCESE $20 Y $40
---- VERIFICA EL IMPACTO DEL MONTO DE LOS COMPROBANTES
--SELECT COUNT(*) AS CANTCOMP, CAST(SUM([PCC03_CPBTESLDO]) AS INT) AS TotPes
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
--WHERE [GPR03_PROETM] = 'CCC_001_01'
--	AND ([PCC03_CPBTESLDO] <= @SaldoPesos AND [PCC03_CPBTESLDO] >= -@SaldoPesos)

-- CENTROS DE COSTOS
--SELECT [PCC03_CPBCCCOD], COUNT(*) AS TOTAL
--	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
--GROUP BY [PCC03_CPBCCCOD]
--ORDER BY [PCC03_CPBCCCOD]

---- PRIMERO DEBE MARCAR LOS REGISTROS QUE ESTAR�N SUJETOS A ACTUALIZACI�N
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_ACTCOD] = 'EnProcActFC+-'
-- SELECT TOP 100 *
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [GPR03_PROETM] = 'CCC_001_01'
			AND ([PCC03_CPBTESLDO] <= @SaldoPesos AND [PCC03_CPBTESLDO] >= -@SaldoPesos)
--			AND ([PCC03_CPBCCCOD] = '2020101' OR [PCC03_CPBCCCOD] = '2020102' OR [PCC03_CPBCCCOD] = '2020103' OR [PCC03_CPBCCCOD] = '2020104' OR [PCC03_CPBCCCOD] = '2020105' OR [PCC03_CPBCCCOD] = '2020106' OR [PCC03_CPBCCCOD] = '2020107' OR [PCC03_CPBCCCOD] = '2020108')


-- SEGUNDO DEBE PASAR LA INFORMACI�N AL HIST�RICO
INSERT INTO [PVTWEB].[dbo].[PCC07_PROHIST]
           ([PCC07_CPBTEID]
           ,[PCC07_PROETM_ANT]
           ,[PCC07_PRETCOM_ANT]
		   ,[PCC07_PRETCOM2_ANT]
           ,[PCC07_PRETFECH_ANT]
           ,[PCC07_PROETM_ACT]
           ,[PCC07_PRETCOM_ACT]
		   ,[PCC07_PRETCOM2_ACT]
           ,[PCC07_PRETFECH_ACT]
		   ,[PCC07_CPBCCCOD]
		   ,[PCC07_CTASLDO])
	SELECT [PCC03_CPBTEID]
			,[GPR03_PROETM] AS [PROETM_ANT]
			,[PCC03_PRETCOM] AS [PRETCOM_ANT]
			,[PCC03_PRETCOM02] AS [PRETCOM2_ANT]
			,[PCC03_PRETFECH] AS [PRETFECH_ANT]
			,'CCC_009_02' AS [PROETM_ACT]
			,'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos' AS [PRETCOM_ACT]
		    ,'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos' AS [PRETCOM2_ACT]
			,CAST(GETDATE() AS SMALLDATETIME) AS [PRETFECH_ACT]
			,[PCC03_CPBCCCOD]
			,[PCC03_CPBTESLDO]
--SELECT TOP 100 COUNT(*) AS TOTAL
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [PCC03_ACTCOD] = 'EnProcActFC+-'


-- LUEGO DEBE ACTUALIZAR LA NUEVA INFO
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [GPR03_PROETM] = 'CCC_009_02'
      ,[PCC03_PRETCOM] = 'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos'
	  ,[PCC03_PRETCOM02] = 'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos'
	  ,[PCC03_PRETFECH] = CAST(GETDATE() AS SMALLDATETIME)
--SELECT TOP 1000 [PCC03_CPBTEID], [GPR01_PROETM],[PCC03_PRETCOM], DA.*
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS SP 
		WHERE [PCC03_ACTCOD] = 'EnProcActFC+-'

-- BORRA LA MARCA
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_ACTCOD] = NULL
WHERE [PCC03_ACTCOD] = 'EnProcActFC+-'


--#############################################################################################
--UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
--   SET [PCC03_PRETCOM02] = [PCC03_PRETCOM]
--WHERE [GPR03_PROETM] = 'CCC_009_02'
--
--
--SELECT [GPR03_PROETM], [PCC03_PRETCOM], [PCC03_PRETCOM02], COUNT(*) AS TOTAL
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
--WHERE [GPR03_PROETM] = 'CCC_009_02'
--GROUP BY [GPR03_PROETM], [PCC03_PRETCOM], [PCC03_PRETCOM02]
-- ************************************************************************************************************************************
---- CONTROL DE LA ACTUALIZACI�N
--SELECT [PCC03_PRETCOM]
--		, COUNT(*) AS CANTCOMP
--		, CAST(SUM(CASE WHEN [PCC03_CPBTETIPO] = 'Fac' THEN [PCC03_CPBTESLDO] 
--					 WHEN [PCC03_CPBTETIPO] = 'Deb' THEN [PCC03_CPBTESLDO] 
--					 WHEN [PCC03_CPBTETIPO] = 'Rec' THEN [PCC03_CPBTESLDO] * -1
--					 WHEN [PCC03_CPBTETIPO] = 'Cre' THEN [PCC03_CPBTESLDO] * -1
--					 END) AS INT) AS TotPes
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
--WHERE [GPR03_PROETM] = 'CCC_009_02'
--GROUP BY [PCC03_PRETCOM]
--
--
--DECLARE @SaldoPesos AS INT
--SET @SaldoPesos = 20		-- PESOS, PROCESE $5 Y $20
--
--SELECT *
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
--WHERE [GPR03_PROETM] = 'CCC_009_02'
--	AND [PCC03_PRETCOM] = 'Factura >=-$' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' y <= $' + CAST(@SaldoPesos AS NVARCHAR(5)) + ' Pesos'
--ORDER BY [PCC03_CPBTESLDO]

-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ########################################################################################################################
-- ##################################################  FIN PROCESO EnProcActFC+- $ #########################################

-- ###################################################################################################################################
-- FIN - ACTCC_PASO 7  -- AJUSTES + -
-- ###################################################################################################################################


-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 8  -- ACTUALIZA DATOS Y TABLAS VARIAS
-- ###################################################################################################################################
--DECLARE @NUEVOIDACT AS NVARCHAR(36) 
--DECLARE @PROCNUM AS NUMERIC(18,0)
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'CCTE_ACT')
-- *******************************************************************************************************************************************
-- ########################################################################################################################
-- INICIO -- ACTUALIZA EL CENTRO DE COSTO DE GESTI�N - ESTE ESTA CORREGIDO DE LOS PROBLEMAS QUE PUEDEN HABER HABIDO EN EL SISTEMA
-- ########################################################################################################################
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 11, @PROCNUM, 'ACT_TABLAS', 'ACT CTRO COSTOS GESTION', '[GRL032_CCTOVTATIPO]', 'Act el CtroCtos de Gestion', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
-- ACTUALIZA LA ANTIGUEDAD
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_ANTIG] = CASE WHEN DATEDIFF(DD, [PCC03_CPBFECEMI], GETDATE()) < 7 THEN '<7D'  
							WHEN DATEDIFF(DD, [PCC03_CPBFECEMI], GETDATE()) < 15 AND DATEDIFF(DD, [PCC03_CPBFECEMI], GETDATE()) >= 7 THEN '>7D'
							WHEN DATEDIFF(DD, [PCC03_CPBFECEMI], GETDATE()) < 30 AND DATEDIFF(DD, [PCC03_CPBFECEMI], GETDATE()) >= 15 THEN '>15D'
							WHEN DATEDIFF(DD, [PCC03_CPBFECEMI], GETDATE()) < 45 AND DATEDIFF(DD, [PCC03_CPBFECEMI], GETDATE()) >= 30 THEN '>30D'
							WHEN DATEDIFF(DD, [PCC03_CPBFECEMI], GETDATE()) < 90 AND DATEDIFF(DD, [PCC03_CPBFECEMI], GETDATE()) >= 45 THEN '>45D'
							WHEN DATEDIFF(DD, [PCC03_CPBFECEMI], GETDATE()) < 180 AND DATEDIFF(DD, [PCC03_CPBFECEMI], GETDATE()) >= 90 THEN '>90D'
							ELSE '>180D'
						END
-- ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

-- TABLA [GRL032_CCTOVTATIPO]
-- CARGA LA TABLA CENTRO DE COSTOS - TIPOS DE VENTAS - LOS C�DIGOS QUE FALTAN
INSERT INTO [PVTWEB].[dbo].[GRL032_CCTOVTATIPO]
           ([GRL032_CCTO_COD]
           ,[GRL032_CTROCTO]
           ,[GRL032_VTATIPO_COD]
           ,[GRL032_VTATIPO]
--           ,[GRL032_CCTOCODGEST]
			)
				SELECT [PCC03_CPBCCCOD], [PCC03_CPBCCDES], [PCC03_TIPOVTACOD], [PCC03_TIPOVTANOM]
				FROM (
						SELECT [PCC03_CPBCCCOD], [PCC03_CPBCCDES], [PCC03_TIPOVTACOD], [PCC03_TIPOVTANOM]
						--SELECT CCTO, CCTIPVTA, COUNT(DISTINCT [FV010_FVID]) AS CANTFACT, COUNT(*) AS CANTREG,  SUM([FV010_FCTOTVTANETA]) AS VTANETTOT
						FROM (SELECT *, CAST([PCC03_CPBCCCOD] AS NVARCHAR(20)) AS CCTO, [PCC03_TIPOVTANOM] AS CCTIPVTA
								FROM [PVTWEB].[dbo].[PCC03_SDOPTE] WITH(NOLOCK) 
							 ) AS CC
						GROUP BY [PCC03_CPBCCCOD], [PCC03_CPBCCDES], [PCC03_TIPOVTACOD], [PCC03_TIPOVTANOM]
						) AS CCT
						LEFT OUTER JOIN [PVTWEB].[dbo].[GRL032_CCTOVTATIPO] AS GCT ON
							CCT.[PCC03_CPBCCCOD] = GCT.[GRL032_CCTO_COD]
								AND
							CCT.[PCC03_TIPOVTACOD] = GCT.[GRL032_VTATIPO_COD]
				WHERE GCT.[GRL032_CCTO_COD] IS NULL
				ORDER BY [PCC03_CPBCCCOD], [PCC03_CPBCCDES], [PCC03_TIPOVTACOD], [PCC03_TIPOVTANOM]

-- ACTUALIZA el ctro ctos de gesti�n, seg�n la tabla GRL032_CCTOVTATIPO
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
	SET [PCC03_CPBCCGEST] = [GRL032_CCTOCODGEST]
		FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CC WITH(NOLOCK) 
			INNER JOIN (SELECT *
						FROM [PVTWEB].[dbo].[GRL032_CCTOVTATIPO] WITH(NOLOCK)) AS VFCT  ON
				CC.[PCC03_CPBCCCOD] = VFCT.[GRL032_CCTO_COD]
					AND
				CC.[PCC03_TIPOVTACOD] = VFCT.[GRL032_VTATIPO_COD]

-- TABLA [GRL030_ABRDESC]
-- CARGA EL CENTRO DE COSTOS A LA TABLA GRL030_ABRDESC
INSERT INTO [PVTWEB].[dbo].[GRL030_ABRDESC]
           ([GRL030_CODIGO]
           ,[GRL030_DESCRIPC]
           ,[GRL030_ABRTIPO])
				SELECT [PCC03_CPBCCCOD], [PCC03_CPBCCDES], 'CTRO CTO' AS [ABRTIPO]
				FROM (
						SELECT [PCC03_CPBCCCOD], [PCC03_CPBCCDES]
						FROM [PVTWEB].[dbo].[PCC03_SDOPTE] WITH(NOLOCK) 
						GROUP BY [PCC03_CPBCCCOD], [PCC03_CPBCCDES]
						) AS CCT
						LEFT OUTER JOIN 
									(SELECT [GRL030_CODIGO]
									 FROM [PVTWEB].[dbo].[GRL030_ABRDESC] WITH(NOLOCK) 
									 WHERE GRL030_ABRTIPO = 'CTRO CTO') AS CTA ON
							CCT.[PCC03_CPBCCCOD] = CTA.[GRL030_CODIGO]
				WHERE CTA.[GRL030_CODIGO] IS NULL
				ORDER BY [PCC03_CPBCCCOD]

-- ACTUALIZA el ctro ctos ABREVIADOS, seg�n la tabla [FV010_FVTA]
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
	SET [PCC03_CCTODESABR] = CTROCTODESABR
		, [PCC03_CCTOABR] = CTROCTOABR
		, [PCC03_CCABRCOD] = CCABRCOD
		, [PCC03_CCAC3] = CCAC3
		, [PCC03_MARCAABR] = MARCA
FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CCT WITH (NOLOCK) 
			LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS CTROCTOCODABR
									,[GRL030_DESCRIPC] AS CTROCTODESABR
									,[GRL030_DESCABR] AS CTROCTOABR
									,[GRL030_AGR01] AS CCABRCOD
									,LEFT([GRL030_AGR01],3) AS CCAC3
									,CASE WHEN LEFT([GRL030_AGR01],3) = 'PVN' THEN 'NISSAN' 
										  WHEN LEFT([GRL030_AGR01],3) = 'PVR' THEN 'RENAULT' 
										  ELSE 'OTRA' 
									 END AS MARCA
							  FROM [PVTWEB].[dbo].[GRL030_ABRDESC] WITH (NOLOCK)
							  WHERE [GRL030_ABRTIPO] = 'CTRO CTO'
							) AS AB ON
								CCT.[PCC03_CPBCCCOD] = AB.[CTROCTOCODABR]

-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- *******************************************************************************************************************************************
-- ########################################################################################################################
-- FIN -- AJUSTA LOS CENTROS DE COSTOS
-- ########################################################################################################################



-- ########################################################################################################################
-- INICIO -- ACTUALIZA EL ID DEL CLIENTE VACIOS, ESTOS ES DE LOS CLIENTES VIEJO
-- ########################################################################################################################
-- INICIO ACTUALIZA ID DE CLIENTE ############################################################################################################################
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 12, @PROCNUM, 'ACT_DATOS', 'ACT_ID_CLIENTE', '[GRL012_CLIRESP]', 'Act el ID de los Clientes vacios', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- Actualiza el ID de Cliente en la tabla SDOPTE
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_CTAID] = CLI.[GRL010_CLIID]
--		SELECT TOP 10 CLI.[GRL010_CLIID], *
		FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CCT 
			INNER JOIN [PVTWEB].[dbo].[GRL010_CLIENT] AS CLI ON
				CCT.[PCC03_CTACOD] = CLI.[GRL010_CLICOD]
		WHERE [PCC03_CTAID] IS NULL

-- Acctualiza el Id de Cliente en la tabla SDOPTEEVOL
UPDATE [PVTWEB].[dbo].[PCC031_SDOPTEEVOL]
   SET [PCC031_CTAID] = CLI.[GRL010_CLIID]
--		SELECT TOP 10 CLI.[GRL010_CLIID], *
		FROM [PVTWEB].[dbo].[PCC031_SDOPTEEVOL] AS CCE 
			INNER JOIN [PVTWEB].[dbo].[GRL010_CLIENT] AS CLI ON
				CCE.[PCC031_CTACOD] = CLI.[GRL010_CLICOD]
		WHERE [PCC031_CTAID] IS NULL

-- Actualiza el ID de Cliente en la tabla SDOHIST
UPDATE [PVTWEB].[dbo].[PCC04_SDOHST]
   SET [PCC04_CTAID] = CLI.[GRL010_CLIID]
--		SELECT TOP 10 CLI.[GRL010_CLIID], *
		FROM [PVTWEB].[dbo].[PCC04_SDOHST] AS CCH 
			INNER JOIN [PVTWEB].[dbo].[GRL010_CLIENT] AS CLI ON
				CCH.[PCC04_CTACOD] = CLI.[GRL010_CLICOD]
		WHERE [PCC04_CTAID] IS NULL

-- Actualiza el campo CTA CODIGO DENOMINACI�N PARA FACILITAR LAS BUSQUEDA
-- Actualiza el ID de Cliente en la tabla SDOPTE
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_CTACODDEN] = CAST([PCC03_CTACOD] AS VARCHAR(10)) + ' ' + CAST([PCC03_CTADEN] AS VARCHAR(150))


-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ########################################################################################################################
-- FIN -- ACTUALIZA EL ID DEL CLIENTE
-- ########################################################################################################################


-- ########################################################################################################################
-- INICIO -- ACTUALIZA EL RESPONSABLE DEL CLIENTE
-- ########################################################################################################################
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 13, @PROCNUM, 'ACT_DATOS', 'ACT_RESP_CLIENTE', '[GRL030_ABRDESC]', 'Act el Responsable de los Clientes', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

-- INSERTA LOS NUEVOS USUARIOS EN LA TABLA ABRDESC
INSERT INTO [PVTWEB].[dbo].[GRL030_ABRDESC]
           ([GRL030_CODIGO]
           ,[GRL030_DESCRIPC]
--           ,[GRL030_DESCABR]
           ,[GRL030_ABRTIPO]
--           ,[GRL030_AGR01]
			)
		SELECT EP.[PCC03_OTRECEPT]
				, EP.[PCC03_OTRECEPT]
				, 'RECEPTOR'
		FROM (
				SELECT [PCC03_OTRECEPT]
				FROM [PVTWEB].[dbo].[PCC03_SDOPTE] WITH(NOLOCK)
				GROUP BY [PCC03_OTRECEPT]
			  ) AS EP 
				LEFT OUTER JOIN 
				   (SELECT [GRL030_CODIGO]
						  ,[GRL030_DESCRIPC]
						  ,[GRL030_DESCABR]
						  ,[GRL030_ABRTIPO]
						  ,[GRL030_AGR01]
					  FROM [PVTWEB].[dbo].[GRL030_ABRDESC]
					WHERE ([GRL030_ABRTIPO] = 'RECEPTOR')
					) AS ET ON
				EP.[PCC03_OTRECEPT] = ET.[GRL030_CODIGO]
		WHERE ET.[GRL030_CODIGO] IS NULL


-- INSERTA LOS USUARIOS QUE OPERARON EL SISTEMA EN LA TABLA [GRL030_ABRDESC]
INSERT INTO [PVTWEB].[dbo].[GRL030_ABRDESC]
           ([GRL030_CODIGO]
--           ,[GRL030_DESCRIPC]
--           ,[GRL030_DESCABR]
           ,[GRL030_ABRTIPO]
--           ,[GRL030_AGR01]
			)
			SELECT [PCC03_OTVEHUSUABRIOT] AS 'CODIGO'
					,'USUSIST' AS 'ABRTIPO'
			FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CC 
				LEFT OUTER JOIN (SELECT [GRL030_CODIGO] 
									FROM [PVTWEB].[dbo].[GRL030_ABRDESC] 
									WHERE [GRL030_ABRTIPO] = 'USUSIST' 
									GROUP BY [GRL030_CODIGO]
								 ) AS AB
					ON CC.[PCC03_OTVEHUSUABRIOT] = AB.[GRL030_CODIGO]
				WHERE AB.[GRL030_CODIGO] IS NULL
			GROUP BY [PCC03_OTVEHUSUABRIOT]

-- ######################################################################################################################################
-- INSERTA LOS CLIENTES NUEVOS CON LA TABLA DE RESPONSABLES
INSERT INTO [PVTWEB].[dbo].[GRL012_CLIRESP]
           (
			[GRL012_CLIID]
           ,[GRL012_CLICOD]
           ,[GRL012_CLICCTO]
           ,[GRL012_CLIRAZSOC]
--           ,[GRL012_CLIRESPNOM]
--           ,[GRL012_CLIRESPID]
			)
	-- LISTA LOS CLIENTES Y SUS CENTROS DE COSTOS QUE TODAVIA NO ESTAN EN LA TABLA DE RESPONSABLES
     SELECT [PCC03_CTAID], [PCC03_CTACOD], [PCC03_CPBCCCOD], [PCC03_CTADEN]
		FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CTACTE
			LEFT OUTER JOIN [PVTWEB].[dbo].[GRL012_CLIRESP] AS CLRES ON
				CTACTE.[PCC03_CTACOD] = CLRES.[GRL012_CLICOD]
					AND
				CTACTE.[PCC03_CPBCCCOD] = CLRES.[GRL012_CLICCTO]
	 WHERE CLRES.[GRL012_CLICOD] IS NULL
	 GROUP BY [PCC03_CTAID], [PCC03_CTACOD], [PCC03_CPBCCCOD], [PCC03_CTADEN], LEFT([PCC03_CTADEN], 15)
	 ORDER BY [PCC03_CTAID], [PCC03_CTACOD], [PCC03_CPBCCCOD]


-- ACTUALIZA EL RESPONSABLE FINAL DEL CLIENTE, EN LAS DISTINTAS TABLAS
-- ACTUALIZA LA TABLA DE RESPONSABLE DE VENTAS
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_CLIRESP] = CASE WHEN [GRL012_CLIRESPNOM] IS NULL	-- CLIENTE NO DE REPUESTOS
							THEN CASE WHEN [RECEPABR] IS NULL	-- EL RECEPTOR NO TIENE CODIGO ABREVIADO EN LA TABLA [GRL030_ABRDESC]
										THEN CASE WHEN [USUABR] IS NULL THEN	-- EL USUARIO NO TIENE CODIGO ABREVIADO EN LA TABLA [GRL030_ABRDESC]
														CASE WHEN [PCC03_OTRECEPT] IS NULL THEN	-- EL CAMPO USUARIO NO TIENE NOMBRE
																CASE WHEN [PCC03_OTVEHUSUABRIOT] IS NULL THEN 'A DEFINIR' ELSE [PCC03_OTVEHUSUABRIOT] END	-- SI NO TIENE USUARIO - PONE A DEFINIR - SI NO EL USUARIO
															 ELSE [PCC03_OTRECEPT]
														END
												  ELSE [USUABR]
											 END
									   ELSE [RECEPABR]
								 END
						ELSE [GRL012_CLIRESPNOM]
					END
		FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CCT  WITH (NOLOCK)
				LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS RECEPTCODABR
										,[GRL030_DESCRIPC] AS RECEPTDESC
										,[GRL030_DESCABR] AS RECEPABR
										,[GRL030_AGR01] AS RECAGR
								  FROM [PVTWEB].[dbo].[GRL030_ABRDESC]  WITH (NOLOCK)
								  WHERE [GRL030_ABRTIPO] = 'RECEPTOR'
								) AS AB2 ON
									CCT.[PCC03_OTRECEPT] = AB2.[RECEPTCODABR]
				LEFT OUTER JOIN (SELECT [GRL030_CODIGO] AS USUCODABR
											,[GRL030_DESCRIPC] AS USUDESC
											,[GRL030_DESCABR] AS USUABR
											,[GRL030_AGR01] AS USUAGR
									  FROM [PVTWEB].[dbo].[GRL030_ABRDESC]  WITH (NOLOCK)
									  WHERE [GRL030_ABRTIPO] = 'USUSIST'
								 ) AS AB3 ON
									CCT.[PCC03_OTVEHUSUABRIOT] = AB3.[USUCODABR]
				LEFT OUTER JOIN (SELECT [GRL012_CLIID]
								  ,[GRL012_CLICCTO]
								  ,[GRL012_CLICOD]
								  ,[GRL012_CLIRAZSOC]
								  ,[GRL012_CLIRESPNOM]
								  ,[GRL012_CLIRESPID]
								  ,[GRL012_CLITIPOABR]
								FROM [PVTWEB].[dbo].[GRL012_CLIRESP] WITH (NOLOCK)
								) AS CR ON
									CCT.[PCC03_CTAID] = CR.[GRL012_CLIID]
										AND 
									CCT.PCC03_CPBCCGEST = CR.[GRL012_CLICCTO]

-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ########################################################################################################################
-- FIN -- ACTUALIZA EL RESPONSABLE DEL CLIENTE
-- ########################################################################################################################

---- Controla que no haya duplicados en los Clientes Responsables
--SELECT [GRL012_CLIID]
--      ,[GRL012_CLICCTO]
--      ,COUNT(*) AS TOT
--  FROM [PVTWEB].[dbo].[GRL012_CLIRESP]
--GROUP BY [GRL012_CLIID]
--      ,[GRL012_CLICCTO]
--HAVING COUNT(*) > 1
--
---- Lista los Clientes responsables
--SELECT [GRL012_CLIID]
--      ,[GRL012_CLICCTO]
--      ,[GRL012_CLICOD]
--      ,[GRL012_CLIRAZSOC]
--      ,[GRL012_CLIRESPNOM]
--      ,[GRL012_CLIRESPID]
--  FROM [PVTWEB].[dbo].[GRL012_CLIRESP]
--WHERE [GRL012_CLIID] = '240958D8-E1B9-45CE-9D1F-C0671FD441C0'


-- ########################################################################################################################
-- INICIO -- CARGA LOS CLIENTES EN LA TABLA DE CLIENTE TIPO
-- ########################################################################################################################
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 14, @PROCNUM, 'ACT_DATOS', 'ACT_TIPO_CLIENTE', '[GRL014_CLITIPO]', 'Act el Tipo de Cliente', CAST(GETDATE() AS SMALLDATETIME), NULL

-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- ACTUALIZA LA TABLA DE CLIENTE TIPO
INSERT INTO [PVTWEB].[dbo].[GRL014_CLITIPO]
           ([GRL014_CTAID]
           ,[GRL014_CTACOD]
           ,[GRL014_CLIRAZSOC]
           ,[GRL014_CLINOMABR]
--           ,[GRL014_CLIDNINUM]
--           ,[GRL014_CTACODUNIF]
           ,[GRL014_CLITIPOCAL]
--           ,[GRL014_CLITIPO]
           ,[GRL014_CLITIPOABR]
			)
	SELECT [PCC03_CTAID]
			, MIN([PCC03_CTACOD]) AS [FV010_CTACOD]
			, MIN([PCC03_CTADEN]) AS [FV010_CTACOD]
			, MIN(CASE WHEN CHARINDEX(' ', [PCC03_CTADEN], CHARINDEX(' ', [PCC03_CTADEN], 0)) = 0 
								 THEN [PCC03_CTADEN]
								 ELSE LTRIM(SUBSTRING([PCC03_CTADEN], 0, CHARINDEX(' ', [PCC03_CTADEN], CHARINDEX(' ', [PCC03_CTADEN], 0) + 1)))
							END) AS [GRL014_CLINOMABR]
			--, MIN([FV010_CLITIPO]) AS [FV010_CLITIPO]
			, '20 - General' AS CLITIPO
			, '01 - General' AS CLITIPABR
		FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CTACTE
			LEFT OUTER JOIN [PVTWEB].[dbo].[GRL014_CLITIPO] AS CLTIP ON
				CTACTE.[PCC03_CTAID] = CLTIP.[GRL014_CTAID]
	 WHERE CLTIP.[GRL014_CTAID] IS NULL
	 GROUP BY [PCC03_CTAID]

-- ACTUALIZA EL CODIGO DE CLIENTE EN LA TABLA GRL014_CLITIPO
-- INICIO --  ACTUALIZA EL CODIGO DE CLIENTE DESDE CALIPSO
-- ------------------------------------------------------------------------------------------------------------------------------
UPDATE [PVTWEB].[dbo].[GRL014_CLITIPO]
   SET [GRL014_CLITIPO] = [GRL0142_CLITIPO]
		, [GRL014_CLITIPOABR] = [GRL0142_CLITIPABR]
--		SELECT TOP 10000 [GRL014_CTAID], [GRL014_CLITIPO], [GRL0142_CLITIPCAL], [GRL0142_CLITIPO], [GRL0142_CLITIPABR]
		FROM [PVTWEB].[dbo].[GRL014_CLITIPO] AS CT
			INNER JOIN [PVTWEB].[dbo].[GRL0142_CLITIPOS] AS CTC ON
					CT.[GRL014_CLITIPOCAL] = CTC.[GRL0142_CLITIPCAL]
		WHERE [GRL014_CLITIPOABR] IS NULL
-- ------------------------------------------------------------------------------------------------------------------------------

-- ACTUALIZA EL CLIENTE TIPO ABREVIADO
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_CLITIPO] = [GRL014_CLITIPO]
		, [PCC03_CLITIPOABR] = [GRL014_CLITIPOABR]
		-- FALTA AGREGAR LA CUENTA CODIGO UNIFICADA, PARA FILTRAR SEG�N LAS CONSOLIDACIONES DE CLIENTES Y NO MANEJAR LAS DUPLICACIONES, 
--SELECT TOP 100 *
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CCT WITH (NOLOCK) 
			LEFT OUTER JOIN (SELECT [GRL014_CTAID]
								  ,[GRL014_CTACOD]
								  ,[GRL014_CLIRAZSOC]
								  ,[GRL014_CLINOMABR]
								  ,[GRL014_CTACODUNIF]
								  ,[GRL014_CLITIPO]
								  ,[GRL014_CLITIPOABR]
							  FROM [PVTWEB].[dbo].[GRL014_CLITIPO]
						 ) AS CT ON
								CCT.[PCC03_CTAID] = CT.[GRL014_CTAID]

-- ACTUALIZA EL CLIENTE TIPO ABREVIADO, DESDE LA TABLA [GRL0142_CLITIPOS]
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_CLITIPOABR] = [GRL0142_CLITIPABR]
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CC WITH (NOLOCK) 
			LEFT OUTER JOIN (SELECT [GRL0142_CLITIPCAL]
								  ,[GRL0142_CLITIPO]
								  ,[GRL0142_CLITIPABR]
							  FROM [PVTWEB].[dbo].[GRL0142_CLITIPOS]) AS CTC ON
			CC.[PCC03_CLITIPO] = CTC.[GRL0142_CLITIPO]
	WHERE [PCC03_CLITIPOABR] IS NULL

-- ACTUALIZA LOS QUE SON NULOS
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_CLITIPO] = '20 - General'
		, [PCC03_CLITIPOABR] = '01 - General'
	WHERE [PCC03_CLITIPO] IS NULL OR [PCC03_CLITIPOABR] IS NULL

--SELECT TOP 100 [PCC03_CLITIPO], [PCC03_CLITIPOABR], COUNT(*) AS TOTAL
--FROM [PVTWEB].[dbo].[PCC03_SDOPTE]
--GROUP BY [PCC03_CLITIPO], [PCC03_CLITIPOABR]
--ORDER BY [PCC03_CLITIPO], [PCC03_CLITIPOABR]



-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ########################################################################################################################
-- FIN -- CARGA LOS CLIENTES EN LA TABLA DE CLIENTE TIPO
-- ########################################################################################################################


-- ########################################################################################################################
-- INICIO -- SEPARA LA MIGRACI�N DEL STOCK DE TAGLE A NIX - CREA EL CC 2020120
-- ########################################################################################################################
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 15, @PROCNUM, 'ACT_DATOS', 'MIGR_NIXSA', '[PCC03_SDOPTE]', 'Separa la migracion Nixsa', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- ACTUALIZA POR COMPROBANTE ID
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_CPBCCGEST] = [PCC032_CPBCCDEST]
--	SELECT TOP 10 *
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CC WITH (NOLOCK)
		INNER JOIN (
					SELECT [PCC032_CLAVEID]
						  ,[PCC032_CPBCCORIG]
						  ,[PCC032_CPBCCDEST]
						  ,[PCC032_CPBCCDESTDET]
					  FROM [PVTWEB].[dbo].[PCC032_AJUIND] WITH (NOLOCK)
					  WHERE [PCC032_TIPO] = 'COMPROBANTE'
					) AS CI ON
		CC.[PCC03_CPBTEID] = CI.[PCC032_CLAVEID]

-- ACTUALIZA POR CLIENTE ID
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [PCC03_CPBCCGEST] = [PCC032_CPBCCDEST]
--	SELECT TOP 10 *
	FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CC WITH (NOLOCK)
		INNER JOIN (
					SELECT [PCC032_CLAVEID]
						  ,[PCC032_CPBCCORIG]
						  ,[PCC032_CPBCCDEST]
						  ,[PCC032_CPBCCDESTDET]
					  FROM [PVTWEB].[dbo].[PCC032_AJUIND] WITH (NOLOCK)
					  WHERE [PCC032_TIPO] = 'CLIENTE'
					) AS CI ON
		CC.[PCC03_CTAID] = CI.[PCC032_CLAVEID]
			AND
		CC.[PCC03_CPBCCCOD] = CI.[PCC032_CPBCCORIG]	
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- ########################################################################################################################
-- FIN -- SEPARA LA MIGRACI�N DEL STOCK DE TAGLE A NIX - CREA EL CC 2020120
-- ########################################################################################################################


-- ########################################################################################################################
-- INICIO -- ACTUALIZA PROCESOS
-- ########################################################################################################################
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
			([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'CCTE_ACT', 16, @PROCNUM, 'ACT_DATOS', 'PROC_ACT', '[PCC03_SDOPTE]', 'Actualiza el ID del Proceso', CAST(GETDATE() AS SMALLDATETIME), NULL
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[PCC03_SDOPTE]
   SET [GPR03_PROCID] = [GPR00_PROCID]
      ,[GPR03_PRETMID] = [GPR01_PRETMID]
--      ,[GPR03_PROETM] = <GPR03_PROETM, char(10),>
--      ,[PCC03_PRETCOM] = <PCC03_PRETCOM, nvarchar(255),>
--      ,[PCC03_PRETCOM02] = <PCC03_PRETCOM02, nvarchar(255),>
--      ,[PCC03_PRETFECH] = <PCC03_PRETFECH, smalldatetime,>
--      ,[PCC03_ACTCOD] = <PCC03_ACTCOD, nvarchar(50),>
--      ,[PCC03_FECACT] = <PCC03_FECACT, smalldatetime,>
--      ,[PCC03_USUABR] = <PCC03_USUABR, varchar(15),>
 FROM [PVTWEB].[dbo].[PCC03_SDOPTE] AS CSP WITH (NOLOCK)
	INNER JOIN (
				SELECT [GPR01_PRETMID]
					  ,[GPR00_PROCID]
					  ,[GPR01_PROETM]
					  ,[GPR02_ETCOID]
					  ,[GPR03_MOTID]
					  ,[GPR01_ETMDEC]
				  FROM [PVTWEB].[dbo].[GPR01_PROGES] WITH (NOLOCK)
				) AS PR ON
		CSP.[GPR03_PROETM] = PR.[GPR01_PROETM]
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT

-- BORRA EL CODIGO DEL PROCESO QUE TERMINO
DELETE FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WHERE [GRL098_PROC] = 'CCTE_ACT'

-- ###################################################################################################################################
-- FIN - ACTCC_PASO 8  -- ACTUALIZA DATOS Y TABLAS VARIAS
-- ###################################################################################################################################
