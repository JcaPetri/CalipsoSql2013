
-- ########################################################################################################################################
-- INICIO -- KARDEX TAGLE
-- ########################################################################################################################################

DECLARE @PROD_ID AS NVARCHAR(50)
DECLARE @PROD_COD AS NVARCHAR(20)
DECLARE @DEP_ID1 AS NVARCHAR(50)
DECLARE @UBI_ID1 AS NVARCHAR(50)
DECLARE @DEP_ID2 AS NVARCHAR(50)
DECLARE @UBI_ID2 AS NVARCHAR(50)
DECLARE @DEP_ID3 AS NVARCHAR(50)
DECLARE @UBI_ID3 AS NVARCHAR(50)

SET @PROD_ID = ''	-- {F41F419A-DC57-4FDA-966A-8287533853E1}
SET @PROD_COD = '8200840770 I'		--7700274177 I	0225244664 alfombras
SET @DEP_ID1 = 'B9EF3D86-DCFA-46EC-BB41-59BFCF94662B'	-- Deposito Comercial Cordoba
SET @UBI_ID1 = 'B8753321-5C5E-4A64-BEBC-A91204FA63F1'	-- UBICACI�N UNICA

SET @DEP_ID2 = 'FB512A71-3225-4140-B3FE-A1893C95630B'	-- Deposito Garantia Cordoba
SET @UBI_ID2 = '5D2C47C5-FFA4-4010-8F3E-E369C90DBE87'	-- UBICACI�N UNICA

SET @DEP_ID3 = 'C02692AE-BA47-4C3F-9639-85DD0396D152'	-- Deposito Garantia Cordoba
SET @UBI_ID3 = '138A01B4-6F83-48C1-AE79-A80A8FA2025F'	-- UBICACI�N UNICA

SELECT 
	-- PRODUCTO_ID
	NOMBREREFERENCIA
	, DESCRIPCION
--	, FECHADOCUMENTO
--	, FECHA_DOCUM
--	, CONVERT(VARCHAR, FECHA_DOCUM, 103) AS FECHA_DOCUM
--	, FECHAINV
--	, FECHA_INV
--	, FECHAVEN
--	, FECHA_VTO
--	, INV.FECHAENTREGA
	, FECHA_ENTREGA AS FECHA_ENTREGA
	, TRANSAC_DOCUM AS DOCU_TRANSAC
	, TRANSAC_NUMDOC AS DOCU_NUM
--	, TRANSAC_NUMITEM
	, DEP_NOMB AS DEP_SUC
--	, INV.[DEPOSITODES_ID]
	, UBI_NOMB AS DEP_UBIC
--	, INV.[UBICACIONDES_ID]
--	, INV.[ESTADOTR] AS TRANSAC_ESTA
--	, BULTOS
	, CASE WHEN CANTIDAD > 0 THEN CANTIDAD ELSE 0 END AS INGRESO
	, CASE WHEN CANTIDAD < 0 THEN CANTIDAD ELSE 0 END AS EGRESO
	, CANTIDAD
	, COSTO
	, TOTAL 
--	, INV.MOMENTOTR
--	, TRANSAC_FECHA
--	, convert(varchar,TRANSAC_FECHA,103) as TRANSAC_FECHA
	, TRANSAC_ORIGINANTE AS DEP_DESDE
	, TRANSAC_DESTINATARIO AS DEP_HASTA
	, ORDENTRABAJO AS OT
	, RECURSOGARANTIA AS RG
	, CANAL AS RG_CANAL
	, VIN AS VIN
FROM (
	-- #####################################################################################################################################
	-- CALIPSO KARDEX --
	-- #####################################################################################################################################
		SELECT TOP 10000 referenciatipo_id AS PRODUCTO_ID
			, INV.NOMBREREFERENCIA
			, INV.DESCRIPCION
--			, INV.FECHADOCUMENTO
			, SUBSTRING(INV.FECHADOCUMENTO,7,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,5,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,0,5) AS FECHA_DOCUM
--			, INV.FECHAINV
--			, SUBSTRING(INV.FECHAINV,7,2) + '/' + SUBSTRING(INV.FECHAINV,5,2) + '/' + SUBSTRING(INV.FECHAINV,0,5) AS FECHA_INV
--			, INV.FECHAVEN
--			, SUBSTRING(INV.FECHAVEN,7,2) + '/' + SUBSTRING(INV.FECHAVEN,5,2) + '/' + SUBSTRING(INV.FECHAVEN,0,5) AS FECHA_VTO
--			, INV.FECHAENTREGA
			, SUBSTRING(INV.FECHAENTREGA,7,2) + '/' + SUBSTRING(INV.FECHAENTREGA,5,2) + '/' + SUBSTRING(INV.FECHAENTREGA,0,5) AS FECHA_ENTREGA
			, INV.NOMBRETR AS TRANSAC_DOCUM
			, INV.NUMERODOCUMENTO AS TRANSAC_NUMDOC
			, INV.NUMEROITEM AS TRANSAC_NUMITEM
			, ALIAS_1.NOMBRE AS DEP_NOMB
--			, INV.[DEPOSITODES_ID]
			, ALIAS_2.NOMBRE AS UBI_NOMB
--			, INV.[UBICACIONDES_ID]
--			, INV.[ESTADOTR] AS TRANSAC_ESTA
			, INV.BULTOS
			, cantidad2_cantidad AS CANTIDAD
			, valor2_importe AS COSTO
			, cantidad2_cantidad * valor2_importe AS TOTAL 
--			, INV.MOMENTOTR
			, SUBSTRING(INV.MOMENTOTR,7,2) + '/' + SUBSTRING(INV.MOMENTOTR,5,2) + '/' + SUBSTRING(INV.MOMENTOTR,0,5) AS TRANSAC_FECHA
			, INV.NOMBREORIGINANTETR AS TRANSAC_ORIGINANTE
			, INV.NOMBREDESTINATARIOTR AS TRANSAC_DESTINATARIO,
			'' AS ORDENTRABAJO,
			'' AS RECURSOGARANTIA,
			'' AS CANAL,
			'' AS VIN
--				, INV.*
	  FROM [ERPSERVER].[CalipsoProduccion].[dbo].[itemingresoinventario] AS INV
		LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[V_DEPOSITO_] ALIAS_1 ON 
			INV.[DEPOSITODES_ID] = ALIAS_1.ID   
		LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[V_UBICACION_] ALIAS_2 ON 
			INV.[UBICACIONDES_ID] = ALIAS_2.ID 
	  WHERE ((ALIAS_1.[UBICACIONES_ID] = @DEP_ID1 AND ALIAS_2.[ID] = @UBI_ID1) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID2 AND ALIAS_2.[ID] = @UBI_ID2) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID3 AND ALIAS_2.[ID] = @UBI_ID3))
			AND [ESTADOTR] = 'C' 
			AND (CAST([REFERENCIATIPO_ID] AS NVARCHAR(50)) = @PROD_ID OR INV.NOMBREREFERENCIA = @PROD_COD)
		UNION ALL
		SELECT TOP 10000 referenciatipo_id AS PRODUCTO_ID
			, INV.NOMBREREFERENCIA
			, INV.DESCRIPCION
--			, INV.FECHADOCUMENTO
			, SUBSTRING(INV.FECHADOCUMENTO,7,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,5,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,0,5) AS FECHA_DOCUM
--			, INV.FECHAINV
--			, SUBSTRING(INV.FECHAINV,7,2) + '/' + SUBSTRING(INV.FECHAINV,5,2) + '/' + SUBSTRING(INV.FECHAINV,0,5) AS FECHA_INV
--			, INV.FECHAVEN
--			, SUBSTRING(INV.FECHAVEN,7,2) + '/' + SUBSTRING(INV.FECHAVEN,5,2) + '/' + SUBSTRING(INV.FECHAVEN,0,5) AS FECHA_VTO
--			, INV.FECHAENTREGA
			, SUBSTRING(INV.FECHAENTREGA,7,2) + '/' + SUBSTRING(INV.FECHAENTREGA,5,2) + '/' + SUBSTRING(INV.FECHAENTREGA,0,5) AS FECHA_ENTREGA
			, INV.NOMBRETR AS TRANSAC_DOCUM
			, INV.NUMERODOCUMENTO AS TRANSAC_NUMDOC
			, INV.NUMEROITEM AS TRANSAC_NUMITEM
			, ALIAS_1.NOMBRE AS DEP_NOMB
--			, INV.[DEPOSITODES_ID]
			, ALIAS_2.NOMBRE AS UBI_NOMB
--			, INV.[UBICACIONDES_ID]
--			, INV.[ESTADOTR] AS TRANSAC_ESTA
			, INV.BULTOS
			, cantidad2_cantidad * -1 AS CANTIDAD
			, valor2_importe AS COSTO
			, cantidad2_cantidad * valor2_importe * -1 AS TOTAL 
--			, INV.MOMENTOTR
			, SUBSTRING(INV.MOMENTOTR,7,2) + '/' + SUBSTRING(INV.MOMENTOTR,5,2) + '/' + SUBSTRING(INV.MOMENTOTR,0,5) AS TRANSAC_FECHA
			, INV.NOMBREORIGINANTETR AS TRANSAC_ORIGINANTE
			, INV.NOMBREDESTINATARIOTR AS TRANSAC_DESTINATARIO,
--			, INV.*
			ALIAS_5.NOMBRE AS ORDENTRABAJO,
			ALIAS_8.NOMBRE AS RECURSOGARANTIA,
			ALIAS_10.NOMBRE AS CANAL,
			ALIAS_13.NUMEROCHASIS AS VIN
		FROM [ERPSERVER].[CalipsoProduccion].[dbo].[itemegresoinventario] AS INV
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[V_DEPOSITO_] ALIAS_1 WITH(NOLOCK) ON 
				INV.[DEPOSITOORI_ID] = ALIAS_1.ID   
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[V_UBICACION_] ALIAS_2 WITH(NOLOCK) ON 
				INV.[UBICACIONORI_ID] = ALIAS_2.ID 
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[TREGRESOINVENTARIO] ALIAS_3 WITH(NOLOCK) ON
				INV.[PLACEOWNER_ID] = ALIAS_3.ID
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[UD_VALEENTREGAPIEZAS] ALIAS_4 WITH(NOLOCK) ON
				ALIAS_3.BOEXTENSION_ID = ALIAS_4.ID
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[TRORDENVENTA] ALIAS_5 WITH(NOLOCK) ON -- JOIN CON OT
				ALIAS_4.ORDENTRABAJO_ID = ALIAS_5.ID

		    LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[TRPROCESOPORLOTE] ALIAS_6 WITH(NOLOCK) ON 
				ALIAS_5.ID = ALIAS_6.TRANSACCION_ID AND ALIAS_6.RELACION_ID = '9090399B-EF8B-400E-BA0D-5A7F5F455D1F' 
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[AGENTEPROCESOPORLOTE] ALIAS_7 WITH(NOLOCK) ON 
				ALIAS_7.TRSORIGEN_ID = ALIAS_6.BO_PLACE_ID AND ALIAS_7.RELACIONORIGEN_ID = '9090399B-EF8B-400E-BA0D-5A7F5F455D1F' 
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[TRORDENVENTA] ALIAS_8 WITH(NOLOCK) ON -- JOIN CON LOS RECURSOS DE GARANTIA
				ALIAS_7.ID = ALIAS_8.GENERADAPOR_ID 
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[UD_ITEMENTREGAPIEZAS] ALIAS_9 WITH(NOLOCK) ON 
				INV.BOEXTENSION_ID = ALIAS_9.ID
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] ALIAS_10 WITH(NOLOCK) ON -- JOIN CON EL CANAL
				ALIAS_9.CANAL_ID = ALIAS_10.ID 
			
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[UD_ORDENTRABAJO] ALIAS_11 WITH(NOLOCK) ON 
				ALIAS_5.BOEXTENSION_ID = ALIAS_11.ID
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[PRODUCTO] ALIAS_12 WITH(NOLOCK) ON 
				ALIAS_11.VEHICULO_ID = ALIAS_12.ID
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[UD_PRODUCTO] ALIAS_13 WITH(NOLOCK) ON 
				ALIAS_12.BOEXTENSION_ID = ALIAS_13.ID


		WHERE ((ALIAS_1.[UBICACIONES_ID] = @DEP_ID1 AND ALIAS_2.[ID] = @UBI_ID1) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID2 AND ALIAS_2.[ID] = @UBI_ID2) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID3 AND ALIAS_2.[ID] = @UBI_ID3))
			AND [ESTADOTR] = 'C' 
			AND (CAST([REFERENCIATIPO_ID] AS NVARCHAR(50)) = @PROD_ID OR INV.NOMBREREFERENCIA LIKE @PROD_COD)
		UNION ALL
		SELECT TOP 10000 referenciatipo_id AS PRODUCTO_ID
			, INV.NOMBREREFERENCIA
			, INV.DESCRIPCION
--			, INV.FECHADOCUMENTO
			, SUBSTRING(INV.FECHADOCUMENTO,7,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,5,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,0,5) AS FECHA_DOCUM
--			, INV.FECHAINV
--			, SUBSTRING(INV.FECHAINV,7,2) + '/' + SUBSTRING(INV.FECHAINV,5,2) + '/' + SUBSTRING(INV.FECHAINV,0,5) AS FECHA_INV
--			, INV.FECHAVEN
--			, SUBSTRING(INV.FECHAVEN,7,2) + '/' + SUBSTRING(INV.FECHAVEN,5,2) + '/' + SUBSTRING(INV.FECHAVEN,0,5) AS FECHA_VTO
--			, INV.FECHAENTREGA
			, SUBSTRING(INV.FECHAENTREGA,7,2) + '/' + SUBSTRING(INV.FECHAENTREGA,5,2) + '/' + SUBSTRING(INV.FECHAENTREGA,0,5) AS FECHA_ENTREGA
			, INV.NOMBRETR AS TRANSAC_DOCUM
			, INV.NUMERODOCUMENTO AS TRANSAC_NUMDOC
			, INV.NUMEROITEM AS TRANSAC_NUMITEM
			, ALIAS_1.NOMBRE AS DEP_NOMB
--			, INV.[DEPOSITODES_ID]
			, ALIAS_2.NOMBRE AS UBI_NOMB
--			, INV.[UBICACIONDES_ID]
--			, INV.[ESTADOTR] AS TRANSAC_ESTA
			, INV.BULTOS
			, cantidad2_cantidad AS CANTIDAD
			, valor2_importe AS COSTO
			, cantidad2_cantidad * valor2_importe AS TOTAL
--			, INV.MOMENTOTR
			, SUBSTRING(INV.MOMENTOTR,7,2) + '/' + SUBSTRING(INV.MOMENTOTR,5,2) + '/' + SUBSTRING(INV.MOMENTOTR,0,5) AS TRANSAC_FECHA
			, INV.NOMBREORIGINANTETR AS TRANSAC_ORIGINANTE
			, INV.NOMBREDESTINATARIOTR AS TRANSAC_DESTINATARIO,
			'' AS ORDENTRABAJO,
			'' AS RECURSOGARANTIA,
			'' AS CANAL,
			'' AS VIN
--			, INV.*
		FROM [ERPSERVER].[CalipsoProduccion].[dbo].[itemtransferenciainventario] AS INV
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[V_DEPOSITO_] ALIAS_1 ON 
				INV.[DEPOSITODES_ID] = ALIAS_1.ID   
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[V_UBICACION_] ALIAS_2 ON 
				INV.[UBICACIONDES_ID] = ALIAS_2.ID 
		WHERE ((ALIAS_1.[UBICACIONES_ID] = @DEP_ID1 AND ALIAS_2.[ID] = @UBI_ID1) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID2 AND ALIAS_2.[ID] = @UBI_ID2) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID3 AND ALIAS_2.[ID] = @UBI_ID3))
			AND [ESTADOTR] = 'C' 
			AND (CAST([REFERENCIATIPO_ID] AS NVARCHAR(50)) = @PROD_ID OR INV.NOMBREREFERENCIA = @PROD_COD)
		UNION ALL
		SELECT TOP 10000 referenciatipo_id AS PRODUCTO_ID
			, INV.NOMBREREFERENCIA
			, INV.DESCRIPCION
--			, INV.FECHADOCUMENTO
			, SUBSTRING(INV.FECHADOCUMENTO,7,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,5,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,0,5) AS FECHA_DOCUM
--			, INV.FECHAINV
--			, SUBSTRING(INV.FECHAINV,7,2) + '/' + SUBSTRING(INV.FECHAINV,5,2) + '/' + SUBSTRING(INV.FECHAINV,0,5) AS FECHA_INV
--			, INV.FECHAVEN
--			, SUBSTRING(INV.FECHAVEN,7,2) + '/' + SUBSTRING(INV.FECHAVEN,5,2) + '/' + SUBSTRING(INV.FECHAVEN,0,5) AS FECHA_VTO
--			, INV.FECHAENTREGA
			, SUBSTRING(INV.FECHAENTREGA,7,2) + '/' + SUBSTRING(INV.FECHAENTREGA,5,2) + '/' + SUBSTRING(INV.FECHAENTREGA,0,5) AS FECHA_ENTREGA
			, INV.NOMBRETR AS TRANSAC_DOCUM
			, INV.NUMERODOCUMENTO AS TRANSAC_NUMDOC
			, INV.NUMEROITEM AS TRANSAC_NUMITEM
			, ALIAS_1.NOMBRE AS DEP_NOMB
--			, INV.[DEPOSITODES_ID]
			, ALIAS_2.NOMBRE AS UBI_NOMB
--			, INV.[UBICACIONDES_ID]
--			, INV.[ESTADOTR] AS TRANSAC_ESTA
			, INV.BULTOS
			, cantidad2_cantidad * -1 AS CANTIDAD
			, valor2_importe AS COSTO
			, cantidad2_cantidad * valor2_importe * -1 AS TOTAL
--			, INV.MOMENTOTR
			, SUBSTRING(INV.MOMENTOTR,7,2) + '/' + SUBSTRING(INV.MOMENTOTR,5,2) + '/' + SUBSTRING(INV.MOMENTOTR,0,5) AS TRANSAC_FECHA
			, INV.NOMBREORIGINANTETR AS TRANSAC_ORIGINANTE
			, INV.NOMBREDESTINATARIOTR AS TRANSAC_DESTINATARIO,
			'' AS ORDENTRABAJO,
			'' AS RECURSOGARANTIA,
			'' AS CANAL,
			'' AS VIN
--			, INV.*
		FROM [ERPSERVER].[CalipsoProduccion].[dbo].[itemtransferenciainventario] AS INV
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[V_DEPOSITO_] ALIAS_1 ON 
				INV.[DEPOSITOORI_ID] = ALIAS_1.ID   
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[V_UBICACION_] ALIAS_2 ON 
				INV.[UBICACIONORI_ID] = ALIAS_2.ID 
		WHERE ((ALIAS_1.[UBICACIONES_ID] = @DEP_ID1 AND ALIAS_2.[ID] = @UBI_ID1) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID2 AND ALIAS_2.[ID] = @UBI_ID2) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID3 AND ALIAS_2.[ID] = @UBI_ID3))
			AND [ESTADOTR] = 'C' 
			AND (CAST([REFERENCIATIPO_ID] AS NVARCHAR(50)) = @PROD_ID OR INV.NOMBREREFERENCIA = @PROD_COD)
		UNION ALL
	-- #####################################################################################################################################
	-- TECHCORE KARDEX --
	-- #####################################################################################################################################
	SELECT 
		-- null as PRODUCTO_ID
		rp.pie_numero as NOMBREREFERENCIA
		, rp.pie_nombre as DESCRIPCION
		, convert(varchar,VADEVO.dva_fecha) as FECHA_DOCUM
		-- , '' as FECHA_ENTREGA
		, 'Vale Devolucion Pieza' AS TRANSAC_DOCUM
		--, VADEVO.val_codigo AS TRANSAC_NUMDOC
		, CAST(VADEVO.val_codigo AS NVARCHAR(50)) as TRANSAC_NUMDOC
		, 0 AS TRANSAC_NUMITEM
		, '' AS DEP_NOMB
		, '' AS UBI_NOMB
		--, 0 as BULTOS
		, SUM(VADEVO.dva_cantidad) * -1 AS CANTIDAD
		, 0 AS COSTO
		, 0 AS TOTAL
		, VADEVO.dva_fecha AS TRANSAC_FECHA
		, '' AS TRANSAC_ORIGINANTE
		, cli.denominacion AS TRANSAC_DESTINATARIO
		, cast(ord.odr_codigo as varchar) AS ORDENTRABAJO
		, cast(rec.rec_codigo as varchar) AS RECURSOGARANTIA
		, vd.vdo_nombre AS CANAL
		, veh.veh_nro_vin AS VIN
	--				'VA' AS TIPO, 'Vale Devolucion Pieza' as DESCRIPCION,  cast(VADEVO.val_codigo as varchar) as NUMERODOCUMENTO, VADEVO.dva_fecha as FECHADOCUMENTO, '' as ESTADOTR, '' as NOMBREORIGINANTETR, '' as NOMBREDESTINATARIOTR, '' as NOMBRETOTALTR,     
	--				SUM(VADEVO.dva_cantidad) AS INGRESO , 0  AS EGRESO
	FROM [ERPSERVER].[TechCoreDB].[dbo].[REP_DETALLE_VALES] AS DVA 
		INNER JOIN [ERPSERVER].[TechCoreDB].[dbo].[REP_DETALLE_VALES] AS VADEVO ON 
				DVA.DEO_CODIGO = VADEVO.DEO_CODIGO 
				AND DVA.SUC_CODIGO = VADEVO.SUC_CODIGO 
				AND DVA.EMP_CODIGO = VADEVO.EMP_CODIGO 
				AND DVA.PIE_CODIGO = VADEVO.PIE_CODIGO 
				AND VADEVO.VAL_CODIGO = 0  
		INNER JOIN [ERPSERVER].[TechCoreDB].[dbo].[REP_DETALLE_VALES_REMITO] AS DVAR ON 
					 DVA.EMP_CODIGO = DVAR.EMP_CODIGO AND DVA.SUC_CODIGO = DVAR.SUC_CODIGO 
					 AND DVA.DVA_CODIGO = DVAR.DVA_CODIGO  
				 
				LEFT  JOIN  [ERPSERVER].[TechCoreDB].[dbo].TAL_DETALLE_ODR TDO ON TDO.EMP_CODIGO = DVA.EMP_CODIGO AND TDO.SUC_CODIGO = DVA.SUC_CODIGO AND
							TDO.DEO_CODIGO = DVA.DEO_CODIGO 
				inner join [ERPSERVER].[TechCoreDB].[dbo].tal_ordenes_reparacion ord on ord.emp_codigo=TDO.emp_codigo and ord.odr_codigo=TDO.odr_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].gen_vehiculos veh on veh.emp_codigo=ord.emp_codigo and veh.veh_codigo=ord.veh_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].tal_recursos rec on rec.emp_codigo=ord.emp_codigo and rec.odr_codigo=ord.odr_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].cfg_valores_dominios vd on vd.emp_codigo=TDO.emp_codigo and vd.vdo_codigo=TDO.deo_observacion
				left join  erpserver.CalipsoProduccion.dbo.cliente cli with(nolock) on cli.codigo=ord.cli_codigo
 
				LEFT JOIN  [ERPSERVER].[TechCoreDB].[dbo].REP_DETALLE_REMITO_GARANTIA RDRG ON DVAR.DETREM_CODIGO = RDRG.DRE_CODIGO AND DVA.EMP_CODIGO = RDRG.EMP_CODIGO AND
						   DVA.SUC_CODIGO = RDRG.SUC_CODIGO 
				left join [ERPSERVER].[TechCoreDB].[dbo].rep_piezas rp on dva.emp_codigo=rp.emp_codigo and rp.pie_codigo=dva.pie_codigo
				WHERE DVA.VAL_CODIGO <> 0  AND TDO.CAR_CODIGO = 8  --and
					  --AND DVA.PIE_CODIGO = @pie_codigo AND 
					  AND rp.PIE_numero = @PROD_COD 
						AND 	
					  DVA.EMP_CODIGO = 2  AND DVA.SUC_CODIGO = 21 --and
					  --DVA.DVA_FECHA > = @fechainicio 
					  --DVA.DVA_FECHA BETWEEN @fechainicio and getdate() --AND dateadd(hour,23,@fechafin)
				GROUP BY 
				rp.pie_codigo,
				rp.pie_numero,
				rp.pie_nombre,
				VADEVO.dva_fecha,
				VADEVO.val_codigo,
				VADEVO.dva_fecha,
				cli.denominacion,
				ord.odr_codigo,
				rec.rec_codigo,
				vd.vdo_nombre,
				veh.veh_nro_vin
				--VADEVO.VAL_CODIGO,VADEVO.DVA_FECHA

				union all    
				  
				----REMITO GARANTIA renault      
				SELECT
				null as PRODUCTO_ID,
				rp.pie_numero as NOMBREREFERENCIA,
				rp.pie_nombre as DESCRIPCION,
				convert(varchar,REP_REMITOS_GARANTIA.rem_fecha) as FECHA_DOCUM,
				'' as FECHA_ENTREGA,
				'Remito Garantia Ingreso Renault' AS TRANSAC_DOCUM,
				--TechCoreDB.dbo.REP_REMITOS_GARANTIA.rem_numero AS TRANSAC_NUMDOC,
				CAST(REP_REMITOS_GARANTIA.rem_numero AS NVARCHAR(50)) as TRANSAC_NUMDOC,
				0 AS TRANSAC_NUMITEM,
				'' AS DEP_NOMB,
				'' AS UBI_NOMB,
				0 as BULTOS,
				REP_DETALLE_REMITO_GARANTIA.dre_cantidad AS CANTIDAD,
				0 AS COSTO,
				0 AS TOTAL ,
				convert(datetime, REP_REMITOS_GARANTIA.rem_fecha, 103) AS TRANSAC_FECHA,
				'' AS TRANSAC_ORIGINANTE,
				'' AS TRANSAC_DESTINATARIO,
				'' AS ORDENTRABAJO,
				'' AS RECURSOGARANTIA,
				'' AS CANAL,
				'' AS VIN
--				'REMG' AS TIPO, 'Remito Garantia Ingreso Renault' as DESCRIPCION, TechCoreDB.dbo.REP_REMITOS_GARANTIA.rem_numero AS NUMERODOCUMENTO  
--				, cast(TechCoreDB.dbo.REP_REMITOS_GARANTIA.rem_fecha as varchar) AS FECHADOCUMENTO,'' AS ESTADOOTR,'' AS NOMBREORIGINANTETR, '' AS NOMBREDESTINATARIOTR,  
--				'' as NOMBRETOTALTR,  TechCoreDB.dbo.REP_DETALLE_REMITO_GARANTIA.dre_cantidad  AS INGRESO , 0 AS EGRESO  
				
				FROM [ERPSERVER].[TechCoreDB].[dbo].REP_REMITOS_GARANTIA  
				INNER JOIN [ERPSERVER].[TechCoreDB].[dbo].REP_DETALLE_REMITO_GARANTIA ON      
				REP_REMITOS_GARANTIA.emp_codigo=REP_DETALLE_REMITO_GARANTIA.emp_codigo and      
				REP_REMITOS_GARANTIA.suc_codigo=REP_DETALLE_REMITO_GARANTIA.suc_codigo and      
				REP_REMITOS_GARANTIA.rem_codigo=REP_DETALLE_REMITO_GARANTIA.rem_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].rep_piezas rp on rp.emp_codigo=REP_DETALLE_REMITO_GARANTIA.emp_codigo and REP_DETALLE_REMITO_GARANTIA.pie_codigo=rp.pie_codigo
				where REP_REMITOS_GARANTIA.emp_codigo=2 and REP_DETALLE_REMITO_GARANTIA.emp_codigo=2 and rp.pie_codigo=REP_DETALLE_REMITO_GARANTIA.pie_codigo   and   
				REP_REMITOS_GARANTIA.suc_codigo=21 and      
				--REP_REMITOS_GARANTIA.rem_fecha between @fechainicio and  getdate() and --dateadd(hour,23,@fechafin) and
				rp.pie_numero=@PROD_COD     
				--REP_DETALLE_REMITO_GARANTIA.pie_codigo=@pie_codigo    
				AND   REP_REMITOS_GARANTIA.rem_numero not LIKE '%PRESTAMO%' 

--) as s
--					
--				  
				UNION ALL  


				  
				SELECT 
				null as PRODUCTO_ID,
				rpie.pie_numero as NOMBREREFERENCIA,
				rpie.pie_nombre as DESCRIPCION,
				convert(varchar,RP.pre_fecha) as FECHA_DOCUM,
				'' as FECHA_ENTREGA,
				'Ingreso Prestamo Comercial' AS TRANSAC_DOCUM,
				CAST(RDP.pre_codigo AS varchar) AS TRANSAC_NUMDOC,
				0 AS TRANSAC_NUMITEM,
				'' AS DEP_NOMB,
				'' AS UBI_NOMB,
				0 as BULTOS,
				dpr_cantidad AS CANTIDAD,
				0 AS COSTO,
				0 AS TOTAL ,
				convert(datetime,RP.pre_fecha, 103) AS TRANSAC_FECHA,
				'' AS TRANSAC_ORIGINANTE,
				'' AS TRANSAC_DESTINATARIO,
				'' AS ORDENTRABAJO,
				'' AS RECURSOGARANTIA,
				'' AS CANAL,
				'' AS VIN

--				'EPRE' AS TIPO, 'Ingreso Prestamo Comercial ' AS DESCRIPCION, CAST(RDP.pre_codigo AS varchar) AS NUMERODOCUMENTO, RP.pre_fecha AS FECHADOCUMENTO,  
--				 '' AS ESTADOTR, '' AS NOMBREORIGINANTETR, '' AS NOMBREDESTINATARIOTR, '' AS NOMBRETOTALTR,  dpr_cantidad AS INGRESO,  0 AS EGRESO  

				FROM         [ERPSERVER].[TechCoreDB].[dbo].REP_DETALLE_PRESTAMO RDP
				inner join [ERPSERVER].[TechCoreDB].[dbo].REP_PRESTAMOS RP on rp.emp_codigo=rdp.emp_codigo and rp.suc_codigo=rdp.suc_codigo and rp.pre_codigo=rdp.pre_codigo
				inner join  [ERPSERVER].[TechCoreDB].[dbo].rep_piezas rpie on rpie.emp_codigo=rdp.emp_codigo and rpie.pie_codigo=rdp.pie_codigo
				WHERE     
				rpie.pie_numero=@PROD_COD and
				--(RDP.pie_codigo = CAST(@pie_codigo AS int)) 
				--AND 
				(RDP.emp_codigo = 2) AND (RDP.suc_codigo = 21)   
				AND RDP.PRE_CODIGO = RP.PRE_CODIGO  
				--AND  (RP.pre_fecha BETWEEN @fechainicio AND getdate()) --dateadd(hour,23,@fechafin))   
				AND RDP.dpr_tipo_stock_origen like '%RC%'  

--
				UNION ALL  

				SELECT distinct
				null as PRODUCTO_ID,
				rp.pie_numero as NOMBREREFERENCIA,
				rp.pie_nombre as DESCRIPCION,
				convert(varchar,REP_DETALLE_VALES.dva_fecha) as FECHA_DOCUM,
				'' as FECHA_ENTREGA,
				'Vale Egreso Pieza' AS TRANSAC_DOCUM,
				cast(REP_DETALLE_VALES.val_codigo as varchar) AS TRANSAC_NUMDOC,
				0 AS TRANSAC_NUMITEM,
				'' AS DEP_NOMB,
				'' AS UBI_NOMB,
				0 as BULTOS,
				REP_DETALLE_VALES.dva_cantidad * -1 AS CANTIDAD,
				0 AS COSTO,
				0 AS TOTAL ,
				convert(datetime,REP_DETALLE_VALES.dva_fecha, 103) AS TRANSAC_FECHA,
				'' AS TRANSAC_ORIGINANTE,
				cli.denominacion AS TRANSAC_DESTINATARIO,
				cast(ord.odr_codigo as varchar) AS ORDENTRABAJO,
				cast(rec.rec_codigo as varchar) AS RECURSOGARANTIA,
				vd.vdo_nombre AS CANAL,
				veh.veh_nro_vin AS VIN

--				distinct 'VA' AS TIPO, 'Vale Egreso Pieza'  as DESCRIPCION, cast(TechCoreDB.dbo.REP_DETALLE_VALES.val_codigo as varchar) as NUMERODOCUMENTO,   
--				TechCoreDB.dbo.REP_DETALLE_VALES.dva_fecha as FECHADOCUMENTO, '' as ESTADOTR, '' as NOMBREORIGINANTETR, '' as NOMBREDESTINATARIOTR, '' as NOMBRETOTALTR,  
--				0 AS INGRESO, TechCoreDB.dbo.REP_DETALLE_VALES.dva_cantidad  AS EGRESO
  
				FROM  [ERPSERVER].[TechCoreDB].[dbo].REP_DETALLE_VALES INNER JOIN  [ERPSERVER].[TechCoreDB].[dbo].REP_DETALLE_VALES_REMITO   ON  REP_DETALLE_VALES.DVA_CODIGO = REP_DETALLE_VALES_REMITO.DVA_CODIGO 
				inner join [ERPSERVER].[TechCoreDB].[dbo].rep_piezas rp on rp.emp_codigo=REP_DETALLE_VALES.emp_codigo and rp.pie_codigo=REP_DETALLE_VALES.pie_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].tal_detalle_odr det on det.emp_codigo=REP_DETALLE_VALES.emp_codigo and det.deo_codigo=REP_DETALLE_VALES.deo_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].tal_ordenes_reparacion ord on ord.emp_codigo=det.emp_codigo and ord.odr_codigo=det.odr_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].gen_vehiculos veh on veh.emp_codigo=ord.emp_codigo and veh.veh_codigo=ord.veh_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].tal_recursos rec on rec.emp_codigo=ord.emp_codigo and rec.odr_codigo=ord.odr_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].cfg_valores_dominios vd on vd.emp_codigo=det.emp_codigo and vd.vdo_codigo=det.deo_observacion
				left join  erpserver.CalipsoProduccion.dbo.cliente cli with(nolock) on cli.codigo=ord.cli_codigo
				INNER JOIN  [ERPSERVER].[TechCoreDB].[dbo].REP_DETALLE_PRESTAMO   ON REP_DETALLE_VALES_REMITO.DETREM_CODIGO = REP_DETALLE_PRESTAMO.DRE_CODIGO_DESTINO 
							AND REP_DETALLE_PRESTAMO.DRE_CODIGO_DESTINO IN 
							(SELECT REP_DETALLE_REMITO_GARANTIA.DRE_CODIGO FROM [ERPSERVER].[TechCoreDB].[dbo].REP_DETALLE_REMITO_GARANTIA inner join [ERPSERVER].[TechCoreDB].[dbo].rep_piezas rp on rp.emp_codigo=REP_DETALLE_REMITO_GARANTIA.emp_codigo and rp.pie_codigo=REP_DETALLE_REMITO_GARANTIA.pie_codigo  INNER JOIN [ERPSERVER].[TechCoreDB].[dbo].REP_REMITOS_GARANTIA 
																		   ON REP_DETALLE_REMITO_GARANTIA.REM_CODIGO = REP_REMITOS_GARANTIA.REM_CODIGO 
																		   AND REP_REMITOS_GARANTIA.REM_NUMERO LIKE '%PRESTAMO%'
																		   where rp.pie_numero=@PROD_COD
																		   --and TechCoreDB.dbo.REP_DETALLE_REMITO_GARANTIA.PIE_CODIGO = '48'
																			)
																		   
				WHERE   
				--(TechCoreDB.dbo.REP_DETALLE_VALES.pie_codigo = cast('65' as int))
				rp.pie_numero=@PROD_COD
				AND 
				(REP_DETALLE_VALES.emp_codigo = 2)      
				AND (REP_DETALLE_VALES.suc_codigo = 21)      
				--aND (REP_DETALLE_VALES.dva_fecha BETWEEN @fechainicio AND getdate()) -- dateadd(hour,23,@fechafin))    
				AND (REP_DETALLE_VALES.val_codigo > 0)  
				and  REP_DETALLE_VALES.dva_codigo = REP_DETALLE_VALES_REMITO.dva_codigo  
				and  REP_DETALLE_VALES_REMITO.detrem_codigo = REP_DETALLE_PRESTAMO.dre_codigo_destino  
				and  REP_DETALLE_PRESTAMO.dpr_tipo_stock_destino like '%RG%'  
				 

				union all 



				SELECT DISTINCT 
				null as PRODUCTO_ID,
				rp.pie_numero as NOMBREREFERENCIA,
				rp.pie_nombre as DESCRIPCION,
				convert(varchar, REP_DETALLE_VALES.DVA_FECHA) as FECHA_DOCUM,
				'' as FECHA_ENTREGA,
				'Vale Egreso Pieza' AS TRANSAC_DOCUM,
				cast(REP_DETALLE_VALES.val_codigo as varchar) AS TRANSAC_NUMDOC,
				0 AS TRANSAC_NUMITEM,
				'' AS DEP_NOMB,
				'' AS UBI_NOMB,
				0 as BULTOS,
				SUM(REP_DETALLE_VALES.dva_cantidad) * -1 AS CANTIDAD,
				0 AS COSTO,
				0 AS TOTAL ,
				convert(datetime, REP_DETALLE_VALES.DVA_FECHA, 103) AS TRANSAC_FECHA,
				'' AS TRANSAC_ORIGINANTE,
				cli.denominacion AS TRANSAC_DESTINATARIO,
				cast(ord.odr_codigo as varchar) AS ORDENTRABAJO,
				cast(rec.rec_codigo as varchar) AS RECURSOGARANTIA,
				vd.vdo_nombre AS CANAL,
				veh.veh_nro_vin AS VIN

--				'VA' AS TIPO, 'Vale Egreso Pieza' AS DESCRIPCION, cast(TechCoreDB.dbo.REP_DETALLE_VALES.val_codigo as varchar) AS NUMERODOCUMENTO,
--				TechCoreDB.dbo.REP_DETALLE_VALES.DVA_FECHA AS FECHADOCUMENTO, '' AS ESTADOOTR, '' AS NOMBREORIGINANTETR, '' AS NOMBREDESTINATARIOTR, '' AS NOMBRETOTALTR, 
--				0 AS INGRESO, SUM(TechCoreDB.dbo.REP_DETALLE_VALES.dva_cantidad) AS EGRESO

				FROM [ERPSERVER].[TechCoreDB].[dbo].REP_DETALLE_VALES INNER JOIN [ERPSERVER].[TechCoreDB].[dbo].REP_DETALLE_VALES_REMITO ON REP_DETALLE_VALES.dva_codigo = REP_DETALLE_VALES_REMITO.dva_codigo AND
				REP_DETALLE_VALES_REMITO.EMP_CODIGO = REP_DETALLE_VALES.EMP_CODIGO AND REP_DETALLE_VALES_REMITO.SUC_CODIGO = REP_DETALLE_VALES.SUC_CODIGO

				INNER JOIN [ERPSERVER].[TechCoreDB].[dbo].REP_DETALLE_REMITO_GARANTIA ON REP_DETALLE_VALES_REMITO.DETREM_CODIGO = REP_DETALLE_REMITO_GARANTIA.DRE_CODIGO AND 
				REP_DETALLE_REMITO_GARANTIA.REM_CODIGO IN (SELECT REM_CODIGO FROM [ERPSERVER].[TechCoreDB].[dbo].REP_REMITOS_GARANTIA WHERE REM_NUMERO NOT LIKE '%PRESTAMO%') AND
				REP_DETALLE_REMITO_GARANTIA.EMP_CODIGO = REP_DETALLE_VALES_REMITO.EMP_CODIGO AND REP_DETALLE_REMITO_GARANTIA.SUC_CODIGO = REP_DETALLE_VALES_REMITO.SUC_CODIGO AND
				REP_DETALLE_REMITO_GARANTIA.PIE_CODIGO = REP_DETALLE_VALES.PIE_CODIGO
				inner join [ERPSERVER].[TechCoreDB].[dbo].rep_piezas rp on rp.emp_codigo=REP_DETALLE_VALES.emp_codigo and rp.pie_codigo=REP_DETALLE_VALES.pie_codigo
				inner JOIN [ERPSERVER].[TechCoreDB].[dbo].TAL_DETALLE_ODR ON REP_DETALLE_VALES.DEO_CODIGO = TAL_DETALLE_ODR.DEO_CODIGO AND TAL_DETALLE_ODR.CAR_CODIGO = 8
				
				inner join [ERPSERVER].[TechCoreDB].[dbo].tal_ordenes_reparacion ord on ord.emp_codigo=TAL_DETALLE_ODR.emp_codigo and ord.odr_codigo=TAL_DETALLE_ODR.odr_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].gen_vehiculos veh on veh.emp_codigo=ord.emp_codigo and veh.veh_codigo=ord.veh_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].tal_recursos rec on rec.emp_codigo=ord.emp_codigo and rec.odr_codigo=ord.odr_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].cfg_valores_dominios vd on vd.emp_codigo=TAL_DETALLE_ODR.emp_codigo and vd.vdo_codigo=TAL_DETALLE_ODR.deo_observacion
				left join  erpserver.CalipsoProduccion.dbo.cliente cli with(nolock) on cli.codigo=ord.cli_codigo

				WHERE 
				REP_DETALLE_VALES.EMP_CODIGO = 2 and
				--REP_DETALLE_VALES.SUC_CODIGO = 21 and
				rp.pie_numero=@PROD_COD and
				--REP_DETALLE_VALES.PIE_CODIGO = @pie_codigo and
				--(REP_DETALLE_VALES.dva_fecha BETWEEN @fechainicio and getdate()) and  --dateadd(hour,23,@fechafin)) AND
				REP_DETALLE_VALES.VAL_CODIGO > 0 --AND 
				--REP_DETALLE_REMITO_GARANTIA.PIE_CODIGO = @PIE_CODIGO
				GROUP BY 
				rp.pie_codigo,
				rp.pie_numero,
				rp.pie_nombre,
				REP_DETALLE_VALES.DVA_FECHA,
				cast(REP_DETALLE_VALES.val_codigo as varchar),
				--TechCoreDB.dbo.REP_DETALLE_VALES.DVA_FECHA,
				REP_DETALLE_VALES.DVA_FECHA,
				cli.denominacion,
				ord.odr_codigo,
				rec.rec_codigo,
				vd.vdo_nombre,
				veh.veh_nro_vin
				--TechCoreDB.dbo.REP_DETALLE_VALES.VAL_CODIGO,TechCoreDB.dbo.REP_DETALLE_VALES.DVA_FECHA

				--and tal_detalle_odr.car_codigo = 8

--
--					
				union all  
				  

				  
				  
				--REMITO GARANTIA PRESTAMO   
				SELECT 
				null as PRODUCTO_ID,
				rpie.pie_numero as NOMBREREFERENCIA,
				rpie.pie_nombre as DESCRIPCION,
				convert(varchar, RP.pre_fecha) as FECHA_DOCUM,
				'' as FECHA_ENTREGA,
				'Devolucion Prestamo Garantia' AS TRANSAC_DOCUM,
				CAST(RDP.pre_codigo AS varchar) AS TRANSAC_NUMDOC,
				0 AS TRANSAC_NUMITEM,
				'' AS DEP_NOMB,
				'' AS UBI_NOMB,
				0 as BULTOS,
				dpr_cantidad AS CANTIDAD,
				0 AS COSTO,
				0 AS TOTAL ,
				convert(datetime, RP.pre_fecha, 103) AS TRANSAC_FECHA,
				'' AS TRANSAC_ORIGINANTE,
				'' AS TRANSAC_DESTINATARIO,
				'' AS ORDENTRABAJO,
				'' AS RECURSOGARANTIA,
				'' AS CANAL,
				'' AS VIN

--				'DPG' AS TIPO, 'Devolucion Prestamo Garantia' AS DESCRIPCION, CAST(RDP.pre_codigo AS varchar) AS NUMERODOCUMENTO, RP.pre_fecha AS FECHADOCUMENTO,  
--				 '' AS ESTADOTR, '' AS NOMBREORIGINANTETR, '' AS NOMBREDESTINATARIOTR, '' AS NOMBRETOTALTR, 0 AS INGRESO, dpr_cantidad  AS EGRESO  
				FROM [ERPSERVER].[TechCoreDB].[dbo].REP_DETALLE_PRESTAMO AS RDP
				inner join [ERPSERVER].[TechCoreDB].[dbo].REP_PRESTAMOS RP on RDP.emp_codigo=RP.emp_codigo
				inner join [ERPSERVER].[TechCoreDB].[dbo].rep_piezas rpie on rpie.emp_codigo=RDP.emp_codigo and rpie.pie_codigo=RDP.pie_codigo
				WHERE     
				rpie.pie_numero=@PROD_COD AND 
				--(RDP.pie_codigo = CAST(@pie_codigo AS int)) 
				--AND
				(RDP.emp_codigo = 2) AND (RDP.suc_codigo = 21)   
				AND RDP.PRE_CODIGO = RP.PRE_CODIGO  
				--AND  (RP.pre_fecha BETWEEN @fechainicio AND getdate())--dateadd(hour,23,@fechafin))   
				AND RDP.dpr_tipo_stock_origen like '%RG%'  
				   
				--ORDER BY  FECHADOCUMENTO desc  
) AS KARDCAL
ORDER BY CAST(FECHA_DOCUM AS DATETIME) DESC, CAST(FECHA_ENTREGA AS DATETIME) DESC
