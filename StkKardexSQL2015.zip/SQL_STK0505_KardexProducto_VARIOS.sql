SELECT TOP 100 referenciatipo_id AS PRODUCTO_ID
					, INV.NOMBREREFERENCIA
					, INV.DESCRIPCION
					, SUBSTRING(INV.FECHADOCUMENTO,7,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,5,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,0,5) AS FECHA_DOCUM
					, INV.FECHAENTREGA
					, SUBSTRING(INV.FECHAENTREGA,7,2) + '/' + SUBSTRING(INV.FECHAENTREGA,5,2) + '/' + SUBSTRING(INV.FECHAENTREGA,0,5) AS FECHA_ENTREGA
					, INV.TIPOTRANSACCION_ID AS TRANSAC_ORIGID
					, TTR.CODIGO AS TRANSACTIPO_CODIGO
					, TTR.DESCRIPCION AS TRANSACTIPO_DESC
					, INV.NOMBRETR AS TRANSAC_DOCUM
					, INV.NUMERODOCUMENTO AS TRANSAC_NUMDOC
					, INV.NUMEROITEM AS TRANSAC_NUMITEM
					, ALIAS_1.NOMBRE AS DEPDES_NOMB
					, ALIAS_1.[UBICACIONES_ID] AS DEPDES_ID
					, ALIAS_2.NOMBRE AS UBIDES_NOMB
					, ALIAS_2.[ID] AS UBIDES_ID
					, INV.BULTOS
					, cantidad2_cantidad * -1 AS CANTIDAD
					, valor2_importe AS COSTO
					, cantidad2_cantidad * valor2_importe * -1 AS TOTAL 
					, SUBSTRING(INV.MOMENTOTR,7,2) + '/' + SUBSTRING(INV.MOMENTOTR,5,2) + '/' + SUBSTRING(INV.MOMENTOTR,0,5) AS TRANSAC_FECHA
					, INV.ORIGINANTETR_ID AS TRANSAC_ORIGID
					, INV.NOMBREORIGINANTETR AS TRANSAC_ORIGINANTE
					, INV.DESTINATARIOTR_ID AS TRANSAC_DESTID
					, INV.NOMBREDESTINATARIOTR AS TRANSAC_DESTINATARIO
					, INV.CENTROCOSTOS_ID AS CTROCTOSID
					, INV.COMPANIA_ID AS CIAID
					, INV.UNIDADOPERATIVA_ID AS UNIDOPERTID
					, INV.BO_PLACE_ID AS BOPLACEID
					, INV.BOEXTENSION_ID
					, UIEP.[CodigoItemOT]
					, UIEP.[DEPOSITO]
					, UIEP.[ValorventaInterna]
					, UIEP.[ENT CANAL]
					, UIEP.[ENT CARGO]
					, UIEP.[CantidadDevuelta]
					, CC.CODIGO AS [CC_COD]
					, CC.CODIGO + ' - ' + CC.NOMBRE AS [CC_CTOS]
					, EI.[EI_TipTaller]
					, EI.[VH_Interno]
					, EI.[VH_Marca]
					, EI.[VH_Modelo]
					, EI.[VH_Submodelo]
					, EI.[VH_Dominio]
					, EI.[VH_VIN]
					, EI.[VH_Chasis]
					, EI.[VH_NumMotor]
					, EI.[VH_Color]
					, EI.[VH_NumSerie]
					, EI.[VH_AnioRodado]
					, EI.[VH_TIPO]
					, EI.[VH_FechInsc]
					, EI.[VAL_EMPLEADO]
					, EI.[CLI_CODIGO]
					, EI.[CLI_DENOMINACION]
					, EI.[OT_ESTADO]
					, EI.[OT_CLIENTE]
					, EI.[OT_RECEPTOR]
					, EI.[OT_USUARIO]
					, EI.[OT_NUM]
					, EI.[OT_DETALLE]
					, EI.[OT_VEHICULO]
					, EI.[OT_FECULTEST]
				FROM [CalipsoReplicado].[dbo].[itemegresoinventario] AS INV		-- VEP y DeRep
 					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_DEPOSITO_] ALIAS_1 ON 
						-- DEPOSITO
						INV.[DEPOSITOORI_ID] = ALIAS_1.ID   
					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_UBICACION_] ALIAS_2 ON 
						-- UBICACION
						INV.[UBICACIONORI_ID] = ALIAS_2.ID 
					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[TIPOTRANSACCION] AS TTR WITH(NOLOCK) ON
						-- TIPOS TRANSACCION
						INV.TIPOTRANSACCION_ID = TTR.[ID]
					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[CENTROCOSTOS] AS CC WITH(NOLOCK) ON
						-- CENTRO DE COSTOS
						INV.CENTROCOSTOS_ID = CC.[ID]
					LEFT OUTER JOIN (SELECT IEP.[ID], IEP.[BO_OWNER_ID] AS [ItemEgrInvID], IEP.[CodigoItemOT], IEP.[CantidadDevuelta], DEP.NOMBRE AS [DEPOSITO], IEP.[ValorventaInterna], ITC01.[CODIGO] + ' - ' + ITC01.[NOMBRE] AS [ENT CANAL], ITC02.[CODIGO] + ' - ' + ITC02.[NOMBRE] AS [ENT CARGO]
										FROM [CalipsoReplicado].[dbo].[UD_ItemEntregaPiezas] AS IEP WITH(NOLOCK)
											LEFT OUTER JOIN [CalipsoReplicado].[dbo].[Deposito] AS DEP WITH(NOLOCK) ON
												IEP.[Entregado_ID] = DEP.[ID]
											LEFT OUTER JOIN [CalipsoReplicado].[dbo].[ItemTipoClasificador] AS ITC01 WITH(NOLOCK) ON
												IEP.[Canal_ID] = ITC01.[ID]
											LEFT OUTER JOIN [CalipsoReplicado].[dbo].[ItemTipoClasificador] AS ITC02 WITH(NOLOCK) ON
												IEP.[Cargo_ID] = ITC02.[ID]
									 ) AS UIEP ON
						-- DETALLE DE LOS ITEMS DEL VALE
										INV.[BOEXTENSION_ID] = UIEP.[ID]	--[ItemEgrInvID]
					LEFT OUTER JOIN (SELECT TRO.[ID]												, TTR.CODIGO AS [EI_TRTIPOCOD]												, TTR.[DESCRIPCIONCORTA] + ' - ' + TTR.[DESCRIPCION] AS [EI_TRTIPO]												, TRO.[NOMBRE] AS [EI_DOCCOMP]												, TRO.[NUMERODOCUMENTO] AS [EI_DOCNUM]												, TRO.[ESTADO] AS [EI_EST]												, TRO.[NOMBREDESTINATARIO] AS [EI_NOMBDEST]												, TRO.[NOMBREORIGINANTE] AS [EI_DEPORIGEN]												, TRO.[USUARIO] AS [EI_USUARIO]												, SUBSTRING(TRO.[FECHAULTIMOESTADO],7,2) + '/' + SUBSTRING(TRO.[FECHAULTIMOESTADO],5,2) + '/' + SUBSTRING(TRO.[FECHAULTIMOESTADO],0,5) AS [EI_FECHA]												, TRO.[VALORTOTAL] AS [EI_VALTOTAL]												, UOI.[CODIGO] + ' - ' + UOI.[NOMBRE] AS [EI_DEPOSIT]												, VAD.*									  FROM [CalipsoReplicado].[dbo].[TREgresoInventario] AS TRO WITH(NOLOCK)											LEFT OUTER JOIN [CalipsoReplicado].[dbo].[TipoTransaccion] AS TTR WITH(NOLOCK) ON												TRO.[TIPOTRANSACCION_ID] = TTR.[ID]											LEFT OUTER JOIN [CalipsoReplicado].[dbo].[UOInventario] AS UOI WITH(NOLOCK) ON												TRO.[UNIDADOPERATIVA_ID] = UOI.[ID]											LEFT OUTER JOIN (															 SELECT UDVEP.[ID] AS [EI_ID]																	, TTal.[CODIGO] + ' - ' + TTal.[NOMBRE] AS [EI_TipTaller]																	, PRD.[CODIGO] AS [VH_Interno]																	, PDUD.[Marca] AS [VH_Marca]																	, PDUD.[Modelo] AS [VH_Modelo]																	, PDUD.[Submodelo] AS [VH_Submodelo]																	, PDUD.[Dominio] AS [VH_Dominio]																	, PDUD.[NumeroVIN] AS [VH_VIN]																	, PDUD.[NumeroChasis] AS [VH_Chasis]																	, PDUD.[NumeroMotor] AS [VH_NumMotor]																	, PDUD.[Color] AS [VH_Color]																	, PDUD.[Serie] AS [VH_NumSerie]																	, PDUD.[AnioRodado] AS [VH_AnioRodado]																	, PDUD.[TipoVehiculo] AS [VH_TIPO]																	, PDUD.[FechaInscripcion] AS [VH_FechInsc]																	, EMP.[DESCRIPCION] AS [VAL_EMPLEADO]																	, CLI.[CODIGO] AS [CLI_CODIGO]																	, CLI.[DENOMINACION] AS [CLI_DENOMINACION]																	, OT.ESTADO AS [OT_ESTADO]																	, OT.NOMBREDESTINATARIO AS [OT_CLIENTE]																	, OT.NOMBREORIGINANTE AS [OT_RECEPTOR]																	, OT.USUARIO AS [OT_USUARIO]																	, OT.NUMERODOCUMENTO AS [OT_NUM]																	, OT.NOMBRE AS [OT_DETALLE]																	, OT.DETALLE AS [OT_VEHICULO]																	, SUBSTRING(OT.FECHAULTIMOESTADO,7,2) + '/' + SUBSTRING(OT.FECHAULTIMOESTADO,5,2) + '/' + SUBSTRING(OT.FECHAULTIMOESTADO,0,5) AS [OT_FECULTEST]															FROM [CalipsoReplicado].[dbo].[UD_ValeEntregaPiezas] AS UDVEP WITH(NOLOCK)																LEFT OUTER JOIN [CalipsoReplicado].[dbo].[Producto] AS PRD WITH(NOLOCK) ON																	-- Vincula el Vale con el Veh�culo																	UDVEP.[Vehiculo_ID] = PRD.[ID]																LEFT OUTER JOIN [CalipsoReplicado].[dbo].[UD_Producto] AS PDUD WITH(NOLOCK) ON																	-- Vincula el Veh�culo general con el Detalle																	PRD.[BOEXTENSION_ID] = PDUD.[ID]																LEFT OUTER JOIN [CalipsoReplicado].[dbo].[ItemTipoClasificador] AS TTal WITH(NOLOCK) ON																	UDVEP.[TipoTaller_ID] = TTal.[ID]																LEFT OUTER JOIN [CalipsoReplicado].[dbo].[Empleado] AS EMP WITH(NOLOCK) ON																	UDVEP.[Mecanico_ID] = EMP.[ID]																LEFT OUTER JOIN [CalipsoReplicado].[dbo].[Cliente] AS CLI WITH(NOLOCK) ON																	UDVEP.[ClienteFacturar_ID] = CLI.[ID]																LEFT OUTER JOIN [CalipsoReplicado].[dbo].[TROrdenVenta] AS OT WITH(NOLOCK) ON																	UDVEP.[OrdenTrabajo_ID] = OT.[ID]									--										WHERE UDVEP.ID = 'C909543F-E092-4D15-8B2E-1E8261F879A1'															 ) AS VAD ON												TRO.[BOEXTENSION_ID] = VAD.[EI_ID]--									WHERE TRO.[NUMERODOCUMENTO] = '37930'									 ) AS EI ON
							INV.[PLACEOWNER_ID] = EI.[ID]
--							TRO.[ID] = INV.[PLACEOWNER_ID]
--							INV.[BOEXTENSION_ID] = EI.[ID]
				WHERE (CAST(ALIAS_1.[UBICACIONES_ID] AS NVARCHAR(36)) = 'B9EF3D86-DCFA-46EC-BB41-59BFCF94662B' -- Deposito Comercial Cordoba
							OR CAST(ALIAS_1.[UBICACIONES_ID] AS NVARCHAR(36)) = 'FB512A71-3225-4140-B3FE-A1893C95630B' -- Deposito Garantia Cordoba
							OR CAST(ALIAS_1.[UBICACIONES_ID] AS NVARCHAR(36)) = 'C02692AE-BA47-4C3F-9639-85DD0396D152' -- Deposito Separacion Cordoba
							OR CAST(ALIAS_1.[UBICACIONES_ID] AS NVARCHAR(36)) = '5618407C-FC0A-4CDB-A810-19D303903121' -- Deposito Comercial RM Cordoba
							OR CAST(ALIAS_1.[UBICACIONES_ID] AS NVARCHAR(36)) = 'A3BC9E4E-BC62-4A9C-8AE0-D6FEA2CAD28C' -- Deposito Rep.Reservados Cordoba
							OR CAST(ALIAS_1.[UBICACIONES_ID] AS NVARCHAR(36)) = 'FB342E92-696E-4DBA-8B9D-2C69855A314E' -- Deposito Repuestos Reemplazados Cordoba
						)
						AND [ESTADOTR] = 'C' 
--						AND INV.NOMBRETR = 'VEP Nro.  63965 - Fecha 28-01-2015'
						AND INV.NOMBREREFERENCIA = '208251239R I'

VEP Nro.  37930 - Fecha 10-04-2014
--
--DEPOSITOORI_ID
--UBICACIONORI_ID
--
--
--TABLA = DatoComplementario
--
--DATOSCOMPLEMENTARIOS_ID
--
--1DD2FA3E-375D-4B3F-967B-65DC547F4DA5
--
--
--PLACEOWNER_ID
--111472B6-E509-4942-AEFD-764FE5276031
--
--
--
--[CalipsoReplicado].[dbo].[itemegresoinventario] AS INV
--BOEXTENSION_ID
--	UD_ItemEntregaPiezas
--	3B7C3D15-315C-49B4-B609-D7D0B9A146D6
--
---- ########################################################################################################################################
---- DETALLE DE LOS ItemsEntregaPiezas - 
--SELECT TOP 100 IEP.[ID], IEP.[BO_OWNER_ID] AS [ItemEgrInvID], IEP.[CodigoItemOT], IEP.[CantidadDevuelta], DEP.NOMBRE AS [DEPOSITO], IEP.[ValorventaInterna], ITC01.[CODIGO] + ' - ' + ITC01.[NOMBRE] AS [ENT CANAL], ITC02.[CODIGO] + ' - ' + ITC02.[NOMBRE] AS [ENT CARGO]
--FROM [CalipsoReplicado].[dbo].[UD_ItemEntregaPiezas] AS IEP WITH(NOLOCK)
--	LEFT OUTER JOIN [CalipsoReplicado].[dbo].[Deposito] AS DEP WITH(NOLOCK) ON
--		IEP.[Entregado_ID] = DEP.[ID]
--	LEFT OUTER JOIN [CalipsoReplicado].[dbo].[ItemTipoClasificador] AS ITC01 WITH(NOLOCK) ON
--		IEP.[Canal_ID] = ITC01.[ID]
--	LEFT OUTER JOIN [CalipsoReplicado].[dbo].[ItemTipoClasificador] AS ITC02 WITH(NOLOCK) ON
--		IEP.[Cargo_ID] = ITC02.[ID]
--WHERE IEP.[ID] = '3B7C3D15-315C-49B4-B609-D7D0B9A146D6'
--	OR IEP.[ID] = '34A99BD2-E0D9-447A-8653-556EAB71F42E'
--
--		-- SOLO TABLA [UD_ItemEntregaPiezas]
--		SELECT TOP 100 *
--		FROM [CalipsoReplicado].[dbo].[UD_ItemEntregaPiezas] AS IEP WITH(NOLOCK)
--		WHERE [Entregado_ID] IS NOT NULL
--
--		-- SOLO TABLA [ItemTipoClasificador]
--		SELECT TOP 100 *
--		FROM [CalipsoReplicado].[dbo].[ItemTipoClasificador] AS ITC01 WITH(NOLOCK)
--		WHERE [ID] = 'D1F41FC1-857F-483E-8E64-934319C0CCE0'
--
--		-- SOLO TABLA [Deposito]
--		SELECT TOP 100 *
--		FROM [CalipsoReplicado].[dbo].[Deposito] AS DEP WITH(NOLOCK)
--		WHERE [ID] = '0F1F80E4-0B4D-4AC7-A733-EE3FAEEF0417'
--
--
