---- ########################################################################################################################################
---- INICIO -- DETALLE DE DEPOSITOS
---- ########################################################################################################################################
--	-- DEPOSITOS, DETALLE DE LOS DEPOSITOS DISPONIBLES
--	SELECT  TOP 100 ALIAS_0.ID ALIAS_0_ID
--		, ALIAS_0.NOMBRE ALIAS_0_NOMBRE
--		, ALIAS_1.NOMBRE ALIAS_1_NOMBRE
--		, ALIAS_0.BOEXTENSION_ID ALIAS_0_BOEXTENSION_ID 
--		, ALIAS_0.ACTIVESTATUS ALIAS_0_ACTIVESTATUS
--	FROM [CalipsoReplicado].[dbo].[V_DEPOSITO_] ALIAS_0  
--		LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_DATOCOMPLEMENTARIO_] ALIAS_2 ON 
--			ALIAS_0.DATOSCOMPLEMENTARIOS_ID = ALIAS_2.ID   
--		LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_FICHADATOSCOMPLEMENTARIOS_] ALIAS_1 ON 
--			ALIAS_2.FICHADATOSCOMPLEMENTARIOS_ID = ALIAS_1.ID  
--	WHERE ALIAS_0.BO_PLACE_ID = '{0324AF99-7929-4E9D-B1C9-26447EF4DE5C}'	-- TAGLE 
--		AND  ALIAS_0.ACTIVESTATUS <> 2  AND  ALIAS_0.ACTIVESTATUS <> 1  
--		AND   (ALIAS_0.UNIDADOPERATIVA_ID = '{B1AC037C-4C42-4D20-8821-F135777A5F44}'  OR   ALIAS_0.UNIDADOPERATIVA_ID IS NULL) 
--
--
--	-- DEPOSITOS CORDOBA, CODIGOS ID
--	--	003B2413-F530-4653-9044-4AF3DBE5AE3A	Deposito Comercial Cordoba
--	--	ED3A83B7-7054-4CCE-8A69-4ABAC741B52E	Deposito Garantia Cordoba
--	--	2C4B035F-41D4-468C-853D-B32CD96F8AA2	Deposito Rep.Reservados Cordoba
--	--	C4CA2299-700C-447F-AD5B-CD666D503EA6	Deposito Separacion Cordoba
--	--	ED3A83B7-7054-4CCE-8A69-4ABAC741B52E	Deposito Garantia Cordoba
--
--
--
--	-- UBICACIONES
--	-- DEP�SITOS
--	-- DEP�SITO COMERCIAL CORDOBA
--	SELECT ALIAS_3.UBICACIONES_ID AS DEP_ID
--		, ALIAS_3.NOMBRE AS DEP_NOMBRE
--		, ALIAS_0.ID AS UBIC_ID
--		, ALIAS_0.NOMBRE AS UBIC_NOMB
--		, ALIAS_0.ACTIVESTATUS AS UBIC_ESTADO
--	--	, ALIAS_0.*
--		FROM [CalipsoReplicado].[dbo].[V_UBICACION_] ALIAS_0  
--			LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_TIPOUBICACION_] ALIAS_1 ON 
--				ALIAS_0.TIPOUBICACION_ID = ALIAS_1.ID   
--			LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_DEPOSITO_] ALIAS_3 ON 
--				ALIAS_0.[BO_PLACE_ID] = ALIAS_3.[UBICACIONES_ID]  
--	WHERE ALIAS_3.NOMBRE LIKE '%Cordoba%'
--	ORDER BY ALIAS_3.NOMBRE
--		, ALIAS_0.NOMBRE

-- ########################################################################################################################################
-- INICIO -- KARDEX TAGLE
-- ########################################################################################################################################

-- PIEZAS
DECLARE @PROD_ID AS NVARCHAR(50)
DECLARE @PROD_COD AS NVARCHAR(20)

SET @PROD_ID = ''	-- {F41F419A-DC57-4FDA-966A-8287533853E1}
SET @PROD_COD = '8200650085 I'		--7700274177 I	0225244664 alfombras

--DECLARE @DEP_ID1 AS NVARCHAR(50)	-- Deposito Comercial Cordoba RENAULT
----DECLARE @UBI_ID1 AS NVARCHAR(50)
----DECLARE @UBI_ID2 AS NVARCHAR(50)
----DECLARE @UBI_ID3 AS NVARCHAR(50)
----DECLARE @UBI_ID4 AS NVARCHAR(50)
----DECLARE @UBI_ID5 AS NVARCHAR(50)
--
--DECLARE @DEP_ID2 AS NVARCHAR(50)	-- Deposito Comercial Cordoba NIX
----DECLARE @UBI_ID21 AS NVARCHAR(50)
--
--DECLARE @DEP_ID3 AS NVARCHAR(50)	-- Deposito Comercial Rio IV RENAULT
----DECLARE @UBI_ID31 AS NVARCHAR(50)
----DECLARE @UBI_ID32 AS NVARCHAR(50)
--
--DECLARE @DEP_ID4 AS NVARCHAR(50)	-- Deposito Comercial Rio IV NIX
----DECLARE @UBI_ID41 AS NVARCHAR(50)
--
--DECLARE @DEP_ID5 AS NVARCHAR(50)	-- Deposito Comercial VILLA MARIA
----DECLARE @UBI_ID51 AS NVARCHAR(50)
----DECLARE @UBI_ID52 AS NVARCHAR(50)
--

--
---- DEPOSITOS
---- DEPOSITO COMERCIAL CORDOBA TAGLE
--SET @DEP_ID1 = 'B9EF3D86-DCFA-46EC-BB41-59BFCF94662B'	-- Deposito Comercial Cordoba RENAULT	B9EF3D86-DCFA-46EC-BB41-59BFCF94662B
----SET @UBI_ID1 = 'C98BE931-EDF9-40F5-9759-83B739337DF6'	-- UBICACI�N UNICA
----SET @UBI_ID2 = 'E151E5A9-E6B5-4A03-8920-BC5D265FCB6F'	-- UBICACI�N VITRINA
----SET @UBI_ID3 = '8E887877-FB05-419A-A36A-9FD168766876'	-- UBICACI�N ALISTAJE
----SET @UBI_ID4 = '6BB5878B-94B4-4322-A75A-0925C4988B7D'	-- UBICACI�N CHAPA Y PINTURA
----SET @UBI_ID5 = 'ABFE8F04-BDEA-452F-AFAE-0EBB584E40CF'	-- UBICACI�N SCRAP
--
---- DEPOSITO COMERCIAL CORDOBA NIX
--SET @DEP_ID2 = 'F69A0255-9A3C-4F2C-9707-8F3E5EA65B9F'		-- Deposito Comercial Cordoba NIX
----SET @UBI_ID21 = 'D48CCB2E-7C98-468D-B3E3-C4350EFF0369'	-- UBICACI�N UNICA
--
---- DEPOSITO COMERCIAL CORDOBA RIO IV TAGLE
--SET @DEP_ID3 = 'B07EF741-F1D3-4070-812C-D42367454231'		-- Deposito Comercial Rio IV RENAULT
----SET @UBI_ID31 = 'E4C4A7C2-44D3-4E76-8F4A-7D7AB6409B69'	-- UBICACI�N UNICA
----SET @UBI_ID32 = '8DBDA8F9-B120-48EB-AB77-2C72C7473A33'	-- UBICACI�N ALISTAJE
--
---- DEPOSITO COMERCIAL RIO IV NIX
--SET @DEP_ID4 = '17CA4150-8C23-40A8-B9A5-C47C5087F805'		-- Deposito Comercial Rio IV NIX
----SET @UBI_ID41 = '2384A556-85B9-4740-8C4E-5BDF8C87F957'	-- UBICACI�N UNICA
--
---- DEPOSITO COMERCIAL VILLA MAR�A
--SET @DEP_ID5 = '3B6F47B9-2090-4F54-8394-102BAB28C26A'		-- Deposito Comercial VILLA MARIA
----SET @UBI_ID51 = 'B4288D8F-6DE3-46C9-86C6-4339501FF50D'	-- UBICACI�N UNICA
----SET @UBI_ID52 = '55932E5C-B488-4597-933F-D5E8DDEC4082'	-- UBICACI�N ALISTAJE

DECLARE @DEP_ID1 AS NVARCHAR(50)	-- Deposito Comercial Cordoba RENAULT
DECLARE @UBI_ID1 AS NVARCHAR(50)
DECLARE @DEP_ID2 AS NVARCHAR(50)	-- Deposito Garantia Cordoba
DECLARE @UBI_ID2 AS NVARCHAR(50)
DECLARE @DEP_ID3 AS NVARCHAR(50)	-- Deposito Garantia Cordoba
DECLARE @UBI_ID3 AS NVARCHAR(50)

SET @DEP_ID1 = 'B9EF3D86-DCFA-46EC-BB41-59BFCF94662B'	-- Deposito Comercial Cordoba
SET @UBI_ID1 = 'B8753321-5C5E-4A64-BEBC-A91204FA63F1'	-- UBICACI�N UNICA

SET @DEP_ID2 = 'FB512A71-3225-4140-B3FE-A1893C95630B'	-- Deposito Garantia Cordoba
SET @UBI_ID2 = '5D2C47C5-FFA4-4010-8F3E-E369C90DBE87'	-- UBICACI�N UNICA

SET @DEP_ID3 = 'C02692AE-BA47-4C3F-9639-85DD0396D152'	-- Deposito Garantia Cordoba
SET @UBI_ID3 = '138A01B4-6F83-48C1-AE79-A80A8FA2025F'	-- UBICACI�N UNICA


SELECT CIAID
	, UNIDOPERTID
	, BOPLACEID
	, BOEXTENSION_ID
	, CTROCTOSID
	, PRODUCTO_ID
	, NOMBREREFERENCIA
	, DESCRIPCION
	, FECHA_DOCUM
	, FECHA_ENTREGA
	, FECHAENTREGA
	, TRANSAC_TIPOID
	, TRANSACTIPO_CODIGO
	, TRANSACTIPO_DESC
	, TRANSAC_DOCUM
	, TRANSAC_NUMDOC
--	, TRANSAC_NUMITEM
	, DEPDES_NOMB
	, DEPDES_ID
	, UBIDES_NOMB
	, UBIDES_ID
--	, DEP_NOMB + '/' + UBI_NOMB AS DEPOSITO
	, TRANSAC_ORIGID
	, TRANSAC_ORIGINANTE
	, TRANSAC_DESTID
	, TRANSAC_DESTINATARIO AS DESTINATARIO
	, CANTIDAD
	, COSTO
	, TOTAL 
FROM (
		SELECT TOP 10000 referenciatipo_id AS PRODUCTO_ID
					, INV.NOMBREREFERENCIA
					, INV.DESCRIPCION
--					, INV.FECHADOCUMENTO
					, SUBSTRING(INV.FECHADOCUMENTO,7,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,5,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,0,5) AS FECHA_DOCUM
	----				, INV.FECHAINV
	--				, SUBSTRING(INV.FECHAINV,7,2) + '/' + SUBSTRING(INV.FECHAINV,5,2) + '/' + SUBSTRING(INV.FECHAINV,0,5) AS FECHA_INV
	----				, INV.FECHAVEN
	--				, SUBSTRING(INV.FECHAVEN,7,2) + '/' + SUBSTRING(INV.FECHAVEN,5,2) + '/' + SUBSTRING(INV.FECHAVEN,0,5) AS FECHA_VTO
					, INV.FECHAENTREGA
					, SUBSTRING(INV.FECHAENTREGA,7,2) + '/' + SUBSTRING(INV.FECHAENTREGA,5,2) + '/' + SUBSTRING(INV.FECHAENTREGA,0,5) AS FECHA_ENTREGA
					, INV.TIPOTRANSACCION_ID AS TRANSAC_TIPOID
					, TTR.CODIGO AS TRANSACTIPO_CODIGO
					, TTR.DESCRIPCION AS TRANSACTIPO_DESC
					, INV.NOMBRETR AS TRANSAC_DOCUM
					, INV.NUMERODOCUMENTO AS TRANSAC_NUMDOC
					, INV.NUMEROITEM AS TRANSAC_NUMITEM
					, ALIAS_1.NOMBRE AS DEPDES_NOMB
					, ALIAS_1.[UBICACIONES_ID] AS DEPDES_ID
					, ALIAS_2.NOMBRE AS UBIDES_NOMB
					, ALIAS_2.[ID] AS UBIDES_ID
	--				, INV.[ESTADOTR] AS TRANSAC_ESTA
					, INV.BULTOS
					, cantidad2_cantidad AS CANTIDAD
					, valor2_importe AS COSTO
					, cantidad2_cantidad * valor2_importe AS TOTAL 
	--				, INV.MOMENTOTR
					, SUBSTRING(INV.MOMENTOTR,7,2) + '/' + SUBSTRING(INV.MOMENTOTR,5,2) + '/' + SUBSTRING(INV.MOMENTOTR,0,5) AS TRANSAC_FECHA
					, INV.ORIGINANTETR_ID AS TRANSAC_ORIGID
					, INV.NOMBREORIGINANTETR AS TRANSAC_ORIGINANTE
					, INV.DESTINATARIOTR_ID AS TRANSAC_DESTID
					, INV.NOMBREDESTINATARIOTR AS TRANSAC_DESTINATARIO
					, INV.CENTROCOSTOS_ID AS CTROCTOSID
					, INV.COMPANIA_ID AS CIAID
					, INV.UNIDADOPERATIVA_ID AS UNIDOPERTID
					, INV.BO_PLACE_ID AS BOPLACEID
					, INV.BOEXTENSION_ID
	--				, INV.*
			  FROM [CalipsoReplicado].[dbo].[itemingresoinventario] AS INV
				LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_DEPOSITO_] ALIAS_1 ON 
					INV.[DEPOSITODES_ID] = ALIAS_1.ID   
				LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_UBICACION_] ALIAS_2 ON 
					INV.[UBICACIONDES_ID] = ALIAS_2.ID 
				LEFT OUTER JOIN [CalipsoReplicado].[dbo].[TIPOTRANSACCION] AS TTR WITH(NOLOCK) ON
					INV.TIPOTRANSACCION_ID = TTR.[ID]
			  WHERE 
--					(ALIAS_1.[UBICACIONES_ID] = @DEP_ID1 OR ALIAS_1.[UBICACIONES_ID] = @DEP_ID2 OR ALIAS_1.[UBICACIONES_ID] = @DEP_ID3 OR ALIAS_1.[UBICACIONES_ID] = @DEP_ID4 OR ALIAS_1.[UBICACIONES_ID] = @DEP_ID5)
--						((ALIAS_1.[UBICACIONES_ID] = @DEP_ID1 AND (ALIAS_2.[ITEMSINVENTARIO_ID] = @UBI_ID1 OR ALIAS_2.[ITEMSINVENTARIO_ID] = @UBI_ID2 OR ALIAS_2.[ITEMSINVENTARIO_ID] = @UBI_ID3 OR ALIAS_2.[ITEMSINVENTARIO_ID] = @UBI_ID4 OR ALIAS_2.[ITEMSINVENTARIO_ID] = @UBI_ID5))
--						 OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID2 AND ALIAS_2.[ITEMSINVENTARIO_ID] = @UBI_ID21)
--						 OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID3 AND (ALIAS_2.[ITEMSINVENTARIO_ID] = @UBI_ID31 OR ALIAS_2.[ITEMSINVENTARIO_ID] = @UBI_ID32))
--						 OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID4 AND ALIAS_2.[ITEMSINVENTARIO_ID] = @UBI_ID41)
--						 OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID5 AND (ALIAS_2.[ITEMSINVENTARIO_ID] = @UBI_ID51 OR ALIAS_2.[ITEMSINVENTARIO_ID] = @UBI_ID52))
--						)
						((ALIAS_1.[UBICACIONES_ID] = @DEP_ID1 AND ALIAS_2.[ID] = @UBI_ID1) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID2 AND ALIAS_2.[ID] = @UBI_ID2) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID3 AND ALIAS_2.[ID] = @UBI_ID3))
						AND [ESTADOTR] = 'C' 
						AND (CAST([REFERENCIATIPO_ID] AS NVARCHAR(50)) = @PROD_ID OR INV.NOMBREREFERENCIA = @PROD_COD)
		UNION ALL
		SELECT TOP 10000 referenciatipo_id AS PRODUCTO_ID
					, INV.NOMBREREFERENCIA
					, INV.DESCRIPCION
--					, INV.FECHADOCUMENTO
					, SUBSTRING(INV.FECHADOCUMENTO,7,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,5,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,0,5) AS FECHA_DOCUM
	----				, INV.FECHAINV
	--				, SUBSTRING(INV.FECHAINV,7,2) + '/' + SUBSTRING(INV.FECHAINV,5,2) + '/' + SUBSTRING(INV.FECHAINV,0,5) AS FECHA_INV
	----				, INV.FECHAVEN
	--				, SUBSTRING(INV.FECHAVEN,7,2) + '/' + SUBSTRING(INV.FECHAVEN,5,2) + '/' + SUBSTRING(INV.FECHAVEN,0,5) AS FECHA_VTO
					, INV.FECHAENTREGA
					, SUBSTRING(INV.FECHAENTREGA,7,2) + '/' + SUBSTRING(INV.FECHAENTREGA,5,2) + '/' + SUBSTRING(INV.FECHAENTREGA,0,5) AS FECHA_ENTREGA
					, INV.TIPOTRANSACCION_ID AS TRANSAC_ORIGID
					, TTR.CODIGO AS TRANSACTIPO_CODIGO
					, TTR.DESCRIPCION AS TRANSACTIPO_DESC
					, INV.NOMBRETR AS TRANSAC_DOCUM
					, INV.NUMERODOCUMENTO AS TRANSAC_NUMDOC
					, INV.NUMEROITEM AS TRANSAC_NUMITEM
					, ALIAS_1.NOMBRE AS DEPDES_NOMB
					, ALIAS_1.[UBICACIONES_ID] AS DEPDES_ID
					, ALIAS_2.NOMBRE AS UBIDES_NOMB
					, ALIAS_2.[ID] AS UBIDES_ID
	--				, INV.[ESTADOTR] AS TRANSAC_ESTA
					, INV.BULTOS
					, cantidad2_cantidad * -1 AS CANTIDAD
					, valor2_importe AS COSTO
					, cantidad2_cantidad * valor2_importe * -1 AS TOTAL 
	--				, INV.MOMENTOTR
					, SUBSTRING(INV.MOMENTOTR,7,2) + '/' + SUBSTRING(INV.MOMENTOTR,5,2) + '/' + SUBSTRING(INV.MOMENTOTR,0,5) AS TRANSAC_FECHA
					, INV.ORIGINANTETR_ID
					, INV.NOMBREORIGINANTETR AS TRANSAC_ORIGINANTE
					, INV.DESTINATARIOTR_ID AS TRANSAC_DESTID
					, INV.NOMBREDESTINATARIOTR AS TRANSAC_DESTINATARIO
					, INV.CENTROCOSTOS_ID
					, INV.COMPANIA_ID
					, INV.UNIDADOPERATIVA_ID
					, INV.BO_PLACE_ID
					, INV.BOEXTENSION_ID
	--				, INV.*
				FROM [CalipsoReplicado].[dbo].[itemegresoinventario] AS INV
 					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_DEPOSITO_] ALIAS_1 ON 
						INV.[DEPOSITOORI_ID] = ALIAS_1.ID   
					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_UBICACION_] ALIAS_2 ON 
						INV.[UBICACIONORI_ID] = ALIAS_2.ID 
					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[TIPOTRANSACCION] AS TTR WITH(NOLOCK) ON
							INV.TIPOTRANSACCION_ID = TTR.[ID]
				WHERE ((ALIAS_1.[UBICACIONES_ID] = @DEP_ID1 AND ALIAS_2.[ID] = @UBI_ID1) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID2 AND ALIAS_2.[ID] = @UBI_ID2) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID3 AND ALIAS_2.[ID] = @UBI_ID3))
						AND [ESTADOTR] = 'C' 
						AND (CAST([REFERENCIATIPO_ID] AS NVARCHAR(50)) = @PROD_ID OR INV.NOMBREREFERENCIA LIKE @PROD_COD)
		UNION ALL
		SELECT TOP 10000 referenciatipo_id AS PRODUCTO_ID
					, INV.NOMBREREFERENCIA
					, INV.DESCRIPCION
--					, INV.FECHADOCUMENTO
					, SUBSTRING(INV.FECHADOCUMENTO,7,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,5,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,0,5) AS FECHA_DOCUM
	----				, INV.FECHAINV
	--				, SUBSTRING(INV.FECHAINV,7,2) + '/' + SUBSTRING(INV.FECHAINV,5,2) + '/' + SUBSTRING(INV.FECHAINV,0,5) AS FECHA_INV
	----				, INV.FECHAVEN
	--				, SUBSTRING(INV.FECHAVEN,7,2) + '/' + SUBSTRING(INV.FECHAVEN,5,2) + '/' + SUBSTRING(INV.FECHAVEN,0,5) AS FECHA_VTO
					, INV.FECHAENTREGA
					, SUBSTRING(INV.FECHAENTREGA,7,2) + '/' + SUBSTRING(INV.FECHAENTREGA,5,2) + '/' + SUBSTRING(INV.FECHAENTREGA,0,5) AS FECHA_ENTREGA
					, INV.TIPOTRANSACCION_ID AS TRANSAC_ORIGID
					, TTR.CODIGO AS TRANSACTIPO_CODIGO
					, TTR.DESCRIPCION AS TRANSACTIPO_DESC
					, INV.NOMBRETR AS TRANSAC_DOCUM
					, INV.NUMERODOCUMENTO AS TRANSAC_NUMDOC
					, INV.NUMEROITEM AS TRANSAC_NUMITEM
					, ALIAS_1.NOMBRE AS DEPDES_NOMB
					, ALIAS_1.[UBICACIONES_ID] AS DEPDES_ID
					, ALIAS_2.NOMBRE AS UBIDES_NOMB
					, ALIAS_2.[ID] AS UBIDES_ID
	--				, INV.[ESTADOTR] AS TRANSAC_ESTA
					, INV.BULTOS
					, cantidad2_cantidad AS CANTIDAD
					, valor2_importe AS COSTO
					, cantidad2_cantidad * valor2_importe AS TOTAL
	--				, INV.MOMENTOTR
					, SUBSTRING(INV.MOMENTOTR,7,2) + '/' + SUBSTRING(INV.MOMENTOTR,5,2) + '/' + SUBSTRING(INV.MOMENTOTR,0,5) AS TRANSAC_FECHA
					, INV.ORIGINANTETR_ID
					, INV.NOMBREORIGINANTETR AS TRANSAC_ORIGINANTE
					, INV.DESTINATARIOTR_ID AS TRANSAC_DESTID
					, INV.NOMBREDESTINATARIOTR AS TRANSAC_DESTINATARIO
					, INV.CENTROCOSTOS_ID
					, INV.COMPANIA_ID
					, INV.UNIDADOPERATIVA_ID
					, INV.BO_PLACE_ID
					, INV.BOEXTENSION_ID
	--				, INV.*
				FROM [CalipsoReplicado].[dbo].[itemtransferenciainventario] AS INV
 					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_DEPOSITO_] ALIAS_1 ON 
						INV.[DEPOSITODES_ID] = ALIAS_1.ID   
					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_UBICACION_] ALIAS_2 ON 
						INV.[UBICACIONDES_ID] = ALIAS_2.ID 
					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[TIPOTRANSACCION] AS TTR WITH(NOLOCK) ON
						INV.TIPOTRANSACCION_ID = TTR.[ID]
				WHERE ((ALIAS_1.[UBICACIONES_ID] = @DEP_ID1 AND ALIAS_2.[ID] = @UBI_ID1) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID2 AND ALIAS_2.[ID] = @UBI_ID2) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID3 AND ALIAS_2.[ID] = @UBI_ID3))
						AND [ESTADOTR] = 'C' 
						AND (CAST([REFERENCIATIPO_ID] AS NVARCHAR(50)) = @PROD_ID OR INV.NOMBREREFERENCIA = @PROD_COD)
		UNION ALL
		SELECT TOP 10000 referenciatipo_id AS PRODUCTO_ID
					, INV.NOMBREREFERENCIA
					, INV.DESCRIPCION
--					, INV.FECHADOCUMENTO
					, SUBSTRING(INV.FECHADOCUMENTO,7,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,5,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,0,5) AS FECHA_DOCUM
	----				, INV.FECHAINV
	--				, SUBSTRING(INV.FECHAINV,7,2) + '/' + SUBSTRING(INV.FECHAINV,5,2) + '/' + SUBSTRING(INV.FECHAINV,0,5) AS FECHA_INV
	----				, INV.FECHAVEN
	--				, SUBSTRING(INV.FECHAVEN,7,2) + '/' + SUBSTRING(INV.FECHAVEN,5,2) + '/' + SUBSTRING(INV.FECHAVEN,0,5) AS FECHA_VTO
					, INV.FECHAENTREGA
					, SUBSTRING(INV.FECHAENTREGA,7,2) + '/' + SUBSTRING(INV.FECHAENTREGA,5,2) + '/' + SUBSTRING(INV.FECHAENTREGA,0,5) AS FECHA_ENTREGA
					, INV.TIPOTRANSACCION_ID AS TRANSAC_ORIGID
					, TTR.CODIGO AS TRANSACTIPO_CODIGO
					, TTR.DESCRIPCION AS TRANSACTIPO_DESC
					, INV.NOMBRETR AS TRANSAC_DOCUM
					, INV.NUMERODOCUMENTO AS TRANSAC_NUMDOC
					, INV.NUMEROITEM AS TRANSAC_NUMITEM
					, ALIAS_1.NOMBRE AS DEPDES_NOMB
					, ALIAS_1.[UBICACIONES_ID] AS DEPDES_ID
					, ALIAS_2.NOMBRE AS UBIDES_NOMB
					, ALIAS_2.[ID] AS UBIDES_ID
	--				, INV.[ESTADOTR] AS TRANSAC_ESTA
					, INV.BULTOS
					, cantidad2_cantidad * -1 AS CANTIDAD
					, valor2_importe AS COSTO
					, cantidad2_cantidad * valor2_importe * -1 AS TOTAL
	--				, INV.MOMENTOTR
					, SUBSTRING(INV.MOMENTOTR,7,2) + '/' + SUBSTRING(INV.MOMENTOTR,5,2) + '/' + SUBSTRING(INV.MOMENTOTR,0,5) AS TRANSAC_FECHA
					, INV.ORIGINANTETR_ID
					, INV.NOMBREORIGINANTETR AS TRANSAC_ORIGINANTE
					, INV.DESTINATARIOTR_ID AS TRANSAC_DESTID
					, INV.NOMBREDESTINATARIOTR AS TRANSAC_DESTINATARIO
					, INV.CENTROCOSTOS_ID
					, INV.COMPANIA_ID
					, INV.UNIDADOPERATIVA_ID
					, INV.BO_PLACE_ID
					, INV.BOEXTENSION_ID
	--				, INV.*
				FROM [CalipsoReplicado].[dbo].[itemtransferenciainventario] AS INV
 					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_DEPOSITO_] ALIAS_1 ON 
						INV.[DEPOSITOORI_ID] = ALIAS_1.ID   
					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_UBICACION_] ALIAS_2 ON 
						INV.[UBICACIONORI_ID] = ALIAS_2.ID 
					LEFT OUTER JOIN [CalipsoReplicado].[dbo].[TIPOTRANSACCION] AS TTR WITH(NOLOCK) ON
						INV.TIPOTRANSACCION_ID = TTR.[ID]
				WHERE ((ALIAS_1.[UBICACIONES_ID] = @DEP_ID1 AND ALIAS_2.[ID] = @UBI_ID1) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID2 AND ALIAS_2.[ID] = @UBI_ID2) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID3 AND ALIAS_2.[ID] = @UBI_ID3))
						AND [ESTADOTR] = 'C' 
						AND (CAST([REFERENCIATIPO_ID] AS NVARCHAR(50)) = @PROD_ID OR INV.NOMBREREFERENCIA = @PROD_COD)
) AS KARDCAL
ORDER BY PRODUCTO_ID, DEPDES_NOMB, UBIDES_NOMB, CAST(FECHA_DOCUM AS DATETIME) DESC, FECHAENTREGA DESC


---- DEP�SITOS
---- DEP�SITO COMERCIAL CORDOBA
---- UBICACIONES
--SELECT  TOP 100 ALIAS_0.[BO_PLACE_ID] DEPOSITO_ID
--	, ALIAS_3.NOMBRE NOMBRE
--	, ALIAS_0.[ITEMSINVENTARIO_ID] ALIAS_0_UBIC_ID
--	, ALIAS_0.NOMBRE ALIAS_0_NOMBRE
--	, ALIAS_0.ACTIVESTATUS ALIAS_0_ACTIVESTATUS
--	, ALIAS_0.VOLUMEN ALIAS_0_VOLUMEN
--	, ALIAS_0.SUPERFICIE ALIAS_0_SUPERFICIE
--	, ALIAS_0.PESOMAXIMO ALIAS_0_PESOMAXIMO
--	, ALIAS_0.ALTURA ALIAS_0_ALTURA
--	, ALIAS_0.TEMPERATURAMAXIMA ALIAS_0_TEMPERATURAMAXIMA
--	, ALIAS_0.TEMPERATURAMINIMA ALIAS_0_TEMPERATURAMINIMA
--	, ALIAS_0.CANTIDADPRODUCTOS ALIAS_0_CANTIDADPRODUCTOS
--	, ALIAS_1.NOMBRE ALIAS_1_NOMBRE
--	, ALIAS_2.NOMBRE ALIAS_2_NOMBRE 
--	FROM [CalipsoReplicado].[dbo].[V_UBICACION_] ALIAS_0  
--		LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_TIPOUBICACION_] ALIAS_1 ON 
--			ALIAS_0.TIPOUBICACION_ID = ALIAS_1.ID   
--		LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_UNIDADMEDIDA_] ALIAS_2 ON 
--			ALIAS_0.UNIDADMEDIDAVOLUMEN_ID = ALIAS_2.ID  
--		LEFT OUTER JOIN [CalipsoReplicado].[dbo].[V_DEPOSITO_] ALIAS_3 ON 
--			ALIAS_0.[BO_PLACE_ID] = ALIAS_3.[UBICACIONES_ID]  
----WHERE ALIAS_0.[BO_PLACE_ID] = '{B9EF3D86-DCFA-46EC-BB41-59BFCF94662B}'
--ORDER BY ALIAS_3.NOMBRE
--
--
--	AND (--ALIAS_0.BO_PLACE_ID = '{50F28FF5-3C9D-4BB0-B0C5-7F7AE9D2D8A0}' -- DEP TAGLE - UBIC UNICA - ES DEP BASURA
--		 -- DEP�SITOS COMERCIALES
--			ALIAS_0.BO_PLACE_ID = '{C98BE931-EDF9-40F5-9759-83B739337DF6}' -- DEP REN CBA CIAL - UBIC UNICA
----			OR ALIAS_0.BO_PLACE_ID = '{E4C4A7C2-44D3-4E76-8F4A-7D7AB6409B69}' -- DEP REN RIV CIAL - UBIC UNICA
--			OR ALIAS_0.BO_PLACE_ID = '{D48CCB2E-7C98-468D-B3E3-C4350EFF0369}' -- DEP NIX CBA CIAL - UBIC UNICA
----			OR ALIAS_0.BO_PLACE_ID = '{2384A556-85B9-4740-8C4E-5BDF8C87F957}' -- DEP NIX RIV CIAL - UBIC UNICA
--		 -- DEP�SITOS GARANT�A
--			OR ALIAS_0.BO_PLACE_ID = '{8A3F51B4-153C-40CA-ACC9-1195F1BEEDBE}' -- DEP REN CBA GTIA - UBIC UNICA
--			OR ALIAS_0.BO_PLACE_ID = '{9520F09F-DCCB-4BFE-9065-FC8913380F15}' -- DEP NIX CBA GTIA - UBIC UNICA
--		 -- DEP�SITOS CHAPA Y PINTURA
--			OR ALIAS_0.BO_PLACE_ID = '{6BB5878B-94B4-4322-A75A-0925C4988B7D}' -- DEP REN CBA GTIA - UBIC UNICA
--		 -- DEP�SITOS ALISTAJE
--			OR ALIAS_0.BO_PLACE_ID = '{8E887877-FB05-419A-A36A-9FD168766876}' -- DEP REN CBA GTIA - UBIC UNICA
--		 -- DEP�SITOS RESERVADOS
--			OR ALIAS_0.BO_PLACE_ID = '{30F4C96F-D6F1-42FF-A5F3-1AC2E5155117}' -- DEP REN CBA RESERVADO - UBIC UNICA
--			OR ALIAS_0.BO_PLACE_ID = '{8659A45C-7298-4804-820A-05925076D73C}' -- DEP REN CBA RESERVADO - UBIC UNICA
--		 )
--
--
--
--
--
--
---------------------------------------------------------------------------------------------------------------------
---- STOCK INICIAL STOCK COMERCIAL (SUMA)
--SELECT            'SI' AS TIPO, 'Stock Inicial' AS DESCRIPCION, 
--                  '' AS NUMERODOCUMENTO,  SI.fecha_inicio AS FECHADOCUMENTO, 
--                  --DEJAR A PRUEBA POR UNOS DIAS SINO QUITAR
--                  --'' AS ESTADOTR, '' AS NOMBREORIGINANTETR, '' AS NOMBREDESTINATARIOTR, '' AS NOMBRETOTALTR, 
--                  SI.STOCKINICIAL AS INGRESO, 0 AS EGRESO    
--FROM        dbo.REP_PIEZAS_STOCK_INICIAL SI    
--WHERE       (SI.pie_codigo = cast(@pie_codigo AS int))    
--AND               (SI.emp_codigo = @emp_codigo)    
--AND               (SI.suc_codigo = @suc_codigo)    
--AND               (SI.fecha_inicio > = @fechainicio) --AND @fechafin)    
--UNION ALL
---------------------------------------------------------------------------------------------------------------------
----REMITO COMERCIAL COMPRA DE RESPUESTO (SUMA)
--SELECT            'REM' AS TIPO, 'Remito Comercial' AS DESCRIPCION, 
--                  rep_remitos.rem_numero AS NUMERODOCUMENTO, 
--                  rep_remitos.rem_fecha AS FECHADOCUMENTO,
--                  --'' AS ESTADOOTR,'' AS NOMBREORIGINANTETR, '' AS NOMBREDESTINATARIOTR,'' AS NOMBRETOTALTR, 
--                  REP_DETALLE_REMITO.dre_cantidad AS INGRESO, 0 AS EGRESO    
--FROM        REP_REMITOS    
--INNER JOIN  REP_DETALLE_REMITO 
--ON                REP_REMITOS.emp_codigo=REP_DETALLE_REMITO.emp_codigo 
--AND               REP_REMITOS.suc_codigo=REP_DETALLE_REMITO.suc_codigo 
--AND               REP_REMITOS.rem_codigo=REP_DETALLE_REMITO.rem_codigo    
--WHERE       REP_DETALLE_REMITO.emp_codigo=@emp_codigo 
--AND               REP_DETALLE_REMITO.suc_codigo=@suc_codigo 
--AND               REP_REMITOS.rem_fecha > = @fechainicio  
----AND       @fechafin + 1    
--AND               REP_DETALLE_REMITO.pie_codigo=@pie_codigo                  
--AND               REP_REMITOS.rem_tipo_comprobante = 223
--UNION ALL
------------------------------------------------------------------------------------------------------------------------
----REMITO AJUSTE DE RESPUESTO (SUMA)
--SELECT            'REMA' AS TIPO, 'Remito Por Ajuste' AS DESCRIPCION, 
--                  REP_REMITOS.rem_numero AS NUMERODOCUMENTO, 
--                  REP_REMITOS.rem_fecha AS FECHADOCUMENTO,
----                '' AS ESTADOOTR,'' AS NOMBREORIGINANTETR, '' AS NOMBREDESTINATARIOTR,'' AS NOMBRETOTALTR, 
--                  REP_DETALLE_REMITO.dre_cantidad AS INGRESO, 0 AS EGRESO    
--FROM        REP_REMITOS    
--INNER JOIN  REP_DETALLE_REMITO 
--ON                REP_REMITOS.emp_codigo=REP_DETALLE_REMITO.emp_codigo 
--AND               REP_REMITOS.suc_codigo=REP_DETALLE_REMITO.suc_codigo 
--AND               REP_REMITOS.rem_codigo=REP_DETALLE_REMITO.rem_codigo    
--WHERE       REP_DETALLE_REMITO.emp_codigo=@emp_codigo 
--AND               REP_DETALLE_REMITO.suc_codigo=@suc_codigo 
--AND               REP_REMITOs.rem_fecha > = @fechainicio  
----AND       @fechafin + 1 and    
--AND               REP_DETALLE_REMITO.pie_codigo=@pie_codigo 
--AND               REP_REMITOS.rem_tipo_comprobante = 228
--UNION ALL  
---------------------------------------------------------------------------------------------------------------------
---- NOTA DE CREDITO VENTA DE RESPUESTO (SUMA)
--SELECT            'NC' AS TIPO, 'Nota Credito Venta' AS DESCRIPCION, CAST(I.NUMERODOCUMENTO AS VARCHAR) AS NUMERODOCUMENTO, 
--                  SUBSTRING(I.FECHADOCUMENTO,7,2)+'/'+SUBSTRING(I.FECHADOCUMENTO,5,2)+'/'+SUBSTRING(I.FECHADOCUMENTO,1,4) AS FECHADOCUMENTO, 
--                  --I.ESTADOTR, I.NOMBREORIGINANTETR, I.NOMBREDESTINATARIOTR, I.NOMBRETOTALTR, 
--                  I.CANTIDAD2_CANTIDAD AS INGRESO, 0 AS EGRESO 
--FROM        .CalipsoProduccion.dbo.ITEMCREDITOVENTA I    
--INNER JOIN  .CalipsoProduccion.dbo.PRODUCTO P 
--ON                P.ID = I.REFERENCIA_ID
--INNER JOIN  .CalipsoProduccion.dbo.UD_PRODUCTO UDP
--ON                P.BOEXTENSION_ID=UDP.ID    
--INNER JOIN .CalipsoProduccion.dbo.V_UNIDADOPERATIVA 
--ON                I.UNIDADOPERATIVA_ID=V_UNIDADOPERATIVA.ID    
--INNER JOIN .CalipsoProduccion.dbo.TRCREDITOVENTA TR 
--ON                TR.ID = I.PLACEOWNER_ID
--INNER JOIN .CalipsoProduccion.dbo.UD_NOTACREDITOVENTA UD 
--ON                UD.ID = TR.BOEXTENSION_ID
--INNER JOIN .CalipsoProduccion.dbo.ITEMTIPOCLASIFICADOR TV 
--ON                TV.ID = UD.SUCURSAL_ID 
--WHERE       UDP.CodigoTechCor = Convert(nvarchar,@pie_codigo)    
--AND               I.TIPOTRANSACCION_ID =  '{FF5DA972-CD50-4FF6-B1DD-EE55647306B0}'       
--AND               V_UNIDADOPERATIVA.CODIGO = cast(@emp_codigo as varchar)
--AND               TV.CODIGO = cast(@suc_codigo as varchar)
--AND               (CONVERT(DATETIME,SUBSTRING(I.FECHADOCUMENTO,0,9)) > =  @fechainicio) -- AND @fechafin) 
--and               UD.SOLICITUD = ''
--AND               TR.ESTADO not like 'N'
--AND               TR.NUMERODOCUMENTO NOT LIKE 'AN%'
--AND               I.FECHADOCUMENTO<'20120920'
--UNION ALL   
---------------------------------------------------------------------------------------------------------------------
----VALES DE DEVOLUCION (SUMA)
--SELECT            'VA' AS TIPO, 'Vale Devolucion' AS DESCRIPCION,  CAST(DVA.val_codigo AS varchar) AS NUMERODOCUMENTO, 
--                  DVA.dva_fecha as FECHADOCUMENTO, 
--                  --'' as ESTADOTR, '' as NOMBREORIGINANTETR, '' as NOMBREDESTINATARIOTR, '' as NOMBRETOTALTR,     
--                  DVA.dva_cantidad AS INGRESO , 0  AS EGRESO
--FROM        REP_DETALLE_VALES DVA 
--INNER JOIN  TAL_DETALLE_ODR DO 
--ON                DO.EMP_CODIGO = DVA.EMP_CODIGO 
--AND               DO.SUC_CODIGO = DVA.SUC_CODIGO 
--AND               DO.DEO_CODIGO = DVA.DEO_CODIGO  
--WHERE       DVA.DVA_ACCION LIKE '%Dev%'  
--AND               DO.CAR_CODIGO <> 8  
--AND               DVA.PIE_CODIGO = @pie_codigo 
--AND               DVA.EMP_CODIGO = @emp_codigo  
--AND               DVA.SUC_CODIGO = @suc_codigo 
--AND               DVA.DVA_FECHA > = @fechainicio
---- AND @fechafin
--UNION ALL
---------------------------------------------------------------------------------------------------------------------
----VALES DE DEVOLUCION POR GARANTIA CANAL CREDITO (SUMA)
--SELECT            'VA' AS TIPO, 'Vale Devolucion Canal Credito' AS DESCRIPCION,  CAST(DVA.val_codigo AS varchar) AS NUMERODOCUMENTO, 
--                  DVA.dva_fecha as FECHADOCUMENTO, 
--                  --'' as ESTADOTR, '' as NOMBREORIGINANTETR, '' as NOMBREDESTINATARIOTR, '' as NOMBRETOTALTR,     
--                  DVA.dva_cantidad AS INGRESO , 0  AS EGRESO
--FROM        REP_DETALLE_VALES DVA 
--INNER JOIN  TAL_DETALLE_ODR DO 
--ON                DO.EMP_CODIGO = DVA.EMP_CODIGO 
--AND               DO.SUC_CODIGO = DVA.SUC_CODIGO 
--AND               DO.DEO_CODIGO = DVA.DEO_CODIGO  
--WHERE       DVA.DVA_ACCION LIKE '%Dev%'  
--AND               DO.CAR_CODIGO = 8
--AND               DO.DEO_OBSERVACION LIKE '%312%'  
--AND               DVA.PIE_CODIGO = @pie_codigo 
--AND               DVA.EMP_CODIGO = @emp_codigo  
--AND               DVA.SUC_CODIGO = @suc_codigo 
--AND               DVA.DVA_FECHA > = @fechainicio
---- AND            @fechafin
--UNION ALL
---------------------------------------------------------------------------------------------------------------------
----DEVOLUCION DE PRESTAMO (SUMA) 
--SELECT            'DPG' AS TIPO, 'Devolucion Prestamo Garantia' AS DESCRIPCION, CAST(RDP.pre_codigo AS varchar) AS NUMERODOCUMENTO, 
--                  RP.pre_fecha AS FECHADOCUMENTO,
--                  --'' AS ESTADOTR, '' AS NOMBREORIGINANTETR, '' AS NOMBREDESTINATARIOTR, '' AS NOMBRETOTALTR, 
--                  dpr_cantidad AS INGRESO, 0  AS EGRESO
--FROM        REP_DETALLE_PRESTAMO AS RDP 
--INNER JOIN  REP_PRESTAMOS RP
--ON                RP.emp_codigo=RDP.emp_codigo
--AND               RP.suc_codigo=RDP.suc_codigo
--AND               RP.pre_codigo=RDP.pre_codigo
--WHERE       RDP.pie_codigo = CAST(@pie_codigo AS int) 
--AND               RDP.emp_codigo = @emp_codigo 
--AND               RDP.suc_codigo = @suc_codigo 
--AND               RP.pre_fecha > = @fechainicio 
--AND               RDP.dpr_tipo_stock_origen like '%RG%'
----AND       @fechafin 
--UNION ALL
---------------------------------------------------------------------------------------------------------------------
----FACTURA DE VENTA COMERCIAL DE RESPUESTOS - TRAE TODAS FACTURAS CERRADAS Y SIN CONFIRMAR (RESTA)
--SELECT            'FV' AS TIPO, 'Factura de Venta' AS DESCRIPCION, CAST(I.NUMERODOCUMENTO AS VARCHAR) AS NUMERODOCUMENTO, 
--                  SUBSTRING(I.FECHADOCUMENTO,7,2)+'/'+SUBSTRING(I.FECHADOCUMENTO,5,2)+'/'+SUBSTRING(I.FECHADOCUMENTO,1,4) AS FECHADOCUMENTO, 
--                  --I.ESTADOTR, I.NOMBREORIGINANTETR, I.NOMBREDESTINATARIOTR, I.NOMBRETOTALTR, 
--                  0 AS INGRESO, I.CANTIDAD2_CANTIDAD AS EGRESO 
--FROM        CalipsoProduccion.dbo.ITEMFACTURAVENTA I    
--INNER JOIN  CalipsoProduccion.dbo.PRODUCTO P               
--ON                P.ID = I.REFERENCIA_ID    
--INNER JOIN  CalipsoProduccion.dbo.UD_PRODUCTO UDP
--ON                P.BOEXTENSION_ID=UDP.ID
--INNER JOIN  CalipsoProduccion.dbo.V_UNIDADOPERATIVA  
--ON                I.UNIDADOPERATIVA_ID=V_UNIDADOPERATIVA.ID  
--INNER JOIN  CalipsoProduccion.dbo.TRFACTURAVENTA TR  
--ON                TR.ID = I.PLACEOWNER_ID
--INNER JOIN  CalipsoProduccion.dbo.UD_FACTURAVENTA UD
--ON                UD.ID = TR.BOEXTENSION_ID
--INNER JOIN  CalipsoProduccion.dbo.ITEMTIPOCLASIFICADOR TV 
--ON                TV.ID = UD.SUCURSAL_ID 
----AND       TV.NOMBRE LIKE '%Repuestos%'
--WHERE       UDP.CodigoTechCor = Convert(nvarchar,@pie_codigo)    
--AND               I.TIPOTRANSACCION_ID =  '{6D6B7EB2-9495-4A0B-BA48-50AD66D95FCC}'      
--AND               V_UNIDADOPERATIVA.CODIGO = cast(@emp_codigo AS varchar)
--AND               TV.CODIGO = cast(@suc_codigo AS varchar)
--AND               (CONVERT(DATETIME,SUBSTRING(I.FECHADOCUMENTO,0,9)) > =  @fechainicio) -- AND @fechafin) 
--AND               UD.SOLICITUD = ''
--AND               TR.ESTADO not like 'N'
--AND               I.FECHADOCUMENTO<'20120920'
--UNION ALL
---------------------------------------------------------------------------------------------------------------------
----FACTURA DE VENTA RT COMERCIAL DE RESPUESTOS - TRAE TODAS FACTURAS CERRADAS Y SIN CONFIRMAR (RESTA)
--SELECT            'FV' AS TIPO, 'Factura de Venta' AS DESCRIPCION, CAST(I.NUMERODOCUMENTO AS VARCHAR) AS NUMERODOCUMENTO, 
--                  SUBSTRING(I.FECHADOCUMENTO,7,2)+'/'+SUBSTRING(I.FECHADOCUMENTO,5,2)+'/'+SUBSTRING(I.FECHADOCUMENTO,1,4) AS FECHADOCUMENTO, 
--                  --I.ESTADOTR, I.NOMBREORIGINANTETR, I.NOMBREDESTINATARIOTR, I.NOMBRETOTALTR, 
--                  0 AS INGRESO, I.CANTIDAD2_CANTIDAD AS EGRESO 
--FROM        CalipsoProduccion.dbo.TRFACTURAVENTA TR
--INNER JOIN  CalipsoProduccion.dbo.ITEMFACTURAVENTA I    
--ON                TR.ID = I.PLACEOWNER_ID
--INNER JOIN  CalipsoProduccion.dbo.PRODUCTO P               
--ON                P.ID = I.REFERENCIA_ID
--INNER JOIN  CalipsoProduccion.dbo.UD_PRODUCTO UDP
--ON                P.BOEXTENSION_ID=UDP.ID    
--INNER JOIN  CalipsoProduccion.dbo.V_UNIDADOPERATIVA  
--ON                I.UNIDADOPERATIVA_ID=V_UNIDADOPERATIVA.ID  
--INNER JOIN  CalipsoProduccion.dbo.UD_FACTURAVENTART UD
--ON                UD.ID = TR.BOEXTENSION_ID
--INNER JOIN  CalipsoProduccion.dbo.ITEMTIPOCLASIFICADOR TV 
--ON                TV.ID = UD.SUCURSAL_ID 
----AND       TV.NOMBRE LIKE '%Repuestos%'
--WHERE       UDP.CodigoTechCor = Convert(nvarchar,@pie_codigo)    
--AND               I.TIPOTRANSACCION_ID =  '{CD910422-6A3B-4E06-A91C-F89D1B83241B}'      
--AND               V_UNIDADOPERATIVA.CODIGO = cast(@emp_codigo AS varchar)
--AND               TV.CODIGO = cast(@suc_codigo AS varchar)
--AND               (CONVERT(DATETIME,SUBSTRING(I.FECHADOCUMENTO,0,9)) > = @fechainicio) -- AND @fechafin) 
--AND               UD.SOLICITUD = ''
--AND               TR.ESTADO not like 'N'
--AND               I.FECHADOCUMENTO<'20120920'
--UNION ALL    
---------------------------------------------------------------------------------------------------------------------
---- ANULACION DE CREDITO VENTA DE RESPUESTO (RESTA)
--SELECT            'NC' AS TIPO, 'Anulacion de Credito Venta' AS DESCRIPCION, CAST(I.NUMERODOCUMENTO AS VARCHAR) AS NUMERODOCUMENTO, 
--                  SUBSTRING(I.FECHADOCUMENTO,7,2)+'/'+SUBSTRING(I.FECHADOCUMENTO,5,2)+'/'+SUBSTRING(I.FECHADOCUMENTO,1,4) AS FECHADOCUMENTO, 
--                  --I.ESTADOTR, I.NOMBREORIGINANTETR, I.NOMBREDESTINATARIOTR, I.NOMBRETOTALTR, 
--                  0 AS INGRESO, I.CANTIDAD2_CANTIDAD AS EGRESO 
--FROM        CalipsoProduccion.dbo.ITEMCREDITOVENTA I    
--INNER JOIN  CalipsoProduccion.dbo.PRODUCTO P 
--ON                P.ID = I.REFERENCIA_ID
--INNER JOIN  CalipsoProduccion.dbo.UD_PRODUCTO UDP
--ON                P.BOEXTENSION_ID=UDP.ID    
--INNER JOIN  CalipsoProduccion.dbo.V_UNIDADOPERATIVA 
--ON                I.UNIDADOPERATIVA_ID=V_UNIDADOPERATIVA.ID    
--INNER JOIN  CalipsoProduccion.dbo.TRCREDITOVENTA TR 
--ON                TR.ID = I.PLACEOWNER_ID
--INNER JOIN  CalipsoProduccion.dbo.UD_NOTACREDITOVENTA UD 
--ON                UD.ID = TR.BOEXTENSION_ID
--INNER JOIN  CalipsoProduccion.dbo.ITEMTIPOCLASIFICADOR TV 
--ON                TV.ID = UD.SUCURSAL_ID 
--WHERE       UDP.CodigoTechCor = Convert(nvarchar,@pie_codigo)    
--AND               I.TIPOTRANSACCION_ID =  '{FF5DA972-CD50-4FF6-B1DD-EE55647306B0}'       
--AND               V_UNIDADOPERATIVA.CODIGO = cast(@emp_codigo as varchar)
--AND               TV.CODIGO = cast(@suc_codigo as varchar)
--AND               (CONVERT(DATETIME,SUBSTRING(I.FECHADOCUMENTO,0,9)) > =  @fechainicio) -- AND @fechafin) 
--and               UD.SOLICITUD = ''
--AND               TR.ESTADO NOT LIKE 'N'
--AND               TR.NUMERODOCUMENTO LIKE 'AN%'
--AND               I.FECHADOCUMENTO<'20120920'
--UNION ALL
---------------------------------------------------------------------------------------------------------------------
---- VALE DE ENTREGA DE REPUESTOS (RESTA)
--SELECT            'VA' AS TIPO, 'Vale Entrega'  as DESCRIPCION, cast(DV.val_codigo as varchar) as NUMERODOCUMENTO, 
--                  DV.dva_fecha as FECHADOCUMENTO,
--                  --'' as ESTADOTR, '' as NOMBREORIGINANTETR, '' as NOMBREDESTINATARIOTR, '' as NOMBRETOTALTR,
--                  0 AS INGRESO, (DV.dva_cantidad) AS EGRESO
--FROM        REP_DETALLE_VALES DV
--INNER JOIN  TAL_DETALLE_ODR DO
--ON                DV.emp_codigo=DO.emp_codigo
--AND               DV.suc_codigo=DO.suc_codigo
--AND               DV.deo_codigo=DO.deo_codigo
--WHERE       DV.DVA_ACCION LIKE '%Ent%'  
--AND               DO.CAR_CODIGO <> 8
--AND               DV.PIE_CODIGO = @pie_codigo 
--AND               DV.EMP_CODIGO = @emp_codigo  
--AND               DV.SUC_CODIGO = @suc_codigo 
--AND               DV.DVA_FECHA > = @fechainicio
--UNION ALL
---------------------------------------------------------------------------------------------------------------------
---- VALE DE ENTREGA DE REPUESTOS POR CANAL CREDITO (RESTA)
--SELECT            'VA' AS TIPO, 'Vale Entrega Canal Credito'  as DESCRIPCION, cast(DV.val_codigo as varchar) as NUMERODOCUMENTO, 
--                  DV.dva_fecha as FECHADOCUMENTO,
--                  --'' as ESTADOTR, '' as NOMBREORIGINANTETR, '' as NOMBREDESTINATARIOTR, '' as NOMBRETOTALTR,
--                  0 AS INGRESO, (DV.dva_cantidad) AS EGRESO
--FROM        REP_DETALLE_VALES DV
--INNER JOIN  TAL_DETALLE_ODR DO
--ON                DV.emp_codigo=DO.emp_codigo
--AND               DV.suc_codigo=DO.suc_codigo
--AND               DV.deo_codigo=DO.deo_codigo
--WHERE       DV.DVA_ACCION LIKE '%Ent%'  
--AND               DO.CAR_CODIGO = 8
--AND               DO.DEO_OBSERVACION LIKE '%312%'  
--AND               DV.PIE_CODIGO = @pie_codigo 
--AND               DV.EMP_CODIGO = @emp_codigo  
--AND               DV.SUC_CODIGO = @suc_codigo 
--AND               DV.DVA_FECHA > = @fechainicio
--UNION ALL  
---------------------------------------------------------------------------------------------------------------------
----AJUSTES STOCK MEMOS (RESTA)
--SELECT            'AJM' AS TIPO, 'Ajuste Stock Menos' AS DESCRIPCION, cast(AJ.aju_codigo AS varchar) AS NUMERODOCUMENTO, 
--                  cast(AJ.aju_fecha AS varchar) AS FECHADOCUMENTO, 
--                  --'' AS ESTADOTR,'' AS NOMBREORIGINANTETR,'' AS NOMBREDESTINATARIOTR,'' AS NOMBRETOTALTR, 
--                  0 AS INGRESO, (AJ.aju_cantidad * -1) as EGRESO    
--FROM        REP_AJUSTE_STOCK AJ    
--WHERE       AJ.pie_codigo = cast(@pie_codigo as int)    
--AND               AJ.emp_codigo = @emp_codigo    
--AND               AJ.aju_fecha > = @fechainicio 
----//el 4 corresponde a ajuste por inventario.
----and  (aj.aju_motivo <> 4) 
----//el 5 corresponde reclamo.
--AND               AJ.aju_observaciones not like '%Ajuste en mas por inventario%'
--AND               AJ.aju_motivo <> 5
--AND               AJ.suc_codigo =@suc_codigo
----AND @fechafin + 2)  
--UNION ALL
---------------------------------------------------------------------------------------------------------------------
------PRESTAMOS DE COMERCIAL A GARANTIA. (RESTA)
--SELECT            'PRE' AS TIPO, 'Prestamo'  AS DESCRIPCION, cast(RDP.pre_codigo AS varchar) AS NUMERODOCUMENTO, 
--                  RP.pre_fecha as FECHADOCUMENTO, 
--                  --'' AS ESTADOTR, '' AS NOMBREORIGINANTETR, '' AS NOMBREDESTINATARIOTR, '' AS NOMBRETOTALTR,
--                  0 AS INGRESO, RDP.dpr_cantidad AS EGRESO 
--FROM        REP_DETALLE_PRESTAMO AS RDP 
--INNER JOIN  REP_PRESTAMOS AS RP
--ON                RP.emp_codigo=RDP.emp_codigo
--AND               RP.suc_codigo=RDP.suc_codigo
--AND               RP.pre_codigo=RDP.pre_codigo
--WHERE       RDP.pie_codigo = CAST(@pie_codigo AS int) 
--AND               RDP.emp_codigo = @emp_codigo 
--AND               RDP.suc_codigo = @suc_codigo   
--AND               RDP.PRE_CODIGO = RP.PRE_CODIGO  
--AND               RP.pre_fecha BETWEEN @fechainicio AND getdate() --dateadd(hour,23,@fechafin))   
--AND               RDP.dpr_tipo_stock_origen like '%RC%' 
--UNION ALL  
---------------------------------------------------------------------------------------------------------------------
----RECLAMO DE RESPUESTO (RESTA)
--SELECT            'REC' AS TIPO, 'Reclamo' AS DESCRIPCION, R.rec_numero_fabrica AS NUMERODOCUMENTO, R.rec_fecha_reclamo AS FECHADOCUMENTO,
--                  --'' AS ESTADOOTR,'' AS NOMBREORIGINANTETR, '' AS NOMBREDESTINATARIOTR,'' as NOMBRETOTALTR,
--                  0 AS INGRESO, DR.der_cantidad_reclamada AS EGRESO    
--from        REP_RECLAMOS AS R  
--INNER JOIN  REP_DETALLE_RECLAMOS AS DR 
--ON                R.emp_codigo=DR.emp_codigo
--AND               R.suc_codigo=DR.suc_codigo
--AND               R.rec_codigo = DR.rec_codigo
--INNER JOIN  REP_CAUSA_RECLAMO CR 
--ON                DR.emp_codigo=CR.emp_codigo
--AND               DR.der_causa=CR.cau_codigo    
--WHERE       R.emp_codigo=@emp_codigo 
--AND               R.suc_codigo=@suc_codigo 
--AND               R.rec_fecha_reclamo > = @fechainicio   
--AND               DR.pie_codigo=@pie_codigo     
--AND               CR.cau_asiento = 1 
--AND               DR.der_estado like 'A'
