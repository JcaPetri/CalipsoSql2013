-- ###################################################################################################################################
-- INICIO - ACT STOCK -- PASO 2  -- ACTUALIZA LA TABLA DEL STOCK [STK0101_STOCK]
-- ###################################################################################################################################
DECLARE @NUEVOIDACT AS NVARCHAR(36) 
DECLARE @PROCNUM AS NUMERIC(18,0)

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'STCK_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'STCK_ACT', 2, @PROCNUM, 'STCK_COMPLETO', 'STCK_C_DATBORR', '[STK0110_STOCK]', 'Borra los datos de la Tabla', CAST(GETDATE() AS DATETIME), NULL

-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- PRIMERO BORRA LOS DATOS DE LA BASE
DELETE FROM [PVTWEB].[dbo].[STK0110_STOCK]

UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::

SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'STCK_ACT', 2, @PROCNUM, 'STCK_COMPLETO', 'STCK_C_DATIMP', '[STK0110_STOCK]', 'Pasa los datos de la Tabla Kardex a Stock', CAST(GETDATE() AS DATETIME), NULL

-- LUEGO IMPORTA LOS DATOS COMPLETOS
INSERT INTO [PVTWEB].[dbo].[STK0110_STOCK]
           ([STK0110_UOP_NOMBRE]
           ,[STK0110_DEPNOMID]
           ,[STK0110_DEPNOMB]
           ,[STK0110_UBIDES_ID]
           ,[STK0110_UBICNOMB]
           ,[STK0110_REFID]
           ,[STK0110_REFCOD]
           ,[STK0110_REFERDESC]
           ,[STK0110_CANT]
           ,[STK0110_CTOPROM]
           ,[STK0110_CTOTOT])
		SELECT [STK0120_UOP_NOMBRE]
			  ,[STK0120_DEPDES_ID]
			  ,[STK0120_DEPDES_NOMB]
			  ,[STK0120_UBIDES_ID]
			  ,[STK0120_UBIDES_NOMB]
			  ,[STK0120_REFID]
			  ,[STK0120_REFCOD]
			  ,[STK0120_REFDESC]
			  ,SUM([STK0120_CANTIDAD]) AS [CANT]
			  ,CASE WHEN SUM([STK0120_CANTIDAD]) = 0 THEN 0 ELSE SUM([STK0120_TOTAL]) / SUM([STK0120_CANTIDAD]) END AS [CTOPROM]
			  ,SUM([STK0120_TOTAL]) AS [TOTAL]
		  FROM [PVTWEB].[dbo].[STK0120_KARDEX]
			GROUP BY [STK0120_UOP_NOMBRE]
					 ,[STK0120_DEPDES_ID]
					 ,[STK0120_DEPDES_NOMB]
					 ,[STK0120_UBIDES_ID]
					 ,[STK0120_UBIDES_NOMB]
					 ,[STK0120_REFID]
					 ,[STK0120_REFCOD]
					 ,[STK0120_REFDESC]
			ORDER BY [STK0120_REFCOD]
					 ,[STK0120_REFID]
					 ,[STK0120_DEPDES_ID]
					 ,[STK0120_UBIDES_ID]


UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT
-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
-- ###################################################################################################################################
-- FIN - ACT STOCK -- PASO 2  -- ACTUALIZA LA TABLA DEL STOCK [STK0101_STOCK]
-- ###################################################################################################################################

