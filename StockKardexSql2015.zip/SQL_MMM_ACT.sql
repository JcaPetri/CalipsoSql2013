-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 1  -- ACTUALIZA LA TABLA Marca Modelo Submodelo Motor - para que los informes salgan correctos.
-- ###################################################################################################################################
DECLARE @NUEVOIDACT AS NVARCHAR(36) 
DECLARE @PROCNUM AS NUMERIC(18,0)

-- GENERA EL CODIGO PARA ESTE PROCESO, ESTO PERMITE QUE EN CADA ETAPA SEPARADA CARGUE EL MISMO CODIGO
-- PRIMERO BORRA EL CODIGO DEL PROCESO, ES POR LAS DUDAS SI HUBIERE
DELETE FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WHERE [GRL098_PROC] = 'MMM_ACT'
INSERT INTO [PVTWEB].[dbo].[GRL098_PROCLAVE]
           ([GRL098_PROC]
           ,[GRL098_PROCNUM])
       SELECT 'MMM_ACT', REPLACE(REPLACE(REPLACE(CONVERT(NVARCHAR(20), GETDATE(), 120), '-', ''), ':', ''), ' ', '')

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'MMM_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
-- [GRL050_MMM]
-- Esta consulta es para arreglar las Marcas, Modelos, Submodelo Motor, que cargan los usuarios, luego de corregirlas en la base TPVWEB
-- se la carga en el servidor para que cuando consultamos las FC de venta y las OT, pongamos los datos correctos.
-- este proceso se hace eventualmente, por lo tanto se saca de la actualizaci�n diaria.

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'MMM_ACT', 1, @PROCNUM, 'MMM_DATAD', 'MMM_DATIMP', '[GRL050_MMM]', 'Agrega datos faltantes del servidor', CAST(GETDATE() AS DATETIME), NULL


-- IMPORTA LOS DATOS FALTANTES A LA TABLA - LAS NUEVAS MARCAS - MODELO - MOTOR, QUE NO ESTAN EN LA TABLA
-- LAS OTRAS QUEDAN
INSERT INTO [PVTWEB].[dbo].[GRL050_MMM]
           ([GRL050_MMM_ID]
		   ,[GRL050_MARCA]
           ,[GRL050_MODELO]
           ,[GRL050_SUBMODELO]
           ,[GRL050_MOTOR]
           ,[GRL050_CANTUTIL])
		SELECT NEWID()
			  ,[MARCA]
			  ,[MODELO]
			  ,[SUBMODELO]
			  ,[MOTOR]
			  ,[CANTUTIL]
		  FROM [SYS-REPLICA].[CalipsoReplicado].[dbo].[JCP_VP_MMM] AS CM 
			LEFT OUTER JOIN (
							SELECT [GRL050_MARCA]
								  ,[GRL050_MODELO]
								  ,[GRL050_SUBMODELO]
								  ,[GRL050_MOTOR]
								  ,[GRL050_CANTUTIL]
							  FROM [PVTWEB].[dbo].[GRL050_MMM] WITH(NOLOCK)
							) AS MM ON
					CM.[MARCA] = MM.[GRL050_MARCA]
						AND
					CASE WHEN CM.[MODELO] IS NULL OR CM.[MODELO] = '' THEN '1' ELSE CM.[MODELO] END = CASE WHEN MM.[GRL050_MODELO] IS NULL OR MM.[GRL050_MODELO] = '' THEN '1' ELSE MM.[GRL050_MODELO]END
						AND
					CASE WHEN CM.[SUBMODELO] IS NULL OR CM.[SUBMODELO] = '' THEN '1' ELSE CM.[SUBMODELO] END = CASE WHEN MM.[GRL050_SUBMODELO] IS NULL OR MM.[GRL050_SUBMODELO] = '' THEN '1' ELSE MM.[GRL050_SUBMODELO] END
						AND
					CASE WHEN CM.[MOTOR] IS NULL OR CM.[MOTOR] = ''  THEN '1' ELSE CM.[MOTOR] END = CASE WHEN MM.[GRL050_MOTOR] IS NULL OR MM.[GRL050_MOTOR] = ''  THEN '1' ELSE MM.[GRL050_MOTOR] END
		WHERE MM.[GRL050_MARCA] IS NULL

-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT

-- ###################################################################################################################################
-- FIN - ACTCC_PASO 1 -- ACTUALIZA LA TABLA MARCA MODELO MOTOR
-- ###################################################################################################################################


-- AQU� DEBO ACTUALIZAR LOS DATOS CORRECTOS DE Marca Modelo Submodelo Motor , en excel REF CLASIFICACION MMM.xlsx
-- Lo actualice con Oscar
-- 
-- Borra la Base de Actualizaci�n
DELETE FROM [PVTWEB].[dbo].[GRL050_MMM_ACT]

-- cargo los datos con un copiar y pegar de excel.

-- Actualiza un campo
UPDATE [PVTWEB].[dbo].[GRL050_MMM]
--   [GRL050_MMM_ID] = <GRL050_MMM_ID, uniqueidentifier,>
--      ,[GRL050_MARCA] = <GRL050_MARCA, varchar(120),>
--      ,[GRL050_MODELO] = <GRL050_MODELO, varchar(120),>
--      ,[GRL050_SUBMODELO] = <GRL050_SUBMODELO, varchar(120),>
--      ,[GRL050_MOTOR] = <GRL050_MOTOR, varchar(3),>
--      ,[GRL050_CANTUTIL] = <GRL050_CANTUTIL, numeric,>
--      ,[GRL050_MARCA_OK] = <GRL050_MARCA_OK, varchar(120),>
--      ,[GRL050_MARCA_ABR] = <GRL050_MARCA_ABR, varchar(3),>
--     SET [GRL050_MODELO_OK] = [GRL052_DATACT]
--      ,[GRL050_MODELO_ABR] = <GRL050_MODELO_ABR, varchar(5),>
--		SET [GRL050_SUBMOD_OK] = [GRL052_DATACT]
--      ,[GRL050_SUBMOD_ABR] = <GRL050_SUBMOD_ABR, varchar(5),>
		SET [GRL050_MOTOR_OK] = [GRL052_DATACT]
		FROM [PVTWEB].[dbo].[GRL050_MMM] AS MM 
			INNER JOIN (SELECT [GRL052_MMM_ID]
							  ,[GRL052_DATACT]
						  FROM [PVTWEB].[dbo].[GRL050_MMM_ACT]
						) AS MA ON
		MM.[GRL050_MMM_ID] = MA.[GRL052_MMM_ID]
		


-- ###################################################################################################################################
-- INICIO - ACTCC_PASO 2 -- ACTUALIZA LA TABLA DE CALIPSO - JCP_MMM
-- ###################################################################################################################################
DECLARE @NUEVOIDACT AS NVARCHAR(36) 
DECLARE @PROCNUM AS NUMERIC(18,0)

-- 1ERO ACTUALIZA LOS DATOS
-- Luego de ACTUALIZA la Tabla con la MMM, por los usuarios, debo actualizar la Tabla de Calipso que es desde donde se tomaran 
-- los datos en las distintas consultas.

-- TOMA EL COGIDO DEL PROCESO VIGENTE
-- GENERA EL CODIGO DE LA SUBETAPA PARA LUEGO PODER CARGARLE EL TIEMPO DE FINALIZACION
SET @PROCNUM  = (SELECT TOP 1 [GRL098_PROCNUM] FROM [PVTWEB].[dbo].[GRL098_PROCLAVE] WITH(NOLOCK) WHERE [GRL098_PROC] = 'MMM_ACT')
SET @NUEVOIDACT = NEWID()	-- MARCA TIEMPO DE INICIO
-- [GRL050_MMM]
-- Esta consulta es para arreglar las Marcas, Modelos, Submodelo Motor, que cargan los usuarios, luego de corregirlas en la base TPVWEB
-- se la carga en el servidor para que cuando consultamos las FC de venta y las OT, pongamos los datos correctos.
-- este proceso se hace eventualmente, por lo tanto se saca de la actualizaci�n diaria.

INSERT INTO [PVTWEB].[dbo].[GRL099_ACTREG]	
	([GRL099_CODID], [GRL099_PROC], [GRL099_PROCORD], [GRL099_PROCNUM], [GRL099_SUBPROC], [GRL099_ACTPROC], [GRL099_OBJAFEC], [GRL099_PROCDESC], [GRL099_FECINIC], [GRL099_FECFIN]) 
	 SELECT @NUEVOIDACT, 'MMM_ACT', 2, @PROCNUM, 'MMM_CALIPSO', 'MMM_DATIMP', '[JCP_MMM]', 'Actualiza Calipso MMM', CAST(GETDATE() AS DATETIME), NULL


UPDATE [SYS-REPLICA].[CalipsoReplicado].[dbo].[JCP_MMM]
   SET [MARCA] = [GRL050_MARCA]
      ,[MODELO] = [GRL050_MODELO]
      ,[SUBMODELO] = [GRL050_SUBMODELO]
      ,[MOTOR] = [GRL050_MOTOR]
      ,[CANTUTIL] = [GRL050_CANTUTIL]
      ,[MARCA_OK] = [GRL050_MARCA_OK]
      ,[MARCA_ABR] = [GRL050_MARCA_ABR]
      ,[MODELO_OK] = [GRL050_MODELO_OK]
      ,[MODELO_ABR] = [GRL050_MODELO_ABR]
      ,[SUBMOD_OK] = [GRL050_SUBMOD_OK]
      ,[SUBMOD_ABR] = [GRL050_SUBMOD_ABR]
      ,[MOTOR_OK] = [GRL050_MOTOR_OK]
--		SELECT [MMM_ID], MMM.* 
		FROM [SYS-REPLICA].[CalipsoReplicado].[dbo].[JCP_MMM] CMMM WITH(NOLOCK) 
				INNER JOIN (SELECT [GRL050_MMM_ID]
								  ,[GRL050_MARCA]
								  ,[GRL050_MODELO]
								  ,[GRL050_SUBMODELO]
								  ,[GRL050_MOTOR]
								  ,[GRL050_CANTUTIL]
								  ,[GRL050_MARCA_OK]
								  ,[GRL050_MARCA_ABR]
								  ,[GRL050_MODELO_OK]
								  ,[GRL050_MODELO_ABR]
								  ,[GRL050_SUBMOD_OK]
								  ,[GRL050_SUBMOD_ABR]
								  ,[GRL050_MOTOR_OK]
							  FROM [PVTWEB].[dbo].[GRL050_MMM] WITH(NOLOCK)
							) AS MMM ON
					CMMM.[MMM_ID] = MMM.[GRL050_MMM_ID]


-- 2DO INSERTA LOS DATOS NUEVOS
INSERT INTO [SYS-REPLICA].[CalipsoReplicado].[dbo].[JCP_MMM]
           ([MMM_ID]
           ,[MARCA]
           ,[MODELO]
           ,[SUBMODELO]
           ,[MOTOR]
           ,[CANTUTIL]
           ,[MARCA_OK]
           ,[MARCA_ABR]
           ,[MODELO_OK]
           ,[MODELO_ABR]
           ,[SUBMOD_OK]
           ,[SUBMOD_ABR]
           ,[MOTOR_OK])
      (SELECT [GRL050_MMM_ID]
			  ,[GRL050_MARCA]
			  ,[GRL050_MODELO]
			  ,[GRL050_SUBMODELO]
			  ,[GRL050_MOTOR]
			  ,[GRL050_CANTUTIL]
			  ,[GRL050_MARCA_OK]
			  ,[GRL050_MARCA_ABR]
			  ,[GRL050_MODELO_OK]
			  ,[GRL050_MODELO_ABR]
			  ,[GRL050_SUBMOD_OK]
			  ,[GRL050_SUBMOD_ABR]
			  ,[GRL050_MOTOR_OK]
		  FROM [PVTWEB].[dbo].[GRL050_MMM] AS MMM WITH(NOLOCK) 
			LEFT OUTER JOIN (SELECT [MMM_ID]
								FROM [SYS-REPLICA].[CalipsoReplicado].[dbo].[JCP_MMM] WITH(NOLOCK) 
							) AS CMMM ON
					MMM.[GRL050_MMM_ID] = CMMM.[MMM_ID]
		  WHERE [MMM_ID] IS NULL)


-- :::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
UPDATE [PVTWEB].[dbo].[GRL099_ACTREG] SET [GRL099_FECFIN] = CAST(GETDATE() AS DATETIME) WHERE [GRL099_CODID] = @NUEVOIDACT

-- ###################################################################################################################################
-- FIN - ACTCC_PASO 2 -- ACTUALIZA LA TABLA DE CALIPSO - JCP_MMM
-- ###################################################################################################################################

--
--
-- CONSULTAS VARIAS 
--SELECT GRL050_MARCA, GRL050_MODELO, GRL050_SUBMODELO, GRL050_MOTOR, SUM(GRL050_CANTUTIL) AS CANT
--WHERE GRL050_MARCA = 'Renault'
--GROUP BY GRL050_MARCA, GRL050_MODELO, GRL050_SUBMODELO, GRL050_MOTOR
--ORDER BY GRL050_MARCA, GRL050_MODELO, GRL050_SUBMODELO, GRL050_MOTOR
--
--
-- MARCA / MODELO
--SELECT [GRL050_MARCA_OK]
--      ,[GRL050_MARCA_ABR]
--      ,[GRL050_MODELO_OK]
--      ,[GRL050_MODELO_ABR]
--      ,[GRL050_SUBMOD_OK]
--      ,[GRL050_SUBMOD_ABR]
--      ,[GRL050_MOTOR_OK]
--	  ,SUM([GRL050_CANTUTIL]) AS CANT
--  FROM [PVTWEB].[dbo].[GRL050_MMM]
--GROUP BY [GRL050_MARCA_OK]
--      ,[GRL050_MARCA_ABR]
--      ,[GRL050_MODELO_OK]
--ORDER BY [GRL050_MARCA_OK]
--      ,[GRL050_MARCA_ABR]
--      ,[GRL050_MODELO_OK]
--
--
-- MARCA / MOTOR
--SELECT [GRL050_MARCA_OK]
--      ,[GRL050_MARCA_ABR]
--      ,[GRL050_MODELO_OK]
--      ,[GRL050_MODELO_ABR]
--      ,[GRL050_SUBMOD_OK]
--      ,[GRL050_SUBMOD_ABR]
--      ,[GRL050_MOTOR_OK]
--	  ,SUM([GRL050_CANTUTIL]) AS CANT
--  FROM [PVTWEB].[dbo].[GRL050_MMM]
--GROUP BY [GRL050_MARCA_OK]
--      ,[GRL050_MARCA_ABR]
--      ,[GRL050_MOTOR_OK]
--ORDER BY [GRL050_MARCA_OK]
--      ,[GRL050_MARCA_ABR]
--      ,[GRL050_MOTOR_OK]
--
--
--
-- MARCA / MODELO / MOTOR
--SELECT [GRL050_MARCA_OK]
--      ,[GRL050_MARCA_ABR]
--      ,[GRL050_MODELO_OK]
--      ,[GRL050_MODELO_ABR]
--      ,[GRL050_SUBMOD_OK]
--      ,[GRL050_SUBMOD_ABR]
--      ,[GRL050_MOTOR_OK]
--	  ,SUM([GRL050_CANTUTIL]) AS CANT
--  FROM [PVTWEB].[dbo].[GRL050_MMM]
--GROUP BY [GRL050_MARCA_OK]
--      ,[GRL050_MARCA_ABR]
--      ,[GRL050_MODELO_OK]
--	  ,[GRL050_MOTOR_OK]
--ORDER BY [GRL050_MARCA_OK]
--      ,[GRL050_MARCA_ABR]
--      ,[GRL050_MODELO_OK]
--	  ,[GRL050_MOTOR_OK]
--
--
--
-- MARCA / MODELO / SUBMODELO / MOTOR
--SELECT [GRL050_MARCA_OK]
--      ,[GRL050_MARCA_ABR]
--      ,[GRL050_MODELO_OK]
--      ,[GRL050_MODELO_ABR]
--      ,[GRL050_SUBMOD_OK]
--      ,[GRL050_SUBMOD_ABR]
--      ,[GRL050_MOTOR_OK]
--	  ,SUM([GRL050_CANTUTIL]) AS CANT
--  FROM [PVTWEB].[dbo].[GRL050_MMM]
--GROUP BY [GRL050_MARCA_OK]
--      ,[GRL050_MARCA_ABR]
--      ,[GRL050_MODELO_OK]
--	  ,[GRL050_SUBMOD_OK]
--	  ,[GRL050_MOTOR_OK]
--ORDER BY [GRL050_MARCA_OK]
--      ,[GRL050_MARCA_ABR]
--      ,[GRL050_MODELO_OK]
--	  ,[GRL050_SUBMOD_OK]
--	  ,[GRL050_MOTOR_OK]
--
--
