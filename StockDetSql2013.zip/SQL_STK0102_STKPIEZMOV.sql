-- DETALLE DE LOS MESES QUE ESTAN LAS VENTAS
SELECT TOP 100 [STK0203_FECMES]
	  ,CONVERT(NVARCHAR, [STK0203_FECMES], 113) AS FEC
	  ,COUNT(*) AS CANTREG
      ,SUM([STK0203_CANT]) AS CANT
  FROM [PVTWEB].[dbo].[STK0203_PIEZMOV]
GROUP BY [STK0203_FECMES], CONVERT(NVARCHAR, [STK0203_FECMES], 113)
ORDER BY [STK0203_FECMES]

-- TABLA CON LOS MOVIMIENTOS
SELECT TOP 100 [STK0203_FECMES]
      ,[STK0203_PRODID]
      ,[STK0203_REFERID]
      ,[STK0203_REFERDESC]
      ,[STK0203_TIPO_VTA]
      ,[STK0203_CTROCTOS]
      ,[STK0203_VTACARGO]
      ,[STK0203_CANT]
  FROM [PVTWEB].[dbo].[STK0203_PIEZMOV]


--DELETE FROM [PVTWEB].[dbo].[STK0203_PIEZMOV] WHERE [STK0203_FECMES] IS NULL

-- LISTA LAS SUCURSALES Y LOS SECTORES QUE FACTURARON
SELECT TOP 10 UDFC.SUCU, UDFC.SECTOR, COUNT(*) AS CANTFC
FROM (
	SELECT TOP 1000000 UDVTA.*, ITC1.NOMBRE AS SUCU, ITC2.NOMBRE AS SECTOR --, ITC1.*, ITC2.*
	FROM [CalipsoReplicado].[dbo].[UD_FACTURAVENTA_] AS UDVTA 
		LEFT OUTER JOIN [CalipsoReplicado].[dbo].[ITEMTIPOCLASIFICADOR] AS ITC1 WITH (nolock) ON
			UDVTA.Sucursal_ID = ITC1.ID
		LEFT OUTER JOIN [CalipsoReplicado].[dbo].[ITEMTIPOCLASIFICADOR] AS ITC2 WITH (nolock) ON
			UDVTA.TipoVenta_ID = ITC2.ID
	) AS UDFC
WHERE (UDFC.SUCU = 'Tagle - Cordoba' OR UDFC.SUCU = 'Tagle - Rio IV' OR UDFC.SUCU = 'Tagle - Villa Mar�a' OR UDFC.SUCU = 'Nix - Rio IV' OR UDFC.SUCU = 'Nix - Cordoba')
	AND (UDFC.SECTOR = 'Repuestos Tagle' OR UDFC.SECTOR = 'Taller Mecanico Tagle' OR UDFC.SECTOR = 'Taller de Chapa Tagle')
GROUP BY UDFC.SUCU, UDFC.SECTOR
ORDER BY UDFC.SUCU, UDFC.SECTOR


-- Tarda 55 segundos
DECLARE @FechDesde AS DATETIME
DECLARE @FechHasta AS DATETIME
SET @FechDesde = '01/07/2013'	-- DD/MM/YYYY
SET @FechHasta = '31/07/2013'

-- DESDE EL 01/01/2009 ESTA INCORPORADO

SELECT A�o + '/01/' + Mes AS STK0203_FECMES
	, Codigo_Calipso AS STK0203_PRODID
	, Codigo_Referencia AS STK0203_REFERID
	, MIN(Descripcion_Referencia) AS STK0203_REFERDESC
	, Tipo_Venta
	, Centro_Costos
	, cargo
	, SUM(Cantidad) AS CantVend
FROM (
		-- FACTURA DE VENTA
		SELECT TOP 1000000 'Factura Venta' Tipo_Comprobante, 
			fv.NOMBRE AS Comprobante, 
			fv.NUMERODOCUMENTO AS Numero_Factura, 
			fv.NOMBREDESTINATARIO AS Cliente, 
			substring(fv.FECHAACTUAL,1,4) A�o, 
			substring(fv.FECHAACTUAL,5,2) Mes, 
			cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) AS Fecha, 
			itc2.NOMBRE AS Tipo_Venta, 
			itc3.NOMBRE AS Sucursal, 
			p.ID AS Codigo_Calipso,
			p.CODIGO AS Codigo_Referencia, 
			p.DESCRIPCION AS Descripcion_Referencia, 
			p.TipoBienCambio Tipo_Bien_Cambio, 
			p.Rubro,
			p.SubRubro,
			p.Familia,
			p.Tipo Tipo_Referencia,
			ifv.CANTIDAD2_CANTIDAD AS Cantidad, 
			ifv.TOTAL2_IMPORTE TotalVentaNeta, 
			ifv.Valor2_importe*ifv.porcentajebonificacion*ifv.cantidad2_cantidad TotalDescuento,
			isnull(ud2.pucosto*ifv.CANTIDAD2_CANTIDAD*-1,0) TotalCosto,
			ISNULL(itc1.NOMBRE, '') AS cargo, 
			ciu.Nombre Ciudad_Cliente,
			pro.nombre Provincia_Cliente,
			cc.NOMBRE AS Centro_Costos,
			itc4.codigo+' - '+itc4.NOMBRE AS Tipo_Cliente,
			emp.descripcion Vendedor,
			ud3.TeParticular Telefono_particular
		FROM [CalipsoProduccion].[dbo].[TRFACTURAVENTA] AS fv WITH (nolock)		-- [CalipsoProduccion].[dbo].[UD_FACTURAVENTA]
			INNER JOIN [CalipsoProduccion].[dbo].[ITEMFACTURAVENTA] AS ifv WITH (nolock) ON 
				ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID 
			LEFT JOIN [CalipsoProduccion].[dbo].[vp_referencia_] AS p WITH (nolock)ON 
				p.ID = ifv.REFERENCIA_ID 
			INNER JOIN [CalipsoProduccion].[dbo].[UD_ITEMFACTURAVENTA] AS ud2 WITH (nolock) ON 
				ud2.ID = ifv.BOEXTENSION_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc1 WITH (nolock)ON 
				itc1.ID = ud2.Cargo_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[CENTROCOSTOS] AS cc WITH (nolock) ON 
				cc.ID = ifv.CENTROCOSTOS_ID 
			INNER JOIN [CalipsoProduccion].[dbo].[UD_FACTURAVENTA] AS ud1 WITH (nolock) ON 
				ud1.ID = fv.BOEXTENSION_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc2 WITH (nolock) ON 
				itc2.ID = ud1.TipoVenta_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc3 WITH (nolock) ON 
				itc3.ID = ud1.Sucursal_ID
			LEFT JOIN [CalipsoProduccion].[dbo].[cliente] c1 on 
				c1.id=fv.destinatario_id
			LEFT JOIN [CalipsoProduccion].[dbo].[ud_cliente] ud3 on 
				ud3.id=c1.boextension_id
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc4 WITH (nolock) ON 
				itc4.ID = ud3.TipoCliente_ID
			LEFT JOIN [CalipsoProduccion].[dbo].[domicilio] dom on 
				dom.id=c1.domiciliofacturacion_id
			LEFT JOIN [CalipsoProduccion].[dbo].[ciudad] ciu on 
				ciu.id=dom.ciudad_id
			LEFT JOIN [CalipsoProduccion].[dbo].[Provincia] Pro on 
				pro.id=dom.Provincia_id
			LEFT JOIN [CalipsoProduccion].[dbo].[empleado] emp on 
				emp.id=ud1.empleadoVendedor_id
		WHERE fv.ESTADO = 'C'
				AND p.Rubro = '01 - Repuestos'
				AND (itc3.NOMBRE = 'Tagle - Cordoba' OR itc3.NOMBRE = 'Tagle - Rio IV' OR itc3.NOMBRE = 'Tagle - Villa Mar�a' OR itc3.NOMBRE = 'Nix - Rio IV' OR itc3.NOMBRE = 'Nix - Cordoba')
				AND (itc2.NOMBRE = 'Repuestos Tagle' OR itc2.NOMBRE = 'Taller Mecanico Tagle' OR itc2.NOMBRE = 'Taller de Chapa Tagle')
				AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) >= @FechDesde
				AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) <= @FechHasta
		UNION ALL
		-- FACTURA DE VENTA RT
		SELECT TOP 1000000 'Factura Venta RT' Tipo_Comprobante, 
			fv.NOMBRE AS Comprobante, 
			fv.NUMERODOCUMENTO AS Numero_Factura, 
			fv.NOMBREDESTINATARIO AS Cliente, 
			substring(fv.FECHAACTUAL,1,4) A�o, 
			substring(fv.FECHAACTUAL,5,2) Mes, 
			cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) AS Fecha, 
			itc2.NOMBRE AS Tipo_Venta, 
			itc3.NOMBRE AS Sucursal, 
			p.ID AS Codigo_Calipso,
			p.CODIGO AS Codigo_Referencia, 
			p.DESCRIPCION AS Descripcion_Referencia, 
			p.TipoBienCambio Tipo_Bien_Cambio, 
			p.Rubro,
			p.SubRubro,
			p.Familia,
			p.Tipo Tipo_Referencia,
			ifv.CANTIDAD2_CANTIDAD AS Cantidad, 
			ifv.TOTAL2_IMPORTE TotalVentaNeta, 
			ifv.Valor2_importe*ifv.porcentajebonificacion*ifv.cantidad2_cantidad TotalDescuento,
			isnull(ud2.pucosto*ifv.CANTIDAD2_CANTIDAD*-1,0) TotalCosto,
			ISNULL(itc1.NOMBRE, '') AS cargo, 
			ciu.Nombre Ciudad_Cliente,
			pro.nombre Provincia_Cliente,
			cc.NOMBRE AS Centro_Costos,
			itc4.codigo+' - '+itc4.NOMBRE AS Tipo_Cliente,
			emp.descripcion Vendedor,
			ud3.TeParticular Telefono_particular
		FROM [CalipsoProduccion].[dbo].[TRFACTURAVENTA] AS fv WITH (nolock) 
			INNER JOIN [CalipsoProduccion].[dbo].[ITEMFACTURAVENTA] AS ifv WITH (nolock) ON 
				ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID 
			LEFT JOIN [CalipsoProduccion].[dbo].[vp_referencia_] AS p WITH (nolock)ON 
				p.ID = ifv.REFERENCIA_ID 
			INNER JOIN [CalipsoProduccion].[dbo].[UD_ITEMFACTURART] AS ud2 WITH (nolock) ON 
				ud2.ID = ifv.BOEXTENSION_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc1 WITH (nolock)ON 
				itc1.ID = ud2.Cargo_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[CENTROCOSTOS] AS cc WITH (nolock) ON 
				cc.ID = ifv.CENTROCOSTOS_ID 
			INNER JOIN [CalipsoProduccion].[dbo].[UD_FACTURAVENTART] AS ud1 WITH (nolock) ON 
				ud1.ID = fv.BOEXTENSION_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc2 WITH (nolock) ON 
				itc2.ID = ud1.TipoVenta_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc3 WITH (nolock) ON 
				itc3.ID = ud1.Sucursal_ID
			LEFT JOIN [CalipsoProduccion].[dbo].[cliente] c1 on 
				c1.id=fv.destinatario_id
			LEFT JOIN [CalipsoProduccion].[dbo].[ud_cliente] ud3 on 
				ud3.id=c1.boextension_id
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc4 WITH (nolock) ON 
				itc4.ID = ud3.TipoCliente_ID
			LEFT JOIN [CalipsoProduccion].[dbo].[domicilio] dom on 
				dom.id=c1.domiciliofacturacion_id
			LEFT JOIN [CalipsoProduccion].[dbo].[ciudad] ciu on 
				ciu.id=dom.ciudad_id
			LEFT JOIN [CalipsoProduccion].[dbo].[Provincia] Pro on 
				pro.id=dom.Provincia_id
			LEFT JOIN [CalipsoProduccion].[dbo].[empleado] emp on 
				emp.id=ud1.empleadoVendedor_id
		WHERE fv.ESTADO = 'C' 
				AND p.Rubro = '01 - Repuestos'
				AND (itc3.NOMBRE = 'Tagle - Cordoba' OR itc3.NOMBRE = 'Tagle - Rio IV' OR itc3.NOMBRE = 'Tagle - Villa Mar�a' OR itc3.NOMBRE = 'Nix - Rio IV' OR itc3.NOMBRE = 'Nix - Cordoba')
				AND (itc2.NOMBRE = 'Repuestos Tagle' OR itc2.NOMBRE = 'Taller Mecanico Tagle' OR itc2.NOMBRE = 'Taller de Chapa Tagle')
				AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) >= @FechDesde
				AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) <= @FechHasta
		UNION ALL
		-- NOTA DE CREDITO DE VENTA
		SELECT TOP 1000000 'Nota Credito Venta' Tipo_Comprobante, 
			fv.NOMBRE AS Comprobante, 
			fv.NUMERODOCUMENTO AS Numero_Factura, 
			fv.NOMBREDESTINATARIO AS Cliente, 
			substring(fv.FECHAACTUAL,1,4) A�o, 
			substring(fv.FECHAACTUAL,5,2) Mes, 
			cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) AS Fecha, 
			itc2.NOMBRE AS Tipo_Venta, 
			itc3.NOMBRE AS Sucursal,
			p.ID AS Codigo_Calipso, 
			p.CODIGO AS Codigo_Referencia, 
			p.DESCRIPCION AS Descripcion_Referencia, 
			p.TipoBienCambio Tipo_Bien_Cambio, 
			p.Rubro,
			p.SubRubro,
			p.Familia,
			p.Tipo Tipo_Referencia,
			ifv.CANTIDAD2_CANTIDAD*-1 AS Cantidad, 
			ifv.TOTAL2_IMPORTE*-1 TotalVentaNeta, 
			ifv.Valor2_importe*ifv.porcentajebonificacion*ifv.cantidad2_cantidad*-1 TotalDescuento,
			isnull(ud2.pucosto*ifv.CANTIDAD2_CANTIDAD*-1,0) Costo,
			ISNULL(itc1.NOMBRE, '') AS cargo, 
			ciu.Nombre Ciudad_Cliente,
			pro.nombre Provincia_Cliente,
			cc.NOMBRE AS Centro_Costos,
			itc4.codigo+' - '+itc4.NOMBRE AS Tipo_Cliente,
			emp.descripcion Vendedor,
			ud3.TeParticular Telefono_particular
		FROM [CalipsoProduccion].[dbo].[TRCREDITOVENTA] AS fv WITH (nolock) 
			INNER JOIN [CalipsoProduccion].[dbo].[ITEMCREDITOVENTA] AS ifv WITH (nolock) ON 
				ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID 
			LEFT JOIN [CalipsoProduccion].[dbo].[vp_referencia_] AS p WITH (nolock)ON 
				p.ID = ifv.REFERENCIA_ID 
			INNER JOIN [CalipsoProduccion].[dbo].[UD_ITEMCREDITOVENTA] AS ud2 WITH (nolock) ON 
				ud2.ID = ifv.BOEXTENSION_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc1 WITH (nolock)ON 
				itc1.ID = ud2.Cargo_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[CENTROCOSTOS] AS cc WITH (nolock) ON 
				cc.ID = ifv.CENTROCOSTOS_ID 
			INNER JOIN [CalipsoProduccion].[dbo].[UD_NOTACREDITOVENTA] AS ud1 WITH (nolock) ON 
				ud1.ID = fv.BOEXTENSION_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc2 WITH (nolock) ON 
				itc2.ID = ud1.TipoVenta_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc3 WITH (nolock) ON 
				itc3.ID = ud1.Sucursal_ID
			LEFT JOIN [CalipsoProduccion].[dbo].[cliente] c1 on 
				c1.id=fv.destinatario_id
			LEFT JOIN [CalipsoProduccion].[dbo].[ud_cliente] ud3 on 
				ud3.id=c1.boextension_id
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc4 WITH (nolock) ON 
				itc4.ID = ud3.TipoCliente_ID
			LEFT JOIN [CalipsoProduccion].[dbo].[domicilio] dom on 
				dom.id=c1.domiciliofacturacion_id
			LEFT JOIN [CalipsoProduccion].[dbo].[ciudad] ciu on 
				ciu.id=dom.ciudad_id
			LEFT JOIN [CalipsoProduccion].[dbo].[Provincia] Pro on 
				pro.id=dom.Provincia_id
			LEFT JOIN [CalipsoProduccion].[dbo].[empleado] emp on 
				emp.id=ud1.empleadoVendedor_id
		WHERE fv.ESTADO = 'C' 
				AND p.Rubro = '01 - Repuestos'
				AND (itc3.NOMBRE = 'Tagle - Cordoba' OR itc3.NOMBRE = 'Tagle - Rio IV' OR itc3.NOMBRE = 'Tagle - Villa Mar�a' OR itc3.NOMBRE = 'Nix - Rio IV' OR itc3.NOMBRE = 'Nix - Cordoba')
				AND (itc2.NOMBRE = 'Repuestos Tagle' OR itc2.NOMBRE = 'Taller Mecanico Tagle' OR itc2.NOMBRE = 'Taller de Chapa Tagle')
				AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) >= @FechDesde
				AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) <= @FechHasta
		UNION ALL
		-- NOTA DE DEBITO DE VENTA
		SELECT TOP 1000000 'Nota Debito Venta' Tipo_Comprobante, 
			fv.NOMBRE AS Comprobante, 
			fv.NUMERODOCUMENTO AS Numero_Factura, 
			fv.NOMBREDESTINATARIO AS Cliente, 
			substring(fv.FECHAACTUAL,1,4) A�o, 
			substring(fv.FECHAACTUAL,5,2) Mes, 
			cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) AS Fecha, 
			itc2.NOMBRE AS Tipo_Venta, 
			itc3.NOMBRE AS Sucursal,
			p.ID AS Codigo_Calipso,
			p.CODIGO AS Codigo_Referencia, 
			p.DESCRIPCION AS Descripcion_Referencia, 
			p.TipoBienCambio Tipo_Bien_Cambio, 
			p.Rubro,
			p.SubRubro,
			p.Familia,
			p.Tipo Tipo_Referencia,
			ifv.CANTIDAD2_CANTIDAD AS Cantidad, 
			ifv.TOTAL2_IMPORTE TotalVentaNeta, 
			ifv.Valor2_importe*ifv.porcentajebonificacion*ifv.cantidad2_cantidad TotalDescuento,
			isnull(ud2.pucosto*ifv.CANTIDAD2_CANTIDAD,0) Costo,
			ISNULL(itc1.NOMBRE, '') AS cargo, 
			ciu.Nombre Ciudad_Cliente,
			pro.nombre Provincia_Cliente,
			cc.NOMBRE AS Centro_Costos,
			itc4.codigo+' - '+itc4.NOMBRE AS Tipo_Cliente,
			emp.descripcion Vendedor,
			ud3.TeParticular Telefono_particular
		FROM [CalipsoProduccion].[dbo].[TRdebitoVENTA] AS fv WITH (nolock) 
			INNER JOIN [CalipsoProduccion].[dbo].[ITEMDEBITOVENTA] AS ifv WITH (nolock) ON 
				ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID 
			left JOIN [CalipsoProduccion].[dbo].[vp_referencia_] AS p WITH (nolock)ON 
				p.ID = ifv.REFERENCIA_ID 
			inner JOIN [CalipsoProduccion].[dbo].[UD_ITEMDEBITOVENTA] AS ud2 WITH (nolock) ON 
				ud2.ID = ifv.BOEXTENSION_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc1 WITH (nolock)ON 
				itc1.ID = ud2.Cargo_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[CENTROCOSTOS] AS cc WITH (nolock) ON 
				cc.ID = ifv.CENTROCOSTOS_ID 
			inner JOIN [CalipsoProduccion].[dbo].[UD_NOTADEBITOVENTA] AS ud1 WITH (nolock) ON 
				ud1.ID = fv.BOEXTENSION_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc2 WITH (nolock) ON 
				itc2.ID = ud1.TipoVenta_ID 
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc3 WITH (nolock) ON 
				itc3.ID = ud1.Sucursal_ID
			left join [CalipsoProduccion].[dbo].[cliente] c1 on 
				c1.id=fv.destinatario_id
			left join [CalipsoProduccion].[dbo].[ud_cliente] ud3 on 
				ud3.id=c1.boextension_id
			LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc4 WITH (nolock) ON 
				itc4.ID = ud3.TipoCliente_ID
			left join [CalipsoProduccion].[dbo].[domicilio] dom on 
				dom.id=c1.domiciliofacturacion_id
			left join [CalipsoProduccion].[dbo].[ciudad] ciu on 
				ciu.id=dom.ciudad_id
			left join [CalipsoProduccion].[dbo].[Provincia] Pro on 
				pro.id=dom.Provincia_id
			left join [CalipsoProduccion].[dbo].[empleado] emp on 
				emp.id=ud1.empleadoVendedor_id
		WHERE fv.ESTADO = 'C' 
				AND p.Rubro = '01 - Repuestos'
				AND (itc3.NOMBRE = 'Tagle - Cordoba' OR itc3.NOMBRE = 'Tagle - Rio IV' OR itc3.NOMBRE = 'Tagle - Villa Mar�a' OR itc3.NOMBRE = 'Nix - Rio IV' OR itc3.NOMBRE = 'Nix - Cordoba')
				AND (itc2.NOMBRE = 'Repuestos Tagle' OR itc2.NOMBRE = 'Taller Mecanico Tagle' OR itc2.NOMBRE = 'Taller de Chapa Tagle')
				AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) >= @FechDesde
				AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) <= @FechHasta
	) AS FDC
GROUP BY A�o + '/01/' + Mes
	, Codigo_Calipso
	, Codigo_Referencia
	, Tipo_Venta
	, Centro_Costos
	, cargo
ORDER BY A�o + '/01/' + Mes
	, Codigo_Calipso



-- AHORA HAY QUE IMPORTAR LOS DATOS A LA BASE
-- DETALLE DE LOS MESES QUE ESTAN LAS VENTAS
SELECT TOP 100 [STK0203_FECMES]
	  ,CONVERT(NVARCHAR, [STK0203_FECMES], 113) AS FEC
	  ,COUNT(*) AS CANTREG
      ,SUM([STK0203_CANT]) AS CANT
  FROM [PVTWEB].[dbo].[STK0203_PIEZMOV]
GROUP BY [STK0203_FECMES], CONVERT(NVARCHAR, [STK0203_FECMES], 113)
ORDER BY [STK0203_FECMES]

-- BORRA LAS FILAS DEL MES QUE SE VA A INCORPORAR
SELECT COUNT(*), SUM([STK0203_CANT]) AS TOTAL
--DELETE
FROM [PVTWEB].[dbo].[STK0203_PIEZMOV] 
WHERE CONVERT(NVARCHAR, [STK0203_FECMES], 113) = '01 Jul 2013 00:00:00:000'
