-- ########################################################################################################################################
-- INICIO -- TRAZABILIDAD
-- ########################################################################################################################################
SELECT     ot.Nombre AS OT, itc2.nombre AS Sucursal, ot.Estado, cli.denominacion AS Cliente, cli2.denominacion AS Cliente_A_Facturar, 
                      CASE WHEN ud2.teparticular = '' THEN ud2.telaboral ELSE CASE WHEN ud2.telaboral = '' THEN ud2.celular ELSE CASE WHEN ud2.celular = '' THEN ud2.teparticular
                       ELSE ud.telcontacto END END END AS Telefono, ud3.Dominio, ud3.numerovin AS VIN, ud3.Marca, ud3.Modelo, itc.codigo + ' - ' + itc.nombre AS Cargo, 
                      pf.nombre AS Receptor, PF2.NOMBRE AS Mecanico, PROD.CODIGO AS Numero_Pieza, PROD.DESCRIPCION, iot.cantidad2_cantidad AS Cantidad, 
                      ud5.numeropedidofabrica AS Numero_Pedido_Fabrica, substring(ot.fechaactual, 7, 2) + '/' + substring(ot.fechaactual, 5, 2) 
                      + '/' + substring(ot.fechaactual, 1, 4) AS Fecha_Solicitud, substring(oc.fechaactual, 7, 2) + '/' + substring(oc.fechaactual, 5, 2) 
                      + '/' + substring(oc.fechaactual, 1, 4) AS Fecha_Pedido, OC.Numerodocumento AS Orden_Compra, oc.usuario AS Gestionado_por, 
                      Substring(ud5.fechaestimadaingreso, 7, 2) + '/' + substring(ud5.fechaestimadaingreso, 5, 2) + '/' + substring(ud5.fechaestimadaingreso, 1, 4) 
                      AS Ingreso_Estimado, substring(tri.fechaentrega, 7, 2) + '/' + substring(tri.fechaentrega, 5, 2) + '/' + substring(tri.fechaentrega, 1, 4) AS Fecha_ingreso, 
                      tri.nombredestinatario AS Deposito_Remito, datediff(day, cast(substring(tri.fechaentrega, 7, 2) + '/' + substring(tri.fechaentrega, 5, 2) 
                      + '/' + substring(tri.fechaentrega, 1, 4) AS datetime), getdate()) AS Dias_Transcurridos, substring(ud.fechahoraturno, 7, 2) 
                      + '/' + substring(ud.fechahoraturno, 5, 2) + '/' + substring(ud.fechahoraturno, 1, 4) + ' ' + substring(ud.fechahoraturno, 9, 2) 
                      + ':' + substring(ud.fechahoraturno, 11, 2) AS Turno, substring(hf.fecha, 7, 2) + '/' + substring(hf.fecha, 5, 2) + '/' + substring(hf.fecha, 1, 4) 
                      + ' ' + substring(hf.fecha, 9, 2) + ':' + substring(hf.fecha, 11, 2) AS Fecha_Entrega_Cliente, ud.avisocliente AS AvisoCliente, ud.Observaciones, 
                      rec.nombre AS Recurso, substring(rec.fechaactual, 7, 2) + '/' + substring(rec.fechaactual, 5, 2) + '/' + substring(rec.fechaactual, 1, 4) AS Fecha_Recurso, 
                      ud.Diagnostico, tri.nombre AS Remito, substring(rrr.fechaentrega, 7, 2) + '/' + substring(rrr.fechaentrega, 5, 2) + '/' + substring(rrr.fechaentrega, 1, 4) 
                      AS Fecha_Devolucion, rrr.nombre AS Devolucion, pf.nombre AS Agente, CASE WHEN udirg.reconocido = 'T' THEN 'Si' ELSE 'No' END AS Resolucion, 
                      RRR2.NOTA AS 'Causa Devolucion', substring(rrr.fechaentrega, 7, 2) + '/' + substring(rrr.fechaentrega, 5, 2) + '/' + substring(rrr.fechaentrega, 1, 4) 
                      AS Fecha_Envio, VE.VEP AS Vale_Entrega, substring(VE.FECHAVALE, 7, 2) + '/' + substring(VE.FECHAVALE, 5, 2) + '/' + substring(VE.FECHAVALE, 1, 4) 
                      AS Fecha_Envio_Agente, substring(irr.fechaentrega, 7, 2) + '/' + substring(irr.fechaentrega, 5, 2) + '/' + substring(irr.fechaentrega, 1, 4) 
                      AS Fecha_Recepcion_Reemplazo_Agente, fvov.nombre AS Factura_Renault, substring(fvov.fechaentrega, 7, 2) + '/' + substring(fvov.fechaentrega, 5, 2) 
                      + '/' + substring(fvov.fechaentrega, 1, 4) AS Fecha_Factura_Renault
FROM trordenventa OT WITH (nolock) 
	INNER JOIN itemordenventa IOT WITH (nolock) ON 
		IOT.placeowner_id = OT.id 
	INNER JOIN PRODUCTO PROD WITH (NOLOCK) ON 
		IOT.REFERENCIA_ID = PROD.ID 
	LEFT JOIN ud_itemordentrabajo udiot WITH (nolock) ON 
		iot.boextension_id = udiot.id 
	LEFT JOIN UD_OrdenTrabajo ud WITH (nolock) ON 
		ud.id = ot.boextension_id 
	LEFT JOIN itemtipoclasificador itc WITH (nolock) ON 
		itc.id = ud.cargo_id 
	LEFT JOIN itemtipoclasificador itc2 WITH (nolock) ON 
		ud.sucursal_id = itc2.id 
	LEFT JOIN empleado e WITH (nolock) ON 
		e.id = ud.receptor_id 
	LEFT JOIN personafisica pf WITH (nolock) ON 
		pf.id = e.enteasociado_id 
	LEFT JOIN cliente cli WITH (nolock) ON 
		cli.id = ot.destinatario_id 
	LEFT JOIN ud_cliente ud2 WITH (nolock) ON 
		ud2.id = cli.boextension_id 
	LEFT JOIN cliente cli2 WITH (nolock) ON 
		cli2.id = ud.clientefacturar_id 
	LEFT JOIN producto pro2 WITH (nolock) ON 
		pro2.id = ud.vehiculo_id 
	LEFT JOIN ud_producto ud3 WITH (nolock) ON 
		ud3.id = pro2.boextension_id 
	LEFT JOIN UD_ITEMORDENCOMPRA ud4 WITH (nolock) ON 
		ud4.itemordentrabajo_id = iot.id 
	LEFT JOIN itemordencompra IOC WITH (nolock) ON 
		IOC.id = ud4.bo_owner_id 
	LEFT JOIN trordencompra OC WITH (nolock) ON 
		oc.id = IOC.placeowner_id 
	LEFT JOIN UD_DEPOSITO ud5 WITH (nolock) ON 
		ud5.id = oc.boextension_id 
	LEFT JOIN ud_remitocompra ud6 WITH (nolock) ON 
		ud6.itemordentrabajo_id = iot.id 
	LEFT JOIN itemingresoinventario ii WITH (nolock) ON 
		ii.id = ud6.bo_owner_id 
	LEFT JOIN tringresoinventario tri WITH (nolock) ON 
		tri.id = ii.placeowner_id 
	LEFT JOIN TRPROCESOPORLOTE TRPRO WITH (NOLOCK) ON 
		ot.ID = TRPRO.TRANSACCION_ID 
			AND 
		trpro.relacion_id = '9090399B-EF8B-400E-BA0D-5A7F5F455D1F' 
	LEFT JOIN AGENTEPROCESOPORLOTE PRO WITH (NOLOCK) ON 
		PRO.TRSORIGEN_ID = TRPRO.BO_PLACE_ID 
			AND 
		pro.relacionorigen_id = '9090399B-EF8B-400E-BA0D-5A7F5F455D1F' 
	LEFT JOIN trordenventa rec WITH (NOLOCK) ON 
		PRO.ID = rec.GENERADAPOR_ID 
			AND 
		rec.tipotransaccion_id = '1EA8D57C-97B7-4EB7-82AD-62A59AB84030' 
	LEFT JOIN ud_recursogarantia ud7 WITH (nolock) ON 
		ud7.id = rec.boextension_id 
	LEFT JOIN historyflag hf WITH (nolock) ON 
		ot.id = hf.obj_id 
			AND 
		hf.transicion_id = '24AB7086-1CDF-4045-974C-75331C386936' 
-- RELACION CON ITEM REMITO REPUESTOS REEMP
	LEFT JOIN UD_ITEMREMITOREPUESTOSREEMP udirr WITH (nolock) ON 
		ot.id = udirr.ordentrabajo_id 
	LEFT JOIN itemegresoinventario iei WITH (nolock) ON 
		udirr.bo_owner_id = iei.id 
	LEFT JOIN tregresoinventario rrr WITH (nolock) ON 
		iei.placeowner_id = rrr.id 
	LEFT JOIN ITEMORDENVENTA IRG WITH (NOLOCK) ON 
		REC.ID = IRG.PLACEOWNER_ID 
			AND 
		IRG.REFERENCIA_ID = IOT.REFERENCIA_ID 
	LEFT JOIN UD_ITEMRECURSOGARANTIA UDIRG WITH (NOLOCK) ON 
		IRG.BOEXTENSION_ID = UDIRG.ID 
	LEFT JOIN
BOLIST BO WITH (NOLOCK) ON UD.MECANICOS_ID = BO.ID LEFT JOIN
PERSLIST PER WITH (NOLOCK) ON BO.BO_ITEMS_ID = PER.ID LEFT JOIN
EMPLEADO EMP WITH (NOLOCK) ON PER.ITEM_ID = EMP.ID LEFT JOIN
PERSONAFISICA PF2 WITH (NOLOCK) ON EMP.ENTEASOCIADO_ID = PF2.ID LEFT JOIN
ITEMEGRESOINVENTARIO IRR2 WITH (NOLOCK) ON IOT.REFERENCIA_ID = IRR2.REFERENCIATIPO_ID AND 
IRR2.TIPOTRANSACCION_ID = '3BE2F909-F426-4422-82B7-4DCD0B2D5BC6' LEFT JOIN
UD_ITEMREMITOREPUESTOSREEMP UDIRR2 WITH (NOLOCK) ON IRR2.BOEXTENSION_ID = UDIRR2.ID LEFT JOIN
TREGRESOINVENTARIO RRR2 WITH (NOLOCK) ON IRR2.PLACEOWNER_ID = RRR2.ID OUTER APPLY
  (SELECT     VEP.ID AS ID, VEP.NOMBRE AS VEP, VEP.FECHAENTREGA AS FECHAVALE, UDVEP.ORDENTRABAJO_ID AS IDOT, 
                           IVEP.REFERENCIATIPO_ID AS IDPROD
    FROM          TREGRESOINVENTARIO VEP WITH (NOLOCK) LEFT JOIN
                           ITEMEGRESOINVENTARIO IVEP WITH (NOLOCK) ON VEP.ID = IVEP.PLACEOWNER_ID LEFT JOIN
                           UD_VALEENTREGAPIEZAS UDVEP WITH (NOLOCK) ON VEP.BOEXTENSION_ID = UDVEP.ID LEFT JOIN
                           UD_VALEDEVOLUCION UDVDP WITH (NOLOCK) ON VEP.ID = UDVDP.VALEENTREGA_ID LEFT JOIN
                           TRINGRESOINVENTARIO VDP WITH (NOLOCK) ON UDVDP.ID = VDP.BOEXTENSION_ID
    WHERE      VEP.TIPOTRANSACCION_ID = 'CF40D42F-F93A-4FF4-AB4C-0513E281942D' AND UDVDP.VALEENTREGA_ID IS NULL AND 
                           UDVEP.ORDENTRABAJO_ID = OT.ID AND IVEP.REFERENCIATIPO_ID = IOT.REFERENCIA_ID) AS VE LEFT JOIN
TRPROCESOPORLOTE TRPROLOTE WITH (NOLOCK) ON ve.ID = TRPROLOTE.TRANSACCION_ID AND 
TRPROLOTE.relacion_id = '6A3ED97E-202B-4B6A-B1C6-AB292F597F58' LEFT JOIN
AGENTEPROCESOPORLOTE PROLOTE WITH (NOLOCK) ON PROLOTE.TRSORIGEN_ID = TRPROLOTE.BO_PLACE_ID AND 
PROLOTE.relacionorigen_id = '6A3ED97E-202B-4B6A-B1C6-AB292F597F58' LEFT JOIN
tringresoinventario irr WITH (NOLOCK) ON PROLOTE.ID = irr.GENERADAPOR_ID AND 
irr.tipotransaccion_id = 'D761A22B-B506-4E63-8F5F-F268A1D7AEDD' LEFT JOIN
TRPROCESOPORLOTE TRPROLOTE2 WITH (NOLOCK) ON REC.ID = TRPROLOTE2.TRANSACCION_ID AND 
TRPROLOTE2.relacion_id = '922C5AD1-9745-4EBF-91BB-EED6FCCD34D2' LEFT JOIN
AGENTEPROCESOPORLOTE PROLOTE2 WITH (NOLOCK) ON PROLOTE2.TRSORIGEN_ID = TRPROLOTE2.BO_PLACE_ID AND 
PROLOTE2.relacionorigen_id = '922C5AD1-9745-4EBF-91BB-EED6FCCD34D2' LEFT JOIN
TRFACTURAVENTA FVOV WITH (NOLOCK) ON PROLOTE2.ID = FVOV.GENERADAPOR_ID AND 
FVOV.tipotransaccion_id = '21D226BB-8539-451A-879B-B233BF099E17' AND ot.estado <> 'N'












SELECT TOP 10 *
FROM [ERPSERVER].[CalipsoProduccion].[dbo].[TRORDENVENTA] AS OT WITH (nolock) 
	-- RELACION CON ITEM REMITO REPUESTOS REEMP
	LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[UD_ITEMREMITOREPUESTOSREEMP] AS UDIRR WITH (nolock) ON 
		OT.[ID] = UDIRR.[ORDENTRABAJO_ID]
		-- ESTO RELACIONA, DE LA TABLA [ITEM REMITO REPUESTOS REEMP], A LA TABLA [ITEM EGREOS INVENTARIO]
		LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[ITEMEGRESOINVENTARIO] AS IEI WITH (nolock) ON 
			UDIRR.[BO_OWNER_ID] = IEI.ID 
			-- ESTO RELACIONA LA TABLA [ITEM EGRESO INVENTARIO] A LA TABLA [TR EGREGO INVENTARIO]
			LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[TREGRESOINVENTARIO] AS TEI WITH (nolock) ON 
				IEI.[PLACEOWNER_ID] = TEI.[ID] 
				-- ESTO RELACIONA LA TABLA [TR EGREGO INVENTARIO] A LA TABLA [VALE ENTREGA PIEZAS]
				LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[UD_VALEENTREGAPIEZAS] AS UDP WITH (nolock) ON 
					TEI.BOEXTENSION_ID=UDP.ID
WHERE OT.NUMERODOCUMENTO='6333'


SELECT TOP 10 * 
FROM [ERPSERVER].[CalipsoProduccion].[dbo].[TREGRESOINVENTARIO]AS TEI WITH (nolock)  
	INNER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[UD_VALEENTREGAPIEZAS] AS UDP WITH (nolock) ON 
		TEI.BOEXTENSION_ID=UDP.ID
	INNER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[TRORDENVENTA] AS OT WITH (nolock) ON 
		UDP.ORDENTRABAJO_ID=OT.ID
WHERE OT.NUMERODOCUMENTO='6333'


DECLARE @PROD_ID AS NVARCHAR(50)
DECLARE @PROD_COD AS NVARCHAR(20)
DECLARE @DEP_ID1 AS NVARCHAR(50)
DECLARE @UBI_ID1 AS NVARCHAR(50)
DECLARE @DEP_ID2 AS NVARCHAR(50)
DECLARE @UBI_ID2 AS NVARCHAR(50)
DECLARE @DEP_ID3 AS NVARCHAR(50)
DECLARE @UBI_ID3 AS NVARCHAR(50)

SET @PROD_ID = ''	-- {F41F419A-DC57-4FDA-966A-8287533853E1}
SET @PROD_COD = '8200840770 I'		--7700274177 I	0225244664 alfombras
SET @DEP_ID1 = 'B9EF3D86-DCFA-46EC-BB41-59BFCF94662B'	-- Deposito Comercial Cordoba
SET @UBI_ID1 = 'B8753321-5C5E-4A64-BEBC-A91204FA63F1'	-- UBICACI�N UNICA

SET @DEP_ID2 = 'FB512A71-3225-4140-B3FE-A1893C95630B'	-- Deposito Garantia Cordoba
SET @UBI_ID2 = '5D2C47C5-FFA4-4010-8F3E-E369C90DBE87'	-- UBICACI�N UNICA

SET @DEP_ID3 = 'C02692AE-BA47-4C3F-9639-85DD0396D152'	-- Deposito Garantia Cordoba
SET @UBI_ID3 = '138A01B4-6F83-48C1-AE79-A80A8FA2025F'	-- UBICACI�N UNICA

SELECT TOP 10000 referenciatipo_id AS PRODUCTO_ID
					, INV.NOMBREREFERENCIA
					, INV.DESCRIPCION
	--				, INV.FECHADOCUMENTO
					, SUBSTRING(INV.FECHADOCUMENTO,7,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,5,2) + '/' + SUBSTRING(INV.FECHADOCUMENTO,0,5) AS FECHA_DOCUM
	----				, INV.FECHAINV
	--				, SUBSTRING(INV.FECHAINV,7,2) + '/' + SUBSTRING(INV.FECHAINV,5,2) + '/' + SUBSTRING(INV.FECHAINV,0,5) AS FECHA_INV
	----				, INV.FECHAVEN
	--				, SUBSTRING(INV.FECHAVEN,7,2) + '/' + SUBSTRING(INV.FECHAVEN,5,2) + '/' + SUBSTRING(INV.FECHAVEN,0,5) AS FECHA_VTO
	--				, INV.FECHAENTREGA
					, SUBSTRING(INV.FECHAENTREGA,7,2) + '/' + SUBSTRING(INV.FECHAENTREGA,5,2) + '/' + SUBSTRING(INV.FECHAENTREGA,0,5) AS FECHA_ENTREGA
					, INV.NOMBRETR AS TRANSAC_DOCUM
					, INV.NUMERODOCUMENTO AS TRANSAC_NUMDOC
					, INV.NUMEROITEM AS TRANSAC_NUMITEM
					, ALIAS_1.NOMBRE AS DEP_NOMB
	--				, INV.[DEPOSITODES_ID]
					, ALIAS_2.NOMBRE AS UBI_NOMB
	--				, INV.[UBICACIONDES_ID]
	--				, INV.[ESTADOTR] AS TRANSAC_ESTA
					, INV.BULTOS
					, cantidad2_cantidad AS CANTIDAD
					, valor2_importe AS COSTO
					, cantidad2_cantidad * valor2_importe AS TOTAL 
	--				, INV.MOMENTOTR
					, SUBSTRING(INV.MOMENTOTR,7,2) + '/' + SUBSTRING(INV.MOMENTOTR,5,2) + '/' + SUBSTRING(INV.MOMENTOTR,0,5) AS TRANSAC_FECHA
					, INV.NOMBREORIGINANTETR AS TRANSAC_ORIGINANTE
					, INV.NOMBREDESTINATARIOTR AS TRANSAC_DESTINATARIO
	--				, INV.*
--select top 100 *
			  FROM [ERPSERVER].[CalipsoProduccion].[dbo].[itemingresoinventario] AS INV
				LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[V_DEPOSITO_] ALIAS_1 ON 
					INV.[DEPOSITODES_ID] = ALIAS_1.ID   
				LEFT OUTER JOIN [ERPSERVER].[CalipsoProduccion].[dbo].[V_UBICACION_] ALIAS_2 ON 
					INV.[UBICACIONDES_ID] = ALIAS_2.ID 
			  WHERE ((ALIAS_1.[UBICACIONES_ID] = @DEP_ID1 AND ALIAS_2.[ID] = @UBI_ID1) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID2 AND ALIAS_2.[ID] = @UBI_ID2) OR (ALIAS_1.[UBICACIONES_ID] = @DEP_ID3 AND ALIAS_2.[ID] = @UBI_ID3))
					AND [ESTADOTR] = 'C' 
					AND (CAST([REFERENCIATIPO_ID] AS NVARCHAR(50)) = @PROD_ID OR INV.NOMBREREFERENCIA = @PROD_COD)

