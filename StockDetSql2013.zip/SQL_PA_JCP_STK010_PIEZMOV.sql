-- ================================================
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:	Juan Carlos Petri
-- Create date: 18/07/2013
-- Description:	Movimiento de piezas de repuestos
-- =============================================
CREATE PROCEDURE [dbo].[JCP_STK010_PIEZMOV]
	-- Add the parameters for the stored procedure here
	@FechDesde AS DATETIME
	@FechHasta AS DATETIME
AS
BEGIN

DECLARE @FechDesde AS DATETIME
DECLARE @FechHasta AS DATETIME
SET @FechDesde = '01/01/2013'
SET @FechHasta = '31/08/2013'

	SELECT A�o + '/' + Mes + '/01' AS STK0203_FECMES
		, Codigo_Calipso AS STK0203_PRODID
		, Codigo_Referencia AS STK0203_REFERID
		, MIN(Descripcion_Referencia) AS STK0203_REFERDESC
		, Tipo_Venta
		, Centro_Costos
		, cargo
		, SUM(Cantidad) AS CantVend
	FROM (
			-- FACTURA DE VENTA
			SELECT TOP 1000000 'Factura Venta' Tipo_Comprobante, 
				fv.NOMBRE AS Comprobante, 
				fv.NUMERODOCUMENTO AS Numero_Factura, 
				fv.NOMBREDESTINATARIO AS Cliente, 
				substring(fv.FECHAACTUAL,1,4) A�o, 
				substring(fv.FECHAACTUAL,5,2) Mes, 
				cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) AS Fecha, 
				itc2.NOMBRE AS Tipo_Venta, 
				itc3.NOMBRE AS Sucursal, 
				p.ID AS Codigo_Calipso,
				p.CODIGO AS Codigo_Referencia, 
				p.DESCRIPCION AS Descripcion_Referencia, 
				p.TipoBienCambio Tipo_Bien_Cambio, 
				p.Rubro,
				p.SubRubro,
				p.Familia,
				p.Tipo Tipo_Referencia,
				ifv.CANTIDAD2_CANTIDAD AS Cantidad, 
				ifv.TOTAL2_IMPORTE TotalVentaNeta, 
				ifv.Valor2_importe*ifv.porcentajebonificacion*ifv.cantidad2_cantidad TotalDescuento,
				isnull(ud2.pucosto*ifv.CANTIDAD2_CANTIDAD*-1,0) TotalCosto,
				ISNULL(itc1.NOMBRE, '') AS cargo, 
				ciu.Nombre Ciudad_Cliente,
				pro.nombre Provincia_Cliente,
				cc.NOMBRE AS Centro_Costos,
				itc4.codigo+' - '+itc4.NOMBRE AS Tipo_Cliente,
				emp.descripcion Vendedor,
				ud3.TeParticular Telefono_particular
			FROM [CalipsoProduccion].[dbo].[TRFACTURAVENTA] AS fv WITH (nolock)		-- [CalipsoProduccion].[dbo].[UD_FACTURAVENTA]
				INNER JOIN [CalipsoProduccion].[dbo].[ITEMFACTURAVENTA] AS ifv WITH (nolock) ON 
					ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID 
				LEFT JOIN [CalipsoProduccion].[dbo].[vp_referencia_] AS p WITH (nolock)ON 
					p.ID = ifv.REFERENCIA_ID 
				INNER JOIN [CalipsoProduccion].[dbo].[UD_ITEMFACTURAVENTA] AS ud2 WITH (nolock) ON 
					ud2.ID = ifv.BOEXTENSION_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc1 WITH (nolock)ON 
					itc1.ID = ud2.Cargo_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[CENTROCOSTOS] AS cc WITH (nolock) ON 
					cc.ID = ifv.CENTROCOSTOS_ID 
				INNER JOIN [CalipsoProduccion].[dbo].[UD_FACTURAVENTA] AS ud1 WITH (nolock) ON 
					ud1.ID = fv.BOEXTENSION_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc2 WITH (nolock) ON 
					itc2.ID = ud1.TipoVenta_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc3 WITH (nolock) ON 
					itc3.ID = ud1.Sucursal_ID
				LEFT JOIN [CalipsoProduccion].[dbo].[cliente] c1 on 
					c1.id=fv.destinatario_id
				LEFT JOIN [CalipsoProduccion].[dbo].[ud_cliente] ud3 on 
					ud3.id=c1.boextension_id
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc4 WITH (nolock) ON 
					itc4.ID = ud3.TipoCliente_ID
				LEFT JOIN [CalipsoProduccion].[dbo].[domicilio] dom on 
					dom.id=c1.domiciliofacturacion_id
				LEFT JOIN [CalipsoProduccion].[dbo].[ciudad] ciu on 
					ciu.id=dom.ciudad_id
				LEFT JOIN [CalipsoProduccion].[dbo].[Provincia] Pro on 
					pro.id=dom.Provincia_id
				LEFT JOIN [CalipsoProduccion].[dbo].[empleado] emp on 
					emp.id=ud1.empleadoVendedor_id
			WHERE fv.ESTADO = 'C'
					AND p.Rubro = '01 - Repuestos'
					AND (itc3.NOMBRE = 'Tagle - Cordoba' OR itc3.NOMBRE = 'Tagle - Rio IV' OR itc3.NOMBRE = 'Tagle - Villa Mar�a' OR itc3.NOMBRE = 'Nix - Rio IV' OR itc3.NOMBRE = 'Nix - Cordoba')
					AND (itc2.NOMBRE = 'Repuestos Tagle' OR itc2.NOMBRE = 'Taller Mecanico Tagle' OR itc2.NOMBRE = 'Taller de Chapa Tagle')
					AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) >= @FechDesde
					AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) <= @FechHasta
			UNION ALL
			-- FACTURA DE VENTA RT
			SELECT TOP 1000000 'Factura Venta RT' Tipo_Comprobante, 
				fv.NOMBRE AS Comprobante, 
				fv.NUMERODOCUMENTO AS Numero_Factura, 
				fv.NOMBREDESTINATARIO AS Cliente, 
				substring(fv.FECHAACTUAL,1,4) A�o, 
				substring(fv.FECHAACTUAL,5,2) Mes, 
				cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) AS Fecha, 
				itc2.NOMBRE AS Tipo_Venta, 
				itc3.NOMBRE AS Sucursal, 
				p.ID AS Codigo_Calipso,
				p.CODIGO AS Codigo_Referencia, 
				p.DESCRIPCION AS Descripcion_Referencia, 
				p.TipoBienCambio Tipo_Bien_Cambio, 
				p.Rubro,
				p.SubRubro,
				p.Familia,
				p.Tipo Tipo_Referencia,
				ifv.CANTIDAD2_CANTIDAD AS Cantidad, 
				ifv.TOTAL2_IMPORTE TotalVentaNeta, 
				ifv.Valor2_importe*ifv.porcentajebonificacion*ifv.cantidad2_cantidad TotalDescuento,
				isnull(ud2.pucosto*ifv.CANTIDAD2_CANTIDAD*-1,0) TotalCosto,
				ISNULL(itc1.NOMBRE, '') AS cargo, 
				ciu.Nombre Ciudad_Cliente,
				pro.nombre Provincia_Cliente,
				cc.NOMBRE AS Centro_Costos,
				itc4.codigo+' - '+itc4.NOMBRE AS Tipo_Cliente,
				emp.descripcion Vendedor,
				ud3.TeParticular Telefono_particular
			FROM [CalipsoProduccion].[dbo].[TRFACTURAVENTA] AS fv WITH (nolock) 
				INNER JOIN [CalipsoProduccion].[dbo].[ITEMFACTURAVENTA] AS ifv WITH (nolock) ON 
					ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID 
				LEFT JOIN [CalipsoProduccion].[dbo].[vp_referencia_] AS p WITH (nolock)ON 
					p.ID = ifv.REFERENCIA_ID 
				INNER JOIN [CalipsoProduccion].[dbo].[UD_ITEMFACTURART] AS ud2 WITH (nolock) ON 
					ud2.ID = ifv.BOEXTENSION_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc1 WITH (nolock)ON 
					itc1.ID = ud2.Cargo_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[CENTROCOSTOS] AS cc WITH (nolock) ON 
					cc.ID = ifv.CENTROCOSTOS_ID 
				INNER JOIN [CalipsoProduccion].[dbo].[UD_FACTURAVENTART] AS ud1 WITH (nolock) ON 
					ud1.ID = fv.BOEXTENSION_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc2 WITH (nolock) ON 
					itc2.ID = ud1.TipoVenta_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc3 WITH (nolock) ON 
					itc3.ID = ud1.Sucursal_ID
				LEFT JOIN [CalipsoProduccion].[dbo].[cliente] c1 on 
					c1.id=fv.destinatario_id
				LEFT JOIN [CalipsoProduccion].[dbo].[ud_cliente] ud3 on 
					ud3.id=c1.boextension_id
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc4 WITH (nolock) ON 
					itc4.ID = ud3.TipoCliente_ID
				LEFT JOIN [CalipsoProduccion].[dbo].[domicilio] dom on 
					dom.id=c1.domiciliofacturacion_id
				LEFT JOIN [CalipsoProduccion].[dbo].[ciudad] ciu on 
					ciu.id=dom.ciudad_id
				LEFT JOIN [CalipsoProduccion].[dbo].[Provincia] Pro on 
					pro.id=dom.Provincia_id
				LEFT JOIN [CalipsoProduccion].[dbo].[empleado] emp on 
					emp.id=ud1.empleadoVendedor_id
			WHERE fv.ESTADO = 'C' 
					AND p.Rubro = '01 - Repuestos'
					AND (itc3.NOMBRE = 'Tagle - Cordoba' OR itc3.NOMBRE = 'Tagle - Rio IV' OR itc3.NOMBRE = 'Tagle - Villa Mar�a' OR itc3.NOMBRE = 'Nix - Rio IV' OR itc3.NOMBRE = 'Nix - Cordoba')
					AND (itc2.NOMBRE = 'Repuestos Tagle' OR itc2.NOMBRE = 'Taller Mecanico Tagle' OR itc2.NOMBRE = 'Taller de Chapa Tagle')
					AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) >= @FechDesde
					AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) <= @FechHasta
			UNION ALL
			-- NOTA DE CREDITO DE VENTA
			SELECT TOP 1000000 'Nota Credito Venta' Tipo_Comprobante, 
				fv.NOMBRE AS Comprobante, 
				fv.NUMERODOCUMENTO AS Numero_Factura, 
				fv.NOMBREDESTINATARIO AS Cliente, 
				substring(fv.FECHAACTUAL,1,4) A�o, 
				substring(fv.FECHAACTUAL,5,2) Mes, 
				cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) AS Fecha, 
				itc2.NOMBRE AS Tipo_Venta, 
				itc3.NOMBRE AS Sucursal,
				p.ID AS Codigo_Calipso, 
				p.CODIGO AS Codigo_Referencia, 
				p.DESCRIPCION AS Descripcion_Referencia, 
				p.TipoBienCambio Tipo_Bien_Cambio, 
				p.Rubro,
				p.SubRubro,
				p.Familia,
				p.Tipo Tipo_Referencia,
				ifv.CANTIDAD2_CANTIDAD*-1 AS Cantidad, 
				ifv.TOTAL2_IMPORTE*-1 TotalVentaNeta, 
				ifv.Valor2_importe*ifv.porcentajebonificacion*ifv.cantidad2_cantidad*-1 TotalDescuento,
				isnull(ud2.pucosto*ifv.CANTIDAD2_CANTIDAD*-1,0) Costo,
				ISNULL(itc1.NOMBRE, '') AS cargo, 
				ciu.Nombre Ciudad_Cliente,
				pro.nombre Provincia_Cliente,
				cc.NOMBRE AS Centro_Costos,
				itc4.codigo+' - '+itc4.NOMBRE AS Tipo_Cliente,
				emp.descripcion Vendedor,
				ud3.TeParticular Telefono_particular
			FROM [CalipsoProduccion].[dbo].[TRCREDITOVENTA] AS fv WITH (nolock) 
				INNER JOIN [CalipsoProduccion].[dbo].[ITEMCREDITOVENTA] AS ifv WITH (nolock) ON 
					ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID 
				LEFT JOIN [CalipsoProduccion].[dbo].[vp_referencia_] AS p WITH (nolock)ON 
					p.ID = ifv.REFERENCIA_ID 
				INNER JOIN [CalipsoProduccion].[dbo].[UD_ITEMCREDITOVENTA] AS ud2 WITH (nolock) ON 
					ud2.ID = ifv.BOEXTENSION_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc1 WITH (nolock)ON 
					itc1.ID = ud2.Cargo_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[CENTROCOSTOS] AS cc WITH (nolock) ON 
					cc.ID = ifv.CENTROCOSTOS_ID 
				INNER JOIN [CalipsoProduccion].[dbo].[UD_NOTACREDITOVENTA] AS ud1 WITH (nolock) ON 
					ud1.ID = fv.BOEXTENSION_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc2 WITH (nolock) ON 
					itc2.ID = ud1.TipoVenta_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc3 WITH (nolock) ON 
					itc3.ID = ud1.Sucursal_ID
				LEFT JOIN [CalipsoProduccion].[dbo].[cliente] c1 on 
					c1.id=fv.destinatario_id
				LEFT JOIN [CalipsoProduccion].[dbo].[ud_cliente] ud3 on 
					ud3.id=c1.boextension_id
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc4 WITH (nolock) ON 
					itc4.ID = ud3.TipoCliente_ID
				LEFT JOIN [CalipsoProduccion].[dbo].[domicilio] dom on 
					dom.id=c1.domiciliofacturacion_id
				LEFT JOIN [CalipsoProduccion].[dbo].[ciudad] ciu on 
					ciu.id=dom.ciudad_id
				LEFT JOIN [CalipsoProduccion].[dbo].[Provincia] Pro on 
					pro.id=dom.Provincia_id
				LEFT JOIN [CalipsoProduccion].[dbo].[empleado] emp on 
					emp.id=ud1.empleadoVendedor_id
			WHERE fv.ESTADO = 'C' 
					AND p.Rubro = '01 - Repuestos'
					AND (itc3.NOMBRE = 'Tagle - Cordoba' OR itc3.NOMBRE = 'Tagle - Rio IV' OR itc3.NOMBRE = 'Tagle - Villa Mar�a' OR itc3.NOMBRE = 'Nix - Rio IV' OR itc3.NOMBRE = 'Nix - Cordoba')
					AND (itc2.NOMBRE = 'Repuestos Tagle' OR itc2.NOMBRE = 'Taller Mecanico Tagle' OR itc2.NOMBRE = 'Taller de Chapa Tagle')
					AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) >= @FechDesde
					AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) <= @FechHasta
			UNION ALL
			-- NOTA DE DEBITO DE VENTA
			SELECT TOP 1000000 'Nota Debito Venta' Tipo_Comprobante, 
				fv.NOMBRE AS Comprobante, 
				fv.NUMERODOCUMENTO AS Numero_Factura, 
				fv.NOMBREDESTINATARIO AS Cliente, 
				substring(fv.FECHAACTUAL,1,4) A�o, 
				substring(fv.FECHAACTUAL,5,2) Mes, 
				cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) AS Fecha, 
				itc2.NOMBRE AS Tipo_Venta, 
				itc3.NOMBRE AS Sucursal,
				p.ID AS Codigo_Calipso,
				p.CODIGO AS Codigo_Referencia, 
				p.DESCRIPCION AS Descripcion_Referencia, 
				p.TipoBienCambio Tipo_Bien_Cambio, 
				p.Rubro,
				p.SubRubro,
				p.Familia,
				p.Tipo Tipo_Referencia,
				ifv.CANTIDAD2_CANTIDAD AS Cantidad, 
				ifv.TOTAL2_IMPORTE TotalVentaNeta, 
				ifv.Valor2_importe*ifv.porcentajebonificacion*ifv.cantidad2_cantidad TotalDescuento,
				isnull(ud2.pucosto*ifv.CANTIDAD2_CANTIDAD,0) Costo,
				ISNULL(itc1.NOMBRE, '') AS cargo, 
				ciu.Nombre Ciudad_Cliente,
				pro.nombre Provincia_Cliente,
				cc.NOMBRE AS Centro_Costos,
				itc4.codigo+' - '+itc4.NOMBRE AS Tipo_Cliente,
				emp.descripcion Vendedor,
				ud3.TeParticular Telefono_particular
			FROM [CalipsoProduccion].[dbo].[TRdebitoVENTA] AS fv WITH (nolock) 
				INNER JOIN [CalipsoProduccion].[dbo].[ITEMDEBITOVENTA] AS ifv WITH (nolock) ON 
					ifv.BO_PLACE_ID = fv.ITEMSTRANSACCION_ID 
				left JOIN [CalipsoProduccion].[dbo].[vp_referencia_] AS p WITH (nolock)ON 
					p.ID = ifv.REFERENCIA_ID 
				inner JOIN [CalipsoProduccion].[dbo].[UD_ITEMDEBITOVENTA] AS ud2 WITH (nolock) ON 
					ud2.ID = ifv.BOEXTENSION_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc1 WITH (nolock)ON 
					itc1.ID = ud2.Cargo_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[CENTROCOSTOS] AS cc WITH (nolock) ON 
					cc.ID = ifv.CENTROCOSTOS_ID 
				inner JOIN [CalipsoProduccion].[dbo].[UD_NOTADEBITOVENTA] AS ud1 WITH (nolock) ON 
					ud1.ID = fv.BOEXTENSION_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc2 WITH (nolock) ON 
					itc2.ID = ud1.TipoVenta_ID 
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc3 WITH (nolock) ON 
					itc3.ID = ud1.Sucursal_ID
				left join [CalipsoProduccion].[dbo].[cliente] c1 on 
					c1.id=fv.destinatario_id
				left join [CalipsoProduccion].[dbo].[ud_cliente] ud3 on 
					ud3.id=c1.boextension_id
				LEFT OUTER JOIN [CalipsoProduccion].[dbo].[ITEMTIPOCLASIFICADOR] AS itc4 WITH (nolock) ON 
					itc4.ID = ud3.TipoCliente_ID
				left join [CalipsoProduccion].[dbo].[domicilio] dom on 
					dom.id=c1.domiciliofacturacion_id
				left join [CalipsoProduccion].[dbo].[ciudad] ciu on 
					ciu.id=dom.ciudad_id
				left join [CalipsoProduccion].[dbo].[Provincia] Pro on 
					pro.id=dom.Provincia_id
				left join [CalipsoProduccion].[dbo].[empleado] emp on 
					emp.id=ud1.empleadoVendedor_id
			WHERE fv.ESTADO = 'C' 
					AND p.Rubro = '01 - Repuestos'
					AND (itc3.NOMBRE = 'Tagle - Cordoba' OR itc3.NOMBRE = 'Tagle - Rio IV' OR itc3.NOMBRE = 'Tagle - Villa Mar�a' OR itc3.NOMBRE = 'Nix - Rio IV' OR itc3.NOMBRE = 'Nix - Cordoba')
					AND (itc2.NOMBRE = 'Repuestos Tagle' OR itc2.NOMBRE = 'Taller Mecanico Tagle' OR itc2.NOMBRE = 'Taller de Chapa Tagle')
					AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) >= @FechDesde
					AND cast(substring(fv.FECHAACTUAL,7,2)+'/'+substring(fv.FECHAACTUAL,5,2)+'/'+substring(fv.FECHAACTUAL,1,4) as datetime) <= @FechHasta
		) AS FDC
	GROUP BY A�o + '/' + Mes + '/01'
		, Codigo_Calipso
		, Codigo_Referencia
		, Tipo_Venta
		, Centro_Costos
		, cargo
	ORDER BY A�o + '/' + Mes + '/01'
		, Codigo_Calipso

END
GO
